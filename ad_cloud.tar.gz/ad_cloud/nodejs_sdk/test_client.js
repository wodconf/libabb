var client_mod = require("./client");
var appid = "app1";
console.log(process.argv);
if(process.argv.length >= 3){
	appid = process.argv[2]
}
var arr = ["127.0.0.1:8365"];
var cli = client_mod.Create(appid,arr);

cli.Connect();

cli.on("open",function(){
	console.log("open");
	cli.Send("hello");
	cli.Send("hello");
})
cli.on("close",function(err){
	console.log("close err:",err);
})
cli.on("message",function(buf){
	var str = buf.toString();
	console.log("message",str);
	cli.Send("hello");
})