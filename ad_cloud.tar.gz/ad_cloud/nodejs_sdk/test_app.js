var app_mod = require("./app");
var appid = "app1";
console.log(process.argv);
if(process.argv.length >= 3){
	appid = process.argv[2]
}
var arr = ["127.0.0.1:8365"];
var app = app_mod.Create(appid,arr,"127.0.0.1");
var timer;
var num_pkt = 0;
var num_cli = 0;
app.on('open',function(){
	console.log("opened");
})
app.on("client_in",function(id){
	num_cli++;
	//console.log("client_in",id);
})
app.on("client_data",function(id,buf){
	var str = buf.toString();
	num_pkt++;
	//console.log("client_data",id,str);
	//app.SendToClient(id,"world");
})
app.on("client_out",function(id){
	num_cli--;
	//console.log("client_out",id);
})
app.on("app_data",function(buf){
	console.log("app_data",id);
})
app.on('close',function(err){
	console.log("close",err);
	clearInterval(timer);
	app.Stop();
})
setInterval(function(){
	if(num_pkt > 0){
		console.log("pkt:",num_pkt,"cli:",num_cli);
		num_pkt = 0;
	}
},1000)
app.Start();
