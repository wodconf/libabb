
var util = require("util");
var events = require("events");
var  adcloud = require("../../node_adcloud");

const STATE_INITED = 1;
const STATE_DISPATCHING = 2;
const STATE_DISPATCHED = 3;
const STATE_REGISTING = 4;
const STATE_REGISTED = 5;
const STATE_CLOSED = 6;

exports.Create = function(appid,proxyaddr,selfip){
	return new AdcloudApp(appid,proxyaddr,selfip);
}
function AdcloudApp( appid ,proxyaddr,selfip){
	events.EventEmitter.call(this);
	this.state_ = STATE_INITED;
	this.appid_ = appid;
	
	var self =this;
	this.proxy_client_ = new adcloud.ProxyClient(proxyaddr);
	this.master_client_ = new adcloud.MasterClient(appid,selfip);
	this.master_client_.on("open",function(){
		self.state_ = STATE_REGISTED;
		self.emit("open");
	})
	this.master_client_.on("client_in",function(id){
		self.emit("client_in",id);
	})
	this.master_client_.on("client_data",function(id,buf){
		self.emit("client_data",id,buf);
	})
	this.master_client_.on("client_out",function(id){
		self.emit("client_out",id);
	})
	this.master_client_.on("app_data",function(fromappid,buf){
		self.emit("app_data",fromappid,buf);
	})
	this.master_client_.on("close",function(err){
		self.emit("close",err);
	})
}

util.inherits(AdcloudApp, events.EventEmitter);


AdcloudApp.prototype.Start = function(){
	console.log("Start");
	if(this.state_ != STATE_INITED){
		console.log("state.error.state=",this.state_);
		return false;
	}
	this.state_ = STATE_DISPATCHING;
	var self = this;
	this.proxy_client_.GetMaster(this.appid_,1000,function(err,addr){
		if(err){
			self.emit("close",err);
		}else{
			if(self.state_ == STATE_CLOSED) return;
			self.state_ = STATE_DISPATCHED;
			self.state_ = STATE_REGISTING;
			self.master_client_.Connect(addr.ip,addr.port);
		}
	})
}

AdcloudApp.prototype.Stop = function(){
	this.master_client_.Close();
	this.state_ = STATE_CLOSED;
}

AdcloudApp.prototype.CloseClient = function(id){
	return this.master_client_.CloseClient(id);
}
AdcloudApp.prototype.SendToClient = function(id,data){
	return this.master_client_.SendToClient(id,data);
}

AdcloudApp.prototype.AddScope = function(scope,id){
	return this.master_client_.AddScope(scope,id);
}
AdcloudApp.prototype.DelScope = function(scope,id){
	return this.master_client_.DelScope(scope,id);
}
AdcloudApp.prototype.SendToScope = function(scope,data){
	return this.master_client_.SendToScope(scope,data);
}