
#include "rpc_translate.hpp"
#include "../rpc/rpc_message.hpp"
#include "../common/log.hpp"
#include "../raft/peer.hpp"
namespace adcloud {
namespace monraft {

RpcTranslate::RpcTranslate() {
}

RpcTranslate::~RpcTranslate() {
}
common::SerializationAble* RpcTranslate::SendCommond(raft::Commond* cmd,const std::string& addr,std::string& save_error){
	common::SerializationAble* ret = pool_.Call(addr,"RecvCommond",cmd,save_error);
	return ret;
}
raft::AppendEntriesResponce* RpcTranslate::SendAppendEntries( raft::RaftServer* svr, raft::Peer& peer,raft::AppendEntriesRequest&req){
	std::string err;
	common::SerializationAble* ret = pool_.Call(peer.GetAddr(),"AppendEntries",&req,err);
	if(ret){
		if(ret->GetTypeName() == raft::AppendEntriesResponce::TypeName){
			return static_cast<raft::AppendEntriesResponce*>(ret);
		}
	}
	return NULL;
}
raft::VoteResponce* RpcTranslate::SendVoteRequest( raft::RaftServer* svr, raft::Peer& peer,raft::VoteRequest&req){
	std::string err;
	common::SerializationAble* ret = pool_.Call(peer.GetAddr(),"VoteRequest",&req,err);
	if(ret){
		if(ret->GetTypeName() == raft::VoteResponce::TypeName){
			return static_cast<raft::VoteResponce*>(ret);
		}
	}
	return NULL;
}
raft::SnapshotRecoveryResponce* RpcTranslate::SendSnapshotRecovery( raft::RaftServer* svr, raft::Peer& peer,raft::SnapshotRecoveryRequest&req){
	std::string err;
	common::SerializationAble* ret = pool_.Call(peer.GetAddr(),"SnapshotRecovery",&req,err);
	if(ret){
		if(ret->GetTypeName() == raft::SnapshotRecoveryResponce::TypeName){
			return static_cast<raft::SnapshotRecoveryResponce*>(ret);
		}
	}
	return NULL;
}
raft::SnapshotResponce* RpcTranslate::SendSnapshotRequest( raft::RaftServer* svr, raft::Peer& peer,raft::SnapshotRequest&req){
	std::string err;
	common::SerializationAble* ret =pool_.Call(peer.GetAddr(),"SnapshotRequest",&req,err);
	if(ret){
		if(ret->GetTypeName() == raft::SnapshotResponce::TypeName){
			return static_cast<raft::SnapshotResponce*>(ret);
		}
	}
	return NULL;
}
} /* namespace mastermon */
} /* namespace adcloud */
