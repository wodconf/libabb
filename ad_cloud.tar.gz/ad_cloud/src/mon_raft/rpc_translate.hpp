
#ifndef ADCLOUD_MON_COMMON_RPC_TRANSLATE_HPP_
#define ADCLOUD_MON_COMMON_RPC_TRANSLATE_HPP_

#include "../raft/i_translate.hpp"
#include "../rpc/rpc_client_pool.hpp"
#include "../common/mutex.hpp"
#include <map>
#include "../raft/join_commond.hpp"
namespace adcloud {
namespace monraft {

class RpcTranslate:public raft::ITranslate {
public:
	RpcTranslate();
	~RpcTranslate();
	common::SerializationAble* SendCommond(raft::Commond* cmd,const std::string& addr,std::string& save_error);
	virtual raft::AppendEntriesResponce* SendAppendEntries( raft::RaftServer* svr, raft::Peer& peer,raft::AppendEntriesRequest&req);
	virtual raft::VoteResponce* SendVoteRequest( raft::RaftServer* svr, raft::Peer& peer,raft::VoteRequest&req);
	virtual raft::SnapshotRecoveryResponce* SendSnapshotRecovery( raft::RaftServer* svr, raft::Peer& peer,raft::SnapshotRecoveryRequest&req);
	virtual raft::SnapshotResponce* SendSnapshotRequest( raft::RaftServer* svr, raft::Peer& peer,raft::SnapshotRequest&req);
private:
	rpc::RpcClientPool pool_;
};

} /* namespace mastermon */
} /* namespace adcloud */

#endif /* RPC_TRANSLATE_HPP_ */
