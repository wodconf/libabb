

#ifndef ADCOUD_MASTER_MON_PEER_SERVER_HPP_
#define ADCOUD_MASTER_MON_PEER_SERVER_HPP_
#include <abb/net/ip_addr.hpp>

#include "../raft/raft_server.hpp"
#include "../raft/i_translate.hpp"

#include "../raft/join_commond.hpp"
#include "../translate/acceptor.hpp"
#include "../translate/connection.hpp"
#include "../rpc/rpc_service.hpp"
#include "../common/thread.hpp"
#include "../common/notification.hpp"
#include <vector>
#include <string>
#include <cassert>
namespace adcloud {
namespace monraft{
class RpcTranslate;
class IJoinCommondFactory{
public:
	virtual ~IJoinCommondFactory(){};
	virtual raft::JoinCommond * CreateJoinCommond() = 0;
};
struct SnapshotConf {
	uint32_t checkingInterval ;
	uint64_t lastIndex ;
	uint64_t snapshotThr ;
};
class VoteRequest;
class AppendEntries;
class SnapshotRecovery;
class SnapshotRequest;
class RecvCommond;
class PeerServer :public translate::Acceptor::Listener,translate::Connection::Listener{
public:
	PeerServer(IJoinCommondFactory* fac,
			const std::string& name,
			const std::string& path,
			const std::string& self_addr,
			translate::Acceptor* actor,
			void* ctx,
			const SnapshotConf&conf,
			raft::IStateMachine* machine);
	~PeerServer();
	bool Init();
	bool Start(const std::vector<std::string>& addrlist);
	void Stop(){
		actor_->SetEnable(false);
		this->raft_svr_->Stop();
		this->rpc_svr_->Stop();
		notify_.Notify();
		this->thread_.Wait();
	}
	void* ProcessCommond(raft::Commond* cmd,std::string& save_error);
	virtual void L_Connection_OnMessage(translate::Connection* self,translate::Message*msg);
	virtual void L_Connection_OnClose(translate::Connection* self);
	virtual void L_Acceptor_OnConnection(translate::Connection*);

private:
	bool JoinCluster(raft::JoinCommond* cmd,const std::string& addr);
	static void* ThreadMain(void*arg){
		PeerServer* svr = (PeerServer*)arg;
		svr->MonitorLoop();
		return NULL;
	}
	void MonitorLoop();
	void MonitorSnapshot();
	void MonitorPeer();
	friend class VoteRequest;
	friend class AppendEntries;
	friend class SnapshotRecovery;
	friend class SnapshotRequest;
	friend class RecvCommond;
	SnapshotRequest* sreq_fn_;
	RecvCommond* pc_fn_;
	AppendEntries* ae_fn_;
	VoteRequest* vr_fn_;
	SnapshotRecovery* sr_fn_;
	raft::RaftServer* raft_svr_;
	rpc::RpcService* rpc_svr_;
	translate::Acceptor* actor_;
	RpcTranslate* tl_;
	IJoinCommondFactory* fac_;
	SnapshotConf snap_conf_;
	common::Thread thread_;
	common::Notification notify_;

};

} /* namespace mastermon */
} /* namespace adcloud */

#endif /* PEER_SERVER_HPP_ */
