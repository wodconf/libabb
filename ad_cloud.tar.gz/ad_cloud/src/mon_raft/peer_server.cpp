
#include "peer_server.hpp"
#include "rpc_translate.hpp"
#include "../raft/append_entries.hpp"
#include "../raft/vote.hpp"
#include "../common/time.hpp"
namespace adcloud {
namespace monraft {

class AppendEntries:public rpc::RpcService::IRpcFunction{
public:
	AppendEntries(PeerServer* p):self(p){};
	virtual ~AppendEntries(){};
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& save_error){
		assert(arg->GetTypeName() == raft::AppendEntriesRequest::TypeName);
		common::SerializationAble* ret =  self->raft_svr_->AppendEntries(static_cast<raft::AppendEntriesRequest*>(arg),save_error);
		arg->UnRef();
		return ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	PeerServer* self;
};
class VoteRequest:public rpc::RpcService::IRpcFunction{
public:
	VoteRequest(PeerServer* p):self(p){};
	virtual ~VoteRequest(){};
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& save_error){
		assert(arg->GetTypeName() == raft::VoteRequest::TypeName);
		common::SerializationAble* ret =  self->raft_svr_->Vote(static_cast<raft::VoteRequest*>(arg),save_error);
		arg->UnRef();
		return ret;

	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	PeerServer* self;
};
class RecvCommond:public rpc::RpcService::IRpcFunction{
public:
	RecvCommond(PeerServer* p):self(p){};
	virtual ~RecvCommond(){};
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& save_error){
		void* ret = ( self->raft_svr_->DealCommond(static_cast<raft::Commond*>(arg),save_error) );
		arg->UnRef();
		return static_cast<common::SerializationAble*>(ret);
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	PeerServer* self;
};
class SnapshotRecovery:public rpc::RpcService::IRpcFunction{
public:
	SnapshotRecovery(PeerServer* p):self(p){};
	virtual ~SnapshotRecovery(){};
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& save_error){
		common::SerializationAble* ret =  self->raft_svr_->RequestSnapshotRecovery(static_cast<raft::SnapshotRecoveryRequest*>(arg),save_error);
		arg->UnRef();
		return ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	PeerServer* self;
};
class SnapshotRequest:public rpc::RpcService::IRpcFunction{
public:
	SnapshotRequest(PeerServer* p):self(p){};
	virtual ~SnapshotRequest(){};
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& save_error){
		common::SerializationAble* ret =self->raft_svr_->RequestSnapshot(static_cast<raft::SnapshotRequest*>(arg),save_error);
		arg->UnRef();
		return ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	PeerServer* self;
};
PeerServer::PeerServer(IJoinCommondFactory* fac,
		const std::string& name,
		const std::string& path,
		const std::string& self_addr,
		translate::Acceptor* actor,
		void* ctx,
		const SnapshotConf&conf,
		raft::IStateMachine* machine)
:actor_(actor),
 ae_fn_(new AppendEntries(this)),
 vr_fn_(new VoteRequest(this)),
 sr_fn_(new SnapshotRecovery(this)),
 sreq_fn_(new SnapshotRequest(this)),
 pc_fn_(new RecvCommond(this)),
 fac_(fac),
 snap_conf_(conf)
{
	actor_->SetListener(this);
	this->tl_ = new RpcTranslate();
	raft_svr_ = new raft::RaftServer(name,path,tl_,self_addr,ctx,machine);
	rpc_svr_ = new rpc::RpcService();
	rpc_svr_->RegistFunction("AppendEntries",ae_fn_);
	rpc_svr_->RegistFunction("VoteRequest",vr_fn_);
	rpc_svr_->RegistFunction("SnapshotRecovery",sr_fn_);
	rpc_svr_->RegistFunction("SnapshotRequest",sreq_fn_);
	rpc_svr_->RegistFunction("RecvCommond",pc_fn_);

	snap_conf_.lastIndex = this->raft_svr_->CommitIndex();
}
PeerServer::~PeerServer() {
	delete this->raft_svr_;
	delete this->actor_;
	delete this->rpc_svr_;
	delete this->ae_fn_;
	delete this->pc_fn_;
	delete this->vr_fn_;
}
bool PeerServer::Start(const std::vector<std::string>& addrlist){
	if( ! this->raft_svr_->Init() ){
		LOG(WARN) << "raft server init fail";
		return false;
	}
	this->raft_svr_->LoadSnapshot();
	bool is_new = this->raft_svr_->IsLogEmpty();
	if( !this->raft_svr_->Start() ){
		LOG(WARN) << "raft server Start fail";
		return false;
	}
	bool suc = false;
	this->actor_->SetEnable(true);
	this->rpc_svr_->Start();
	raft::JoinCommond* cmd = this->fac_->CreateJoinCommond();
	if(is_new){
		if(addrlist.size() == 0){
			std::string err;
			void* ret = this->raft_svr_->DealCommond(cmd,err);
			if(ret == NULL && !err.empty()){
				LOG(WARN) << "PeerServer ProcessCommond JOIN err:"<<err;
				suc = false;
			}else if(ret == NULL){
				LOG(WARN) << "PeerServer ProcessCommond JOIN NULL";
				suc = false;
			}else{
				rpc::TRpcBool* b = static_cast<rpc::TRpcBool*>(ret);
				suc = b->success;
			}

		}else{
			for(int i=0;i<addrlist.size();i++){
				suc = JoinCluster(cmd,addrlist[i]);
				if(suc){
					break;
				}
			}
		}
	}else{
		std::vector<std::string> addrs;
		raft::RaftServer::PeerMap pm = this->raft_svr_->Peers();
		for(raft::RaftServer::PeerMap::iterator iter = pm.begin();iter != pm.end();iter++){
			addrs.push_back( iter->second->GetAddr() );
		}
		if(addrs.size() > 0){
			LOG(DEBUG) << "1";
			for(int i=0;i<addrs.size();i++){
				suc = JoinCluster(cmd,addrs[i]);
				if(suc){
					break;
				}
			}
		}
		if(!suc){
			if(addrlist.size() > 0){
				LOG(DEBUG) << "2";
				for(int i=0;i<addrlist.size();i++){
					suc = JoinCluster(cmd,addrlist[i]);
					if(suc){
						break;
					}
				}
			}else{
				LOG(DEBUG) << "3";
				suc = true;
			}
		}

	}
	if(suc){
		LOG(INFO) << "PeerServer Start Success";
		this->thread_.Start(ThreadMain,this);
	}else{
		LOG(DEBUG) << "join fail";
	}
	cmd->UnRef();
	return suc;
}
bool PeerServer::JoinCluster(raft::JoinCommond* cmd,const std::string& addr){
	std::string err;
	common::SerializationAble* ret =this->tl_->SendCommond(cmd,addr,err);
	if(ret == NULL && !err.empty()){
		LOG(WARN) << "RpcTranslate SendJoinCommond err:"<<err;
		return false;
	}else if(ret == NULL){
		LOG(WARN) << "RpcTranslate SendJoinCommond return NULL";
		return false;
	}
	rpc::TRpcBool* b = static_cast<rpc::TRpcBool*>(ret);
	return b->success;
}
void* PeerServer::ProcessCommond(raft::Commond* cmd,std::string& save_error){
	if(this->raft_svr_->State() == raft::RaftServer::LEADER){
		return this->raft_svr_->DealCommond(cmd,save_error);
	}
	std::string addr;
	if(this->raft_svr_->GetLeaderAddr(addr,&save_error)){
		return this->tl_->SendCommond(cmd,addr,save_error);
	}else{
		return NULL;
	}
}

void PeerServer::L_Connection_OnMessage(translate::Connection* self,translate::Message*msg){
	if(msg->GetTag() == rpc::MRpcRequest::TAG){
		this->rpc_svr_->AsycRpcExecute(static_cast<rpc::MRpcRequest*>(msg));
	}
}
void PeerServer::L_Connection_OnClose(translate::Connection* self){
	LOG(TRACE) << "L_Connection_OnClose" ;
	self->UnRef();
}
void PeerServer::L_Acceptor_OnConnection(translate::Connection* conn){
	conn->SetListner(this);
}
void PeerServer::MonitorLoop(){
	uint64_t now = common::time::MSNow();
	while(true){
		if( !this->notify_.WaitTimeout(snap_conf_.checkingInterval) ){
			this->MonitorSnapshot();
		}else{
			break;
		}
	}
}
void PeerServer::MonitorSnapshot(){
	uint64_t currentIndex = this->raft_svr_->CommitIndex();
	uint64_t	count = currentIndex - snap_conf_.lastIndex;
	if(count > snap_conf_.snapshotThr){
		std::string err;
		if( !this->raft_svr_->TakeSnapshot(err) ){
			LOG(WARN) << "PeerServer.TakeSnapshot fail:" << err;
		}
		//log
		snap_conf_.lastIndex = currentIndex;
	}
}

} /* namespace mastermon */
} /* namespace adcloud */
