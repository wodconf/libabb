


#include "global/global_init.hpp"
#include "monitor/mm_monitor.hpp"
#include "common/arg_parse.hpp"
#include "monitor/mm_config.hpp"
#include "monitor/mm_init.hpp"
#include "common/time.hpp"


using namespace adcloud;


int main(int argc,const char* argv[]){
	common::ArgParse parse;
	parse.Parse(argc,argv);
	if( global::Init(parse) != 0){
		LOG(ERROR) << "global.init.fail";
	}
	mon::Config cfg;
	if( ! cfg.Parse(parse) ){
		LOG(ERROR) << "CONFIG PARSE FAIL";
		exit(-1);
	}
	abb::base::g_min_log_level = abb::base::LOGLEVEL_DEBUG;
	mon::Init();
	mon::Monitor* mon = new mon::Monitor();
	if( !mon->Init(&cfg) ){
		LOG(ERROR) << "MasterMon Init FAIL";
		exit(-1);
	}
	if( !mon->Start() ){
		LOG(ERROR) << "MasterMon Start FAIL";
		exit(-1);
	}
	while(true){
		common::time::Sleep(1000);
	}
	return 0;
}
