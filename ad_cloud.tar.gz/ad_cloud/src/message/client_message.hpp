/*
 * client_message.hpp
 *
 *  Created on: 2014-5-19
 *      Author: wd
 */

#ifndef CLIENT_MESSAGE_HPP_
#define CLIENT_MESSAGE_HPP_
#include "../translate/message.hpp"
namespace adcloud {
namespace message {

class MClientReg :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_CLIENT_REGIST;
public:
	MClientReg();
	MClientReg(uint32_t len);
	virtual ~MClientReg();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string os_id;
};
class MClientRegBak :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_CLIENT_REGIST_BACK;
public:
	MClientRegBak():translate::Message(TAG){}
	MClientRegBak(uint32_t len):translate::Message(TAG,len){}
	virtual ~MClientRegBak(){}
private:
	virtual uint32_t GetLength(){return 0;}
	virtual void EncodeBody(common::BufferWriter& buf){}
	virtual void DecodeBody(common::BufferReader& buf){}
};
class MClientMessage :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_CLIENT_MESSAGE;
public:
	MClientMessage();
	MClientMessage(uint32_t len);
	virtual ~MClientMessage();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	void* data;
	int size;
	bool bneedfree_;
};


} /* namespace monraft */
} /* namespace adcloud */

#endif /* CLIENT_MESSAGE_HPP_ */
