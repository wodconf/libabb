#include "message_init.hpp"
#include "client_message.hpp"
namespace adcloud {
namespace message {
	void Init(){

		translate::Message::RegistCreator(MAppCloseClient::TAG,translate::T_Creater<MAppCloseClient>);
		translate::Message::RegistCreator(MAppScopeData::TAG,translate::T_Creater<MAppScopeData>);
		translate::Message::RegistCreator(MAppScopeOp::TAG,translate::T_Creater<MAppScopeOp>);
		translate::Message::RegistCreator(MAppClientData::TAG,translate::T_Creater<MAppClientData>);
		translate::Message::RegistCreator(MAppClientIn::TAG,translate::T_Creater<MAppClientIn>);
		translate::Message::RegistCreator(MAppClientOut::TAG,translate::T_Creater<MAppClientOut>);
		translate::Message::RegistCreator(MAppOtherAppData::TAG,translate::T_Creater<MAppOtherAppData>);


		translate::Message::RegistCreator(MGateClientIn::TAG,translate::T_Creater<MGateClientIn>);
		translate::Message::RegistCreator(MGateClientOut::TAG,translate::T_Creater<MGateClientOut>);
		translate::Message::RegistCreator(MGateClientData::TAG,translate::T_Creater<MGateClientData>);
		translate::Message::RegistCreator(MCloseClient::TAG,translate::T_Creater<MCloseClient>);
		translate::Message::RegistCreator(MScopeOp::TAG,translate::T_Creater<MScopeOp>);
		translate::Message::RegistCreator(MScopeData::TAG,translate::T_Creater<MScopeData>);

		translate::Message::RegistCreator(MClientReg::TAG,translate::T_Creater<MClientReg>);
		translate::Message::RegistCreator(MClientRegBak::TAG,translate::T_Creater<MClientRegBak>);
		translate::Message::RegistCreator(MClientMessage::TAG,translate::T_Creater<MClientMessage>);

		translate::Message::RegistCreator(MMasterData::TAG,translate::T_Creater<MMasterData>);
		//translate::Message::RegistCreator(MMasterMonRegist::TAG,translate::T_Creater<MMasterMonRegist>);
		//translate::Message::RegistCreator(MMasterMonRegistSuccess::TAG,translate::T_Creater<MMasterMonRegistSuccess>);
		//translate::Message::RegistCreator(MMasterMonRegistFail::TAG,translate::T_Creater<MMasterMonRegistFail>);

		}
}}
