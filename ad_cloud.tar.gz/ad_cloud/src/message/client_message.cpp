/*
 * client_message.cpp
 *
 *  Created on: 2014-5-19
 *      Author: wd
 */

#include "client_message.hpp"

namespace adcloud {
namespace message {
/******************************/
MClientReg::MClientReg():translate::Message(TAG){

}
MClientReg::MClientReg(uint32_t len):translate::Message(TAG,len){

}
MClientReg::~MClientReg(){

}
uint32_t MClientReg::GetLength(){
	return os_id.length() + 1;
}
void MClientReg::EncodeBody(common::BufferWriter& buf){
	buf << os_id;
}
void MClientReg::DecodeBody(common::BufferReader& buf){
	buf >> os_id;
}

/******************************/
MClientMessage::MClientMessage():translate::Message(TAG),bneedfree_(false),data(NULL),size(0){

}
MClientMessage::MClientMessage(uint32_t len):translate::Message(TAG,len),bneedfree_(false),data(NULL),size(0){

}
MClientMessage::~MClientMessage(){
	if(this->bneedfree_) delete [](char*)data;
}
uint32_t MClientMessage::GetLength(){
	return  size;
}
void MClientMessage::EncodeBody(common::BufferWriter& buf){
	buf.Write(this->data,this->size);
}
void MClientMessage::DecodeBody(common::BufferReader& buf){
	this->data = new char[buf.DataSize()];
	this->size = buf.DataSize();
	this->bneedfree_ = true;
	buf.Read(this->data,this->size);
}
} /* namespace monraft */
} /* namespace adcloud */
