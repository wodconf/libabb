

#ifndef M_MASTER_DATA_HPP_
#define M_MASTER_DATA_HPP_

#include "../translate/message.hpp"

namespace adcloud {
namespace message {

class MMasterData: public translate::Message {
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_MASTER_DATA;
	MMasterData();
	MMasterData(uint32_t len);
	virtual ~MMasterData();
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string from_os_id;
	std::string os_id;
	char* data;
	int size;
	bool bneedfree_;
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* M_MASTER_DATA_HPP_ */
