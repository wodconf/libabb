

#include "gate_message.hpp"
using namespace adcloud::message;
/******************************/
MGateClientIn::MGateClientIn():translate::Message(TAG),cid(0){

}
MGateClientIn::MGateClientIn(uint32_t len):translate::Message(TAG,len),cid(0){

}
MGateClientIn::~MGateClientIn(){

}
uint32_t MGateClientIn::GetLength(){
	return sizeof(this->cid);
}
void MGateClientIn::EncodeBody(common::BufferWriter& buf){
	buf.NET_WriteUint32(cid);
}
void MGateClientIn::DecodeBody(common::BufferReader& buf){
	cid = buf.HOST_ReadUint32();
}

/******************************/
MGateClientOut::MGateClientOut():translate::Message(TAG),cid(0){

}
MGateClientOut::MGateClientOut(uint32_t len):translate::Message(TAG,len),cid(0){

}

MGateClientOut::~MGateClientOut(){

}
uint32_t MGateClientOut::GetLength(){
	return sizeof(this->cid);
}
void MGateClientOut::EncodeBody(common::BufferWriter& buf){
	buf.NET_WriteUint32(cid);
}
void MGateClientOut::DecodeBody(common::BufferReader& buf){
	cid = buf.HOST_ReadUint32();
}

/******************************/
MGateClientData::MGateClientData():translate::Message(TAG),cid(0),bneedfree_(false),data(NULL),size(0){

}
MGateClientData::MGateClientData(uint32_t len):translate::Message(TAG,len),cid(0),bneedfree_(false),data(NULL),size(0){

}
MGateClientData::~MGateClientData(){
	if(this->bneedfree_) delete [](char*)data;
}
uint32_t MGateClientData::GetLength(){
	return sizeof(this->cid) + size;
}
void MGateClientData::EncodeBody(common::BufferWriter& buf){
	buf.NET_WriteUint32(cid);
	buf.Write(this->data,this->size);
}
void MGateClientData::DecodeBody(common::BufferReader& buf){
	cid = buf.HOST_ReadUint32();
	this->data = new char[buf.DataSize()];
	this->size = buf.DataSize();
	this->bneedfree_ = true;
	buf.Read(this->data,this->size);
}



/******************************/
MCloseClient::MCloseClient():translate::Message(TAG),cid(0){

}
MCloseClient::MCloseClient(uint32_t len):translate::Message(TAG,len),cid(0){

}
MCloseClient::~MCloseClient(){

}
uint32_t MCloseClient::GetLength(){
	return sizeof(this->cid);
}
void MCloseClient::EncodeBody(common::BufferWriter& buf){
	buf.NET_WriteUint32(cid);
}
void MCloseClient::DecodeBody(common::BufferReader& buf){
	cid = buf.HOST_ReadUint32();
}


/******************************/
MScopeOp::MScopeOp():translate::Message(TAG),cid(0),badd(false){

}
MScopeOp::MScopeOp(uint32_t len):translate::Message(TAG,len),cid(0),badd(false){

}
MScopeOp::~MScopeOp(){

}
uint32_t MScopeOp::GetLength(){
	return sizeof(this->cid)+sizeof(badd)+scope.length()+1;
}
void MScopeOp::EncodeBody(common::BufferWriter& buf){
	buf.NET_WriteUint32(cid);
	buf << badd;
	buf << scope;
}
void MScopeOp::DecodeBody(common::BufferReader& buf){
	cid = buf.HOST_ReadUint32();
	buf >> badd;
	buf >> scope;
}

/******************************/
MScopeData::MScopeData():translate::Message(TAG),bneedfree_(false),data(NULL),size(0){

}
MScopeData::MScopeData(uint32_t len):translate::Message(TAG,len),bneedfree_(false),data(NULL),size(0){

}
MScopeData::~MScopeData(){
	if(this->bneedfree_) delete [](char*)data;
}
uint32_t MScopeData::GetLength(){
	return this->size+scope.length()+1;
}
void MScopeData::EncodeBody(common::BufferWriter& buf){
	buf << scope;
	buf.Write(this->data,this->size);
}
void MScopeData::DecodeBody(common::BufferReader& buf){
	buf >> scope;
	this->data = new char[buf.DataSize()];
	this->size = buf.DataSize();
	this->bneedfree_ = true;
	buf.Read(this->data,this->size);
}
