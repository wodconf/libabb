

#ifndef APP_MESSAGE_HPP_
#define APP_MESSAGE_HPP_

#include "../translate/message.hpp"
#include <vector>
#include <string>
#include <stdint.h>

namespace adcloud {
namespace message {



class MAppCloseClient:public translate::Message{
public:
	static const uint32_t TAG = ADCLOUD_MESSAGE_TAG_APP_CLOSE_CLIENT;
public:
	MAppCloseClient();
	MAppCloseClient(uint32_t len);
	virtual ~MAppCloseClient();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string gate_id;
	uint32_t client_id;
};


class MAppScopeOp:public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_APP_SCOPE_OP;
public:
	MAppScopeOp();
	MAppScopeOp(uint32_t len);
	virtual ~MAppScopeOp();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string scope;
	std::string gate_id;
	uint32_t client_id;
	bool  badd;
};

class MAppScopeData:public translate::Message{
public:
	static const uint32_t TAG = ADCLOUD_MESSAGE_TAG_APP_SCOPE_DATA;
public:
	MAppScopeData();
	MAppScopeData(uint32_t len);
	virtual ~MAppScopeData();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string scope;
	char* data;
	uint32_t size;
	bool bneedfree_;
};


class MAppClientData :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_APP_MSG;
public:
	MAppClientData();
	MAppClientData(uint32_t len);
	virtual ~MAppClientData();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string gate_id;
	uint32_t client_id;
	void* data;
	uint32_t size;
	bool bneedfree_;
};

class MAppClientIn :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_APP_IN;
public:
	MAppClientIn();
	MAppClientIn(uint32_t len);
	virtual ~MAppClientIn();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string gate_id;
	uint32_t client_id;
};

class MAppClientOut :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_APP_OUT;
public:
	MAppClientOut();
	MAppClientOut(uint32_t len);
	virtual ~MAppClientOut();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string gate_id;
	uint32_t client_id;
};

class MAppOtherAppData :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_APP_OTHER_APP_DATA;
public:
	MAppOtherAppData();
	MAppOtherAppData(uint32_t len);
	virtual ~MAppOtherAppData();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string appid;
	void* data;
	uint32_t size;
	bool bneedfree_;
};
}
}



#endif /* APP_MESSAGE_HPP_ */
