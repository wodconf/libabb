

#include "m_master_data.hpp"

namespace adcloud {
namespace message {

/******************************/
MMasterData::MMasterData():translate::Message(TAG),bneedfree_(false),data(NULL),size(0){

}
MMasterData::MMasterData(uint32_t len):translate::Message(TAG,len),bneedfree_(false),data(NULL),size(0){

}
MMasterData::~MMasterData(){
	if(this->bneedfree_) delete [](char*)data;
}
uint32_t MMasterData::GetLength(){
	return from_os_id.length() + os_id.length() + 2 + size;
}
void MMasterData::EncodeBody(common::BufferWriter& buf){
	buf << from_os_id;
	buf << os_id;
	buf.Write(this->data,this->size);
}
void MMasterData::DecodeBody(common::BufferReader& buf){
	buf >> from_os_id;
	buf >> os_id;
	this->data = new char[buf.DataSize()];
	this->size = buf.DataSize();
	this->bneedfree_ = true;
	buf.Read(this->data,this->size);
}

} /* namespace translate */
} /* namespace adcloud */
