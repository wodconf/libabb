#ifndef AD_CLOUD_INIT_MESSAGE_H_
#define AD_CLOUD_INIT_MESSAGE_H_

#include "../message/app_message.hpp"
#include "../message/gate_message.hpp"
#include "../message/m_master_data.hpp"

namespace adcloud {
namespace message {
	void Init();
}}

#endif
