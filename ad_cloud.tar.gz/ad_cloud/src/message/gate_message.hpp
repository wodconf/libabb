
#ifndef GATE_MESSAG_HPP_
#define GATE_MESSAG_HPP_


#include "../translate/message.hpp"
namespace adcloud {
namespace message {

class MGateClientIn :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_IN;
public:
	MGateClientIn();
	MGateClientIn(uint32_t len);
	virtual ~MGateClientIn();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	uint32_t cid;
};

class MGateClientOut :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_OUT;
public:
	MGateClientOut();
	MGateClientOut(uint32_t len);
	virtual ~MGateClientOut();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	uint32_t cid;
};

class MGateClientData :public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_MSG;
public:
	MGateClientData();
	MGateClientData(uint32_t len);
	virtual ~MGateClientData();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	uint32_t cid;
	void* data;
	int size;
	bool bneedfree_;
};





class MCloseClient:public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_CLOSE;
public:
	MCloseClient();
	MCloseClient(uint32_t len);
	virtual ~MCloseClient();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	unsigned cid;
};


class MScopeOp:public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_SCOPE;
public:
	MScopeOp();
	MScopeOp(uint32_t len);
	virtual ~MScopeOp();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string scope;
	unsigned cid;
	bool  badd;
};

class MScopeData:public translate::Message{
public:
	static const uint32_t TAG =  ADCLOUD_MESSAGE_TAG_SCOPE_DATA;
public:
	MScopeData();
	MScopeData(uint32_t len);
	virtual ~MScopeData();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter& buf);
	virtual void DecodeBody(common::BufferReader& buf);
public:
	std::string scope;
	void* data;
	int size;
	bool bneedfree_;
};

}
}


#endif /* GATE_MESSAG_HPP_ */
