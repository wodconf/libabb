
#include "app_message.hpp"

namespace adcloud {
namespace message {


/******************************/
MAppCloseClient::MAppCloseClient():translate::Message(TAG),client_id(0){

}
MAppCloseClient::MAppCloseClient(uint32_t len):translate::Message(TAG,len),client_id(0){

}
MAppCloseClient::~MAppCloseClient(){

}
uint32_t MAppCloseClient::GetLength(){
	return  gate_id.length()+1 + sizeof(client_id);
}
void MAppCloseClient::EncodeBody(common::BufferWriter& buf){
	buf << gate_id;
	buf.NET_WriteUint32(client_id);
}
void MAppCloseClient::DecodeBody(common::BufferReader& buf){
	buf >> gate_id;
	client_id = buf.HOST_ReadUint32();
}


/******************************/
MAppScopeOp::MAppScopeOp():translate::Message(TAG),badd(false),client_id(0){

}
MAppScopeOp::~MAppScopeOp(){

}
MAppScopeOp::MAppScopeOp(uint32_t len):translate::Message(TAG,len),badd(false),client_id(0){

}
uint32_t MAppScopeOp::GetLength(){
	return  gate_id.length()+1 + sizeof(client_id)+sizeof(badd)+scope.length()+1;
}
void MAppScopeOp::EncodeBody(common::BufferWriter& buf){
	buf << gate_id;
	buf.NET_WriteUint32(client_id);
	buf << badd;
	buf << scope;
}
void MAppScopeOp::DecodeBody(common::BufferReader& buf){
	buf >> gate_id;
	client_id = buf.HOST_ReadUint32();
	buf >> badd;
	buf >> scope;
}

/******************************/
MAppScopeData::MAppScopeData():translate::Message(TAG),bneedfree_(false),data(NULL),size(0){

}
MAppScopeData::MAppScopeData(uint32_t len):translate::Message(TAG,len),bneedfree_(false),data(NULL),size(0){

}
MAppScopeData::~MAppScopeData(){
	if(this->bneedfree_) delete [](char*)data;
}
uint32_t MAppScopeData::GetLength(){
	return this->size+scope.length()+1;
}
void MAppScopeData::EncodeBody(common::BufferWriter& buf){
	buf << scope;
	buf.Write(this->data,this->size);
}
void MAppScopeData::DecodeBody(common::BufferReader& buf){
	buf >> scope;
	this->data = new char[buf.DataSize()];
	this->size = buf.DataSize();
	this->bneedfree_ = true;
	buf.Read(this->data,this->size);
}


/******************************/
MAppClientData::MAppClientData():translate::Message(TAG),bneedfree_(false),data(NULL),size(0),client_id(0){

}
MAppClientData::MAppClientData(uint32_t len):translate::Message(TAG,len),bneedfree_(false),data(NULL),size(0),client_id(0){

}
MAppClientData::~MAppClientData(){
	if(this->bneedfree_) delete [](char*)data;
}
uint32_t MAppClientData::GetLength(){
	return gate_id.length()+1 + sizeof(client_id) + size;
}
void MAppClientData::EncodeBody(common::BufferWriter& buf){
	buf << gate_id;
	buf.NET_WriteUint32(client_id);
	buf.Write(this->data,this->size);
}
void MAppClientData::DecodeBody(common::BufferReader& buf){
	buf >> gate_id;
	client_id = buf.HOST_ReadUint32();
	this->data = new char[buf.DataSize()];
	this->size = buf.DataSize();
	this->bneedfree_ = true;
	buf.Read(this->data,this->size);
}

/******************************/
MAppClientIn::MAppClientIn():translate::Message(TAG),client_id(0){

}
MAppClientIn::MAppClientIn(uint32_t len):translate::Message(TAG,len),client_id(0){

}
MAppClientIn::~MAppClientIn(){

}
uint32_t MAppClientIn::GetLength(){
	return gate_id.length()+1 + sizeof(client_id);
}
void MAppClientIn::EncodeBody(common::BufferWriter& buf){
	buf << gate_id;
	buf.NET_WriteUint32(client_id);
}
void MAppClientIn::DecodeBody(common::BufferReader& buf){
	buf >> gate_id;
	client_id = buf.HOST_ReadUint32();
}

/******************************/
MAppClientOut::MAppClientOut():translate::Message(TAG),client_id(0){

}
MAppClientOut::MAppClientOut(uint32_t len):translate::Message(TAG,len),client_id(0){

}
MAppClientOut::~MAppClientOut(){

}
uint32_t MAppClientOut::GetLength(){
	return gate_id.length()+1 + sizeof(client_id);
}
void MAppClientOut::EncodeBody(common::BufferWriter& buf){
	buf << gate_id;
		buf.NET_WriteUint32(client_id);
}
void MAppClientOut::DecodeBody(common::BufferReader& buf){
	buf >> gate_id;
		client_id = buf.HOST_ReadUint32();
}
/******************************/
MAppOtherAppData::MAppOtherAppData():translate::Message(TAG),bneedfree_(false),data(NULL),size(0){

}
MAppOtherAppData::MAppOtherAppData(uint32_t len):translate::Message(TAG,len),bneedfree_(false),data(NULL),size(0){

}
MAppOtherAppData::~MAppOtherAppData(){
	if(this->bneedfree_) delete [](char*)data;
}
uint32_t MAppOtherAppData::GetLength(){
	return this->appid.length()+1 + size;
}
void MAppOtherAppData::EncodeBody(common::BufferWriter& buf){
	buf << appid;
	buf.Write(this->data,this->size);
}
void MAppOtherAppData::DecodeBody(common::BufferReader& buf){
	buf >> appid;
	this->data = new char[buf.DataSize()];
	this->size = buf.DataSize();
	this->bneedfree_ = true;
	buf.Read(this->data,this->size);
}

} /* namespace translate */
} /* namespace adcloud */
