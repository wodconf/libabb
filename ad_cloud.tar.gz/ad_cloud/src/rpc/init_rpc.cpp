

#include "init_rpc.hpp"
namespace adcloud {
namespace rpc {
void Init(){
	translate::Message::RegistCreator(rpc::MRpcRequest::TAG,translate::T_Creater<rpc::MRpcRequest>);
	translate::Message::RegistCreator(rpc::MRpcResponce::TAG,translate::T_Creater<rpc::MRpcResponce>);

	common::SerializationAble::RegistCreator(TRpcNull::TypeName,common::T_SerializationAbleCreator<TRpcNull>);
	common::SerializationAble::RegistCreator(TRpcError::TypeName,common::T_SerializationAbleCreator<TRpcError>);
	common::SerializationAble::RegistCreator(TRpcBool::TypeName,common::T_SerializationAbleCreator<TRpcBool>);
}
void Destroy(){

}
}}
