
#ifndef RPC_CLIENT_HPP_
#define RPC_CLIENT_HPP_

#include "../common/ref_object.hpp"
#include "../common/cond.hpp"
#include "../common/mutex.hpp"
#include "rpc_message.hpp"
#include <map>
#include <set>
#include <stdint.h>
#include "../common/notification.hpp"
namespace adcloud {
namespace rpc {
class RpcClient:public common::RefObject{
public:
	class ISend{
	public:
		virtual ~ISend(){}
		virtual bool ISend_Send(translate::Message& msg) = 0;
		virtual void ISend_Finish(){};
	};
	RpcClient(ISend* conn);
	~RpcClient();
	common::SerializationAble* Call(const std::string& method,common::SerializationAble* type, std::string& save_error,int timeout = 0);
	int AsycCall(const std::string& method,common::SerializationAble* type);
	common::SerializationAble* WaitResult(int seq,std::string& save_error,int timeout = 0);
	void OnClose();
	void OnMessage(MRpcResponce* rpcmsg);
	ISend* GetSender(){
		return send_;
	}
private:
	struct Event{
		common::SerializationAble* rsp;
		uint32_t seq;
		common::Notification notify;
	};
	common::Mutex mtx_;
	uint32_t seq_;
	typedef std::map<uint32_t ,Event*> EventMap;
	EventMap event_map_;
	ISend* send_;
};

}
}

#endif /* RPC_CLIENT_HPP_ */
