
#include "rpc_server.hpp"

#include "rpc_message.hpp"
namespace adcloud {
namespace rpc {

RpcServer::RpcServer():actor_(this) {
	// TODO Auto-generated constructor stub
	rpc_svr_ = new RpcService();
}

RpcServer::~RpcServer() {
	// TODO Auto-generated destructor stub
}
bool RpcServer::Bind(const abb::net::IPAddr& addr,int *save_error){
	return actor_.Bind(addr,save_error);
}
void RpcServer::Start(){
	this->actor_.SetEnable(true);
	rpc_svr_->Start();
}
void RpcServer::Stop(){
	this->actor_.SetEnable(false);
	rpc_svr_->Stop();
}
void RpcServer::L_Connection_OnMessage(translate::Connection* self,translate::Message*msg){
	if(msg->GetTag() == rpc::MRpcRequest::TAG){
		rpc_svr_->AsycRpcExecute(static_cast<rpc::MRpcRequest*>(msg));
	}
}
void RpcServer::L_Connection_OnClose(translate::Connection* self){
	self->UnRef();
}
void RpcServer::L_Acceptor_OnConnection(translate::Connection* conn){
	conn->SetListner(this);
}
} /* namespace queue */
} /* namespace adcloud */
