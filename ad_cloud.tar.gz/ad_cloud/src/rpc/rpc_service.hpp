

#ifndef ADCLOUD_RPC_SERVICE_HPP_
#define ADCLOUD_RPC_SERVICE_HPP_

#include <string>
#include <map>
#include "abb/base/thread_pool.hpp"
#include "../common/rw_lock.hpp"
#include "rpc_message.hpp"
namespace adcloud {
namespace rpc {
class RpcService {
public:
	typedef common::SerializationAble*(*rpc_fn)(void* arg,common::SerializationAble*req);
public:
	class IRpcFunction{
	public:
		virtual ~IRpcFunction(){};
		virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& save_error) = 0;
		virtual void Finsh(common::SerializationAble* res) = 0;
	};
	RpcService();
	~RpcService();
	void SetNumDispatchThread(int num){
		pool.SetNumThread(num);
	}
	bool RegistFunction(const std::string& name,IRpcFunction* func);
	void UnRegistFunction(const std::string& name,IRpcFunction* func);
	void AsycRpcExecute(MRpcRequest* m);
	void SyncRpcExecute(MRpcRequest* m);
	void Start();
	void Stop();
private:
	IRpcFunction* GetFunction(const std::string& name);
private:
	abb::base::ThreadPool pool;
	typedef std::map<std::string,IRpcFunction*> FuncMap;
	FuncMap func_map_;
	common::RWLock rwlocker_;
};

} /* namespace rpc */
} /* namespace adcloud */

#endif /* RPC_SERVER_HPP_ */
