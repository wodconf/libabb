
#include "rpc_service.hpp"
#include "../common/log.hpp"
#include "../translate/connection.hpp"
namespace adcloud {
namespace rpc {

RpcService::RpcService() {

}
RpcService::~RpcService() {

}
void RpcService::Start(){
	pool.SetNumThread(16);
	pool.Start();
}
void RpcService::Stop(){
	pool.Stop();
	pool.Wait();
}
bool RpcService::RegistFunction(const std::string& name,IRpcFunction* func){
	common::RWLock::WLocker l(this->rwlocker_);
	if(this->func_map_.count(name) > 0){
		return false;
	}
	this->func_map_[name] = func;
	return true;
}
void RpcService::UnRegistFunction(const std::string& name,IRpcFunction* func){
	common::RWLock::WLocker l(this->rwlocker_);
	this->func_map_.erase(name);
}
void RpcService::AsycRpcExecute(MRpcRequest* m){
	m->Ref();
	m->svr_ = this;
	this->pool.Execute(m);
}
void RpcService::SyncRpcExecute(MRpcRequest* req){
	this->rwlocker_.RLock();
	IRpcFunction* func = this->GetFunction(req->method_name);
	if(func ){
		MRpcResponce rsp;
		rsp.seq = req->seq;
		std::string err;
		common::SerializationAble*type = func->CallFunction(req->GetType(),err);
		this->rwlocker_.RUnLock();
		if(type == NULL && !err.empty()){
			rpc::TRpcError* e = new rpc::TRpcError();
			e->desc = err;
			rsp.SetType(e);
		}else{
			rsp.SetType(type);
		}
		req->GetConnection()->Send(rsp);
		func->Finsh(type);
	}else{
		this->rwlocker_.RUnLock();
		MRpcResponce rsp;
		TRpcError* e = new TRpcError();
		LOG(WARN) << "methos.not.service.name="<<req->method_name << req->method_name.length();
		e->desc = "METHOD_NOT_SERVICE";
		rsp.SetType(e);
		rsp.seq = req->seq;
		req->GetConnection()->Send(rsp);
	}
}
RpcService::IRpcFunction* RpcService::GetFunction(const std::string& name){
	FuncMap::iterator iter = this->func_map_.find(name);
	if(iter != func_map_.end()){
		return iter->second;
	}
	return NULL;
}
/*
void RpcService::PrintMap(){
	common::RWLock::RLocker r(this->rwlocker_);
	//AD_CLOUD_INFO("RpcService::PrintMap: %s",".");
	for(FuncMap::iterator iter = this->func_map_.begin();iter!= func_map_.end();iter++){
		//AD_CLOUD_INFO("\t\t\t name: %s",iter->first.c_str());
	}
	//AD_CLOUD_INFO("RpcService::PrintMap: %s","end");
}*/
} /* namespace translate */
} /* namespace adcloud */
