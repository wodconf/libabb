/*
 * rpc_server.hpp
 *
 *  Created on: 2014-5-21
 *      Author: wd
 */

#ifndef AD_CLOUD_RPC_SERVER_HPP_
#define AD_CLOUD_RPC_SERVER_HPP_
#include "../translate/acceptor.hpp"
#include "../translate/connection.hpp"
#include "rpc_service.hpp"
namespace adcloud {
namespace rpc {
class RpcServer:public translate::Acceptor::Listener,translate::Connection::Listener {
public:
	RpcServer();
	~RpcServer();
	bool Bind(const abb::net::IPAddr& addr,int *save_error);
	void Start();
	void Stop();
	virtual void L_Connection_OnMessage(translate::Connection* self,translate::Message*msg);
	virtual void L_Connection_OnClose(translate::Connection* self);
	virtual void L_Acceptor_OnConnection(translate::Connection* conn);
	RpcService* GetRpcService(){
		return rpc_svr_;
	}
private:
	RpcService* rpc_svr_;
	translate::Acceptor actor_;
};

} /* namespace queue */
} /* namespace adcloud */

#endif /* RPC_SERVER_HPP_ */
