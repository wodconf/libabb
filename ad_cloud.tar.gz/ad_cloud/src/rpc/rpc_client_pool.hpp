/*
 * rpc_client_pool.hpp
 *
 *  Created on: 2014-5-29
 *      Author: wd
 */

#ifndef RPC_CLIENT_POOL_HPP_
#define RPC_CLIENT_POOL_HPP_

#include "../translate/client_pool.hpp"
#include "rpc_client.hpp"

namespace adcloud {
namespace rpc {

class RpcClientPool:public translate::ClientPool::Listener {
public:
	RpcClientPool();
	~RpcClientPool();
	common::SerializationAble* Call(const std::string& addr,
			const std::string& method,
			common::SerializationAble* type,
			std::string& save_error,
			int timeout = 0);
	void CloseRpcClient(const std::string& addr);
	virtual void L_ClientPool_ConnectionReset(const std::string& addr);
	virtual void L_ClientPool_ConnectionMessage(const std::string& addr,translate::Message* msg);
private:
	rpc::RpcClient*GetRpcClient(const std::string& addr,bool bcreate=false);
private:
	class RpcClientSender:public rpc::RpcClient::ISend{
	public:
		RpcClientSender(translate::ClientPool* p,const std::string& addr):addr_(addr),pool_(p){};
		virtual ~RpcClientSender(){};
		virtual bool ISend_Send(translate::Message& msg){
			return pool_->SendToAddr(msg,addr_);
		}
		virtual void ISend_Finish(){
			delete this;
		}
		std::string addr_;
		translate::ClientPool* pool_;
	};
private:
	typedef std::map<std::string,rpc::RpcClient*> RpcClientMap;
	common::Mutex mtx_;
	RpcClientMap rpc_cli_map_;
	translate::ClientPool client_pool_;
};
} /* namespace monprxoy */
} /* namespace adcloud */

#endif /* RPC_CLIENT_POOL_HPP_ */
