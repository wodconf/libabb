

#ifndef AD_CLOUD_RPC_MESSAGE_HPP_
#define AD_CLOUD_RPC_MESSAGE_HPP_

#include <string>
#include <map>
#include "../translate/message.hpp"
#include "../common/serialization_able.hpp"
#include <abb/base/callback.hpp>
namespace adcloud {
namespace rpc {
class RpcService;
class MRpcRequest :public abb::base::CallBack,public translate::Message{
public:
	static const int TAG =  ADCLOUD_MESSAGE_TAG_RPC_REQ;
public:
	MRpcRequest();
	MRpcRequest(uint32_t len);
	virtual ~MRpcRequest();
	void SetType(common::SerializationAble*  type);
	common::SerializationAble* GetType();
	virtual void Call();
	RpcService* svr_;
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
public:
	std::string method_name;
	unsigned seq;
private:
	common::SerializationAble* type;
};
class MRpcResponce :public translate::Message{
public:
	static const int TAG =  ADCLOUD_MESSAGE_TAG_RPC_RSP;
public:
	MRpcResponce();
	MRpcResponce(uint32_t len);
	virtual ~MRpcResponce();
	void SetType(common::SerializationAble*  type);
	common::SerializationAble* GetType();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
public:
	unsigned seq;
private:
	common::SerializationAble* type;
};
class TRpcNull :public common::SerializationAble{
public:
	static const char *  TypeName;
	TRpcNull():common::SerializationAble(TypeName){}
	virtual ~TRpcNull(){}
private:
	virtual uint32_t GetLength(){return 0;}
	virtual void EncodeBody(common::BufferWriter &buf){

	}
	virtual void DecodeBody(common::BufferReader &buf){

	}
};
class TRpcBool :public common::SerializationAble{
public:
	static const char *  TypeName;
	TRpcBool():common::SerializationAble(TypeName),success(true){}
	virtual ~TRpcBool(){}
	bool success;
private:
	virtual uint32_t GetLength(){return sizeof(success);}
	virtual void EncodeBody(common::BufferWriter &buf){
		buf << success;
	}
	virtual void DecodeBody(common::BufferReader &buf){
		buf >> success;
	}
};
class TRpcError :public common::SerializationAble{
public:
	static const char * TypeName;
	TRpcError():common::SerializationAble(TypeName){}
	virtual ~TRpcError(){}
	std::string desc;
private:
	virtual uint32_t GetLength(){
		return desc.size()+1;
	}
	virtual void EncodeBody(common::BufferWriter &buf){
		buf << desc;
	}
	virtual void DecodeBody(common::BufferReader &buf){
		buf >> desc;
	}
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* RPC_MESSAGE_HPP_ */
