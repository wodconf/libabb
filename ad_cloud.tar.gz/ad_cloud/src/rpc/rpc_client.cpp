
#include "rpc_client.hpp"
#include "../common/log.hpp"
#include "../common/time.hpp"
#include <errno.h>
#include <cassert>

#define RPC_CLIENT_MAX_TIMEOUT 10000

namespace adcloud {
namespace rpc {

RpcClient::RpcClient(ISend* conn):send_(conn),seq_(0) {
}

RpcClient::~RpcClient() {
	this->OnClose();
	if(this->send_){
		this->send_->ISend_Finish();
	}
}
common::SerializationAble* RpcClient::Call(const std::string& method,common::SerializationAble*type, std::string& save_error,int timeout){
	int seq = AsycCall(method,type);
	if(seq < 0){
		save_error = "SendFail";
		return NULL;
	}
	this->Ref();
	common::SerializationAble* ret = WaitResult(seq,save_error,timeout);
	this->UnRef();
	return ret;
}
int RpcClient::AsycCall(const std::string& method,common::SerializationAble* type){
	if(!send_)return -1;

	MRpcRequest req;
	req.method_name = method;
	req.seq = __sync_add_and_fetch(&seq_,1);
	req.SetType(type);

	Event *ev = new Event();
	ev->seq = req.seq;
	ev->rsp = NULL;
	{
		common::Mutex::Locker l(mtx_);
		event_map_[ev->seq] = ev;
		if( !this->send_->ISend_Send(req) ){
			event_map_.erase(req.seq);
			delete ev;
			return -1;
		}
	}
	return ev->seq;
}
common::SerializationAble* RpcClient::WaitResult(int seq,std::string& save_error,int timeout){
	Event *ev = NULL;
	{
		common::Mutex::Locker l(mtx_);
		EventMap::iterator iter = event_map_.find(seq);
		if(iter == event_map_.end()){
			save_error = "NO Seq";
			return NULL;
		}else{
			ev = iter->second;
		}
	}
	if(timeout <= 0){
		timeout = RPC_CLIENT_MAX_TIMEOUT;
	}
	if( ! ev->notify.WaitTimeout(timeout) ){
		save_error = "TIMEOUT";
	}
	{
		common::Mutex::Locker l(mtx_);
		EventMap::iterator iter = event_map_.find(seq);
		if(iter != event_map_.end())
			event_map_.erase(iter);
	}
	common::SerializationAble* rsp = ev->rsp;
	delete ev;
	if(rsp){
		if(rsp->GetTypeName() == rpc::TRpcError::TypeName){
			save_error = static_cast<rpc::TRpcError*>(rsp)->desc;
			rsp->UnRef();
			rsp = NULL;
		}
	}
	return rsp;
}
void RpcClient::OnMessage(MRpcResponce* rpcmsg){
	common::Mutex::Locker l(mtx_);
	EventMap::iterator iter = this->event_map_.find(rpcmsg->seq);
	if(event_map_.end() == iter){
		return;
	}
	iter->second->rsp = rpcmsg->GetType();
	iter->second->notify.Notify();
}
void RpcClient::OnClose(){
	rpc::TRpcError* err = new rpc::TRpcError();
	err->desc = "NET_ERROR";
	common::Mutex::Locker l(mtx_);
	EventMap::iterator iter = this->event_map_.begin();
	for(;iter != this->event_map_.end();iter++){
		if(iter->second->rsp){
			continue;
		}
		err->Ref();
		iter->second->rsp = err;
		iter->second->notify.Notify();
	}
	err->UnRef();
}
} /* namespace rpc */
} /* namespace adcloud */
