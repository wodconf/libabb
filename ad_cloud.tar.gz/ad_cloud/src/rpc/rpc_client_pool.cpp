/*
 * rpc_client_pool.cpp
 *
 *  Created on: 2014-5-29
 *      Author: wd
 */

#include "rpc_client_pool.hpp"

namespace adcloud {
namespace rpc {

RpcClientPool::RpcClientPool():client_pool_(this) {
}

RpcClientPool::~RpcClientPool() {
}
common::SerializationAble* RpcClientPool::Call(const std::string& addr,
		const std::string& method,
		common::SerializationAble* type,
		std::string& save_error,
		int timeout){
	rpc::RpcClient* cli =this->GetRpcClient(addr,true);
	common::SerializationAble* ret = cli->Call(method,type,save_error,timeout);
	cli->UnRef();
	return ret;
}
void RpcClientPool::L_ClientPool_ConnectionReset(const std::string& addr){
	rpc::RpcClient* cli = this->GetRpcClient(addr);
	if(cli){
		cli->OnClose();
		cli->UnRef();
	}

}
void RpcClientPool::CloseRpcClient(const std::string& addr){
	common::Mutex::Locker l(mtx_);
	RpcClientMap::iterator iter = this->rpc_cli_map_.find(addr);
	if(iter != rpc_cli_map_.end()){
		rpc::RpcClient::ISend*s = iter->second->GetSender();
		if( iter->second->UnRef() ){
			delete s;
		}
		rpc_cli_map_.erase(iter);
	}
}
void RpcClientPool::L_ClientPool_ConnectionMessage(const std::string& addr,translate::Message* msg){
	if(msg->GetTag() == rpc::MRpcResponce::TAG){
		rpc::RpcClient* cli = this->GetRpcClient(addr);
		if(cli){
			cli->OnMessage(static_cast<rpc::MRpcResponce*>(msg));
			cli->UnRef();
		}
	}
}
rpc::RpcClient* RpcClientPool::GetRpcClient(const std::string& addr,bool bcreate){
	common::Mutex::Locker l(mtx_);
	RpcClientMap::iterator iter = this->rpc_cli_map_.find(addr);
	if(iter != rpc_cli_map_.end()){
		iter->second->Ref();
		return iter->second ;
	}else if(bcreate){
		rpc::RpcClient* cli = new rpc::RpcClient( new RpcClientSender(&this->client_pool_,addr));
		cli->Ref();
		this->rpc_cli_map_[addr] = cli;
		return cli;
	}else{
		return NULL;
	}
}

} /* namespace monprxoy */
} /* namespace adcloud */
