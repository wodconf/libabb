

#include "rpc_message.hpp"
#include "rpc_service.hpp"
namespace adcloud {
namespace rpc {
static TRpcNull t_rpc_null;
/******************************/
MRpcRequest::MRpcRequest():translate::Message(TAG),type( &t_rpc_null),seq(0),svr_(NULL){

}
MRpcRequest::MRpcRequest(uint32_t len):translate::Message(TAG,len),type( &t_rpc_null),seq(0),svr_(NULL){

}
MRpcRequest::~MRpcRequest(){

}
void MRpcRequest::Call(){
	this->svr_->SyncRpcExecute(this);
	this->UnRef();
}
uint32_t MRpcRequest::GetLength(){
	uint32_t size =   sizeof(seq)+method_name.length()+1;
	size += type->Length();
	return size;
}
void MRpcRequest::EncodeBody(common::BufferWriter& buf){
	buf.NET_WriteUint32(seq);
	buf << method_name;
	type->Encode(buf);
}
void MRpcRequest::DecodeBody(common::BufferReader& buf){
	seq = buf.HOST_ReadUint32();
	buf >> method_name;
	type = common::SerializationAble::Decode(buf);
	if(!type){
		type = &t_rpc_null;
	}
}
void MRpcRequest::SetType(common::SerializationAble*  t){
	if(!t){
		return ;
	}
	type = t;
}
common::SerializationAble* MRpcRequest::GetType(){
	if(type->GetTypeName() == TRpcNull::TypeName){
		return NULL;
	}
	return type;
}
/******************************/
MRpcResponce::MRpcResponce():translate::Message(TAG),type( &t_rpc_null),seq(0){

}
MRpcResponce::MRpcResponce(uint32_t len):translate::Message(TAG,len),type( &t_rpc_null),seq(0){

}
MRpcResponce::~MRpcResponce(){

}
void MRpcResponce::SetType(common::SerializationAble*  t){
	if(!t){
		return ;
	}
	type = t;
}
common::SerializationAble* MRpcResponce::GetType(){
	if(type->GetTypeName() == TRpcNull::TypeName){
		return NULL;
	}
	return type;
}
uint32_t MRpcResponce::GetLength(){
	uint32_t size =   sizeof(seq);
	size += type->Length();
	return size;
}
void MRpcResponce::EncodeBody(common::BufferWriter& buf){
	buf.NET_WriteUint32(seq);
	type->Encode(buf);
}
void MRpcResponce::DecodeBody(common::BufferReader& buf){
	seq = buf.HOST_ReadUint32();
	type = common::SerializationAble::Decode(buf);
	if(!type){
		type = &t_rpc_null;
	}
}

const char* TRpcNull::TypeName = "adcloud.rpc.TRpcNull";
const char* TRpcError::TypeName = "adcloud.rpc.TRpcError";
const char* TRpcBool::TypeName = "adcloud.rpc.TRpcBool";
} /* namespace rpc */
} /* namespace adcloud */
