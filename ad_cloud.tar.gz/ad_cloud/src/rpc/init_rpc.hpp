#ifndef AD_CLOUD_INIT_RPC_H_
#define AD_CLOUD_INIT_RPC_H_

#include "../rpc/rpc_message.hpp"

namespace adcloud {
namespace rpc {
	void Init();
	void Destroy();
}}

#endif
