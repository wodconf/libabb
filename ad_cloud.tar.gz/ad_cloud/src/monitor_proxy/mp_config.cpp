/*
 * mp_config.cpp
 *
 *  Created on: 2014-5-26
 *      Author: wd
 */

#include "mp_config.hpp"
#include "../common/string_tool.hpp"
#include "../common/log.hpp"
namespace adcloud {
namespace monproxy{

Config::Config() {
	// TODO Auto-generated constructor stub

}

Config::~Config() {
	// TODO Auto-generated destructor stub
}
bool Config::Parse(common::ArgParse& arg_parse){
	std::string val;
	if(! arg_parse.GetValue("addr",addr) ){
		LOG(ERROR) << "ARG (adrr) NOT Exist";
		return false;
	}
	if( arg_parse.GetValue("mons",val) ){
		common::StringTool::Split(val,",",this->mon_addr_list);
	}else{
		LOG(ERROR) << "arg.(mons).not.exist";
		return false;
	}
	return true;
}
} /* namespace monprxoy */
} /* namespace adcloud */
