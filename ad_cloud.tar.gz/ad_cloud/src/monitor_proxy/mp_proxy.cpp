
#include "mp_proxy.hpp"
#include "mp_config.hpp"
#include "../type/type_get_gate.hpp"
#include <cassert>
namespace adcloud {
namespace monproxy {
class FGetMaster:public rpc::RpcService::IRpcFunction{
public:
	FGetMaster(MonitorProxy* mm):self(mm){}
	virtual ~FGetMaster(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		common::SerializationAble* ret = self->client_->CallGetFreeMaster(static_cast<type::TGetFreeMasterReq*>(arg),err);
		arg->UnRef();
		return ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	MonitorProxy* self;
};
class FGetGate:public rpc::RpcService::IRpcFunction{
public:
	FGetGate(MonitorProxy* mm):self(mm){}
	virtual ~FGetGate(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		if(arg) arg->UnRef();
		type::TGetGateResponce* rsp = new type::TGetGateResponce();
		rsp->addr_list.push_back("127.0.0.1:9200");
		return rsp;
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	MonitorProxy* self;
};

MonitorProxy::MonitorProxy():cfg_(NULL),client_(NULL),svr_(NULL),gm_fn_(NULL),gg_fn_(NULL) {
	// TODO Auto-generated constructor stub
}

MonitorProxy::~MonitorProxy() {
}
bool MonitorProxy::Init(Config* cfg){
	cfg_ = cfg;
	abb::net::IPAddr addr;
	if( ! addr.SetByString(cfg->addr) ){
		LOG(WARN) << "format fail" << cfg->addr ;
		return false;
	}
	svr_ = new rpc::RpcServer();
	int error;
	if( ! svr_->Bind(addr,&error) ){
		LOG(WARN) << "bind fail"  <<  cfg->addr << strerror(error);
		delete svr_;
		return false;
	}
	gm_fn_ = new FGetMaster(this);
	gg_fn_ = new FGetGate(this);
	svr_->GetRpcService()->RegistFunction("GetMaster",this->gm_fn_);
	svr_->GetRpcService()->RegistFunction("GetGate",this->gg_fn_);
	client_ = new mon::MonitorClient();
	client_->SetAddrs(cfg->mon_addr_list);

	return true;
}
void MonitorProxy::Start(){
	this->svr_->Start();
	timer_.Loop();
}
} /* namespace monraft */
} /* namespace adcloud */
