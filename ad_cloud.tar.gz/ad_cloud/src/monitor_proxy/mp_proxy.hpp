

#ifndef MP_PROXY_HPP_
#define MP_PROXY_HPP_

#include "../monitor/mm_client.hpp"
#include "../rpc/rpc_server.hpp"
#include "../common/timer.hpp"
#include "mp_config.hpp"

namespace adcloud {
namespace monproxy{

class FGetMaster;
class FGetGate;

class MonitorProxy {
public:
	MonitorProxy();
	~MonitorProxy();
	bool Init(Config* cfg);
	void Start();
private:
	mon::MonitorClient* client_;
	Config* cfg_;
	common::Timer timer_;
	rpc::RpcServer* svr_;
	friend class FGetMaster;
	friend class FGetGate;
	FGetMaster* gm_fn_;
	FGetGate* gg_fn_;
};

} /* namespace monraft */
} /* namespace adcloud */

#endif /* MP_PROXY_HPP_ */
