
#ifndef ADCLOUD_PROXY_MP_CONFIG_HPP_
#define ADCLOUD_PROXY_MP_CONFIG_HPP_

#include <stdint.h>
#include <string>
#include <vector>
#include "../common/arg_parse.hpp"
namespace adcloud {
namespace monproxy{

class Config {
public:
	Config();
	~Config();
	bool Parse( common::ArgParse& arg_parse);
	std::vector<std::string> mon_addr_list;
	std::string addr;
};

} /* namespace monprxoy */
} /* namespace adcloud */

#endif /* MP_CONFIG_HPP_ */
