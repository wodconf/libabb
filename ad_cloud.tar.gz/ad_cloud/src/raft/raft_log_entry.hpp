
#ifndef AD_CLOUD_RAFT_RAFT_LOG_ENTRY_HPP_
#define AD_CLOUD_RAFT_RAFT_LOG_ENTRY_HPP_

#include <stdint.h>
#include <vector>
#include "event.hpp"
#include "../common/serialization_able.hpp"
#include "commond.hpp"
namespace adcloud {
namespace raft {
class RaftLog;
class RaftLogEntry :public common::SerializationAble{
public:
	static const char* TypeName;
public:
	RaftLogEntry();
	RaftLogEntry(RaftLog* log,uint64_t index,uint64_t term,Commond*cmd,Event* ev);
	~RaftLogEntry();
	RaftLog* log_;
	uint64_t index_;
	uint64_t term_;
	Commond* cmd_;
	Event* ev_;
	int position;
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};



typedef std::vector<RaftLogEntry*> LogEntryArray;

}
}

#endif /* RAFT_LOG_ENTRY_HPP_ */
