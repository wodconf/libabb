
#ifndef ADCLOUD_RAFT_I_TRANSLATE_HPP_
#define ADCLOUD_RAFT_I_TRANSLATE_HPP_

#include "append_entries.hpp"
#include "vote.hpp"
#include "snapshot.hpp"
namespace adcloud{
namespace raft{
class RaftServer;
class Peer;
class ITranslate{
public:
	virtual ~ITranslate(){}
	virtual AppendEntriesResponce* SendAppendEntries( RaftServer* svr, Peer& peer,AppendEntriesRequest&req) = 0;
	virtual VoteResponce* SendVoteRequest( RaftServer* svr, Peer& peer,VoteRequest&req) = 0;
	virtual SnapshotRecoveryResponce* SendSnapshotRecovery( RaftServer* svr, Peer& peer,SnapshotRecoveryRequest&req) = 0;
	virtual SnapshotResponce* SendSnapshotRequest( RaftServer* svr, Peer& peer,SnapshotRequest&req) = 0;
};
}
}


#endif /* I_TRANSLATE_HPP_ */
