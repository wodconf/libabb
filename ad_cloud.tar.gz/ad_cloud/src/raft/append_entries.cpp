
#include "append_entries.hpp"
#include "../common/log.hpp"
#include <cassert>
namespace adcloud {
namespace raft {
const char* AppendEntriesRequest::TypeName = "adcloud.raft.AppendEntriesRequest";
AppendEntriesRequest::AppendEntriesRequest()
:common::SerializationAble(TypeName),
 term(0),
 PrevLogIndex(0),
 PrevLogTerm(0),
 CommitIndex(0)
{

}
AppendEntriesRequest::AppendEntriesRequest(uint64_t term,
		uint64_t PrevLogIndex,
		uint64_t PrevLogTerm,
		uint64_t CommitIndex,
		const std::string& LeaderName)
:common::SerializationAble(TypeName),
 term(term),
 PrevLogIndex(PrevLogIndex),
 PrevLogTerm(PrevLogTerm),
 CommitIndex(CommitIndex),
 LeaderName(LeaderName)
{

}
AppendEntriesRequest::AppendEntriesRequest(uint64_t term,
		uint64_t PrevLogIndex,
		uint64_t PrevLogTerm,
		uint64_t CommitIndex,
		const std::string& LeaderName,
		const LogEntryArray& arr)
:common::SerializationAble(TypeName),
 term(term),
 PrevLogIndex(PrevLogIndex),
 PrevLogTerm(PrevLogTerm),
 CommitIndex(CommitIndex),
 LeaderName(LeaderName),
 Entries(arr)
{
}

AppendEntriesRequest::~AppendEntriesRequest() {

}
uint32_t AppendEntriesRequest::GetLength(){
	int size = 0;
	size+= sizeof(term);
	size+= sizeof(PrevLogIndex);
	size+= sizeof(PrevLogTerm);
	size+= sizeof(CommitIndex);
	size+= LeaderName.size()+1;
	size+= sizeof(uint32_t);
	for(int i=0;i<Entries.size();i++){
		size += Entries[i]->Length();
	}
	return size;
}
void AppendEntriesRequest::EncodeBody(common::BufferWriter &buf){
	buf.NET_WriteUint64(term);
	buf.NET_WriteUint64(PrevLogIndex);
	buf.NET_WriteUint64(PrevLogTerm);
	buf.NET_WriteUint64(CommitIndex);
	buf << LeaderName;
	buf.NET_WriteUint32(uint32_t(Entries.size()));
	for(int i=0;i<Entries.size();i++){
		uint32_t sz = Entries[i]->Length();
		uint32_t pre = buf.FreeSize();
		Entries[i]->Encode(buf);
		assert( ( pre - buf.FreeSize() ) == sz);
	}
}
void AppendEntriesRequest::DecodeBody(common::BufferReader &buf){
	term = buf.HOST_ReadUint64();
	PrevLogIndex = buf.HOST_ReadUint64();
	PrevLogTerm = buf.HOST_ReadUint64();
	CommitIndex = buf.HOST_ReadUint64();
	buf >> LeaderName;
	uint32_t size = buf.HOST_ReadUint32();
	for(int i=0;i<size;i++){
		RaftLogEntry* entry = static_cast<RaftLogEntry*>(common::SerializationAble::Decode(buf));
		assert(entry);
		Entries.push_back(entry);
	}
}


const char* AppendEntriesResponce::TypeName = "adcloud.raft.AppendEntriesResponce";
AppendEntriesResponce::AppendEntriesResponce()
:Term(0),
 Index(0),
 Success(false),
 CommitIndex(0),
 append(false),
 common::SerializationAble(TypeName){

}
AppendEntriesResponce::AppendEntriesResponce(uint64_t Term,uint64_t Index,bool Success,uint64_t CommitIndex)
:Term(Term),
 Index(Index),
 Success(Success),
 CommitIndex(CommitIndex),
 append(false),
 common::SerializationAble(TypeName){

}

AppendEntriesResponce::~AppendEntriesResponce() {
}
uint32_t AppendEntriesResponce::GetLength(){
	return sizeof(Term)+sizeof(Index)+sizeof(Success)+sizeof(CommitIndex);
}
void AppendEntriesResponce::EncodeBody(common::BufferWriter &buf){
	buf.NET_WriteUint64(Term);
	buf.NET_WriteUint64(Index);
	buf.NET_WriteUint64(CommitIndex);
	buf << Success;
}
void AppendEntriesResponce::DecodeBody(common::BufferReader &buf){
	Term = buf.HOST_ReadUint64();
	Index = buf.HOST_ReadUint64();
	CommitIndex = buf.HOST_ReadUint64();
	buf >> Success;
}
} /* namespace raft */
} /* namespace adcloud */
