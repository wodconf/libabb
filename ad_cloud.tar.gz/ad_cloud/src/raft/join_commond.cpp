
#include "join_commond.hpp"
#include "raft_server.hpp"
namespace adcloud {
namespace raft {
JoinCommond::JoinCommond()
:Commond(CmdName) {

}
JoinCommond::~JoinCommond() {
}
const char* JoinCommond::CmdName = "adcloud.raft.internal.JoinCommond";
} /* namespace translate */
} /* namespace adcloud */
