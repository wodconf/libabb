
#ifndef I_STATE_MACHINE_HPP_
#define I_STATE_MACHINE_HPP_
#include "../common/buffer.hpp"
namespace adcloud {
namespace raft {

class IStateMachine {
public:
	virtual ~IStateMachine(){}
	virtual bool Save(common::Buffer& buf) = 0;
	virtual bool Recovery(common::Buffer& buf) =0;
};

} /* namespace monraft */
} /* namespace adcloud */

#endif /* I_STATE_MACHINE_HPP_ */
