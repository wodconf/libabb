
#ifndef APPEND_ENTRIES_REQUEST_HPP_
#define APPEND_ENTRIES_REQUEST_HPP_

#include <vector>
#include "raft_log_entry.hpp"
#include "../common/serialization_able.hpp"
namespace adcloud {
namespace raft {

class AppendEntriesRequest :public common::SerializationAble{
public:
	static const char* TypeName;
public:
	AppendEntriesRequest();
	AppendEntriesRequest(uint64_t term,
				uint64_t PrevLogIndex,
				uint64_t PrevLogTerm,
				uint64_t CommitIndex,
				const std::string& LeaderName);
	AppendEntriesRequest(uint64_t term,
			uint64_t PrevLogIndex,
			uint64_t PrevLogTerm,
			uint64_t CommitIndex,
			const std::string& LeaderName,
			const LogEntryArray& arr);
	~AppendEntriesRequest();
	uint64_t term;
	uint64_t PrevLogIndex;
	uint64_t PrevLogTerm;
	uint64_t CommitIndex;
	std::string LeaderName;
	LogEntryArray Entries;
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};

class AppendEntriesResponce:public common::SerializationAble {
public:
	static const char* TypeName ;
public:
	AppendEntriesResponce();
	AppendEntriesResponce(uint64_t Term,uint64_t Index,bool Success,uint64_t CommitIndex);
	~AppendEntriesResponce();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
public:
	uint64_t Term;
	uint64_t Index;
	bool Success;
	uint64_t CommitIndex;
	//
	std::string peer;
	bool append;
};
} /* namespace raft */
} /* namespace adcloud */

#endif /* APPEND_ENTRIES_REQUEST_HPP_ */
