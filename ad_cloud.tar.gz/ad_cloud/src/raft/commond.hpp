
#ifndef AD_CLOUD_RAFT_COMMOND_HPP_
#define AD_CLOUD_RAFT_COMMOND_HPP_

#include <map>

#include <string>
#include "../common/serialization_able.hpp"

namespace adcloud {
namespace raft {
class RaftServer;
class Commond :public common::SerializationAble{
public:
	static void RegistCreator(const std::string& name,type_createor fn);
	static bool IsCommond(common::SerializationAble* sa);
public:
	Commond(const std::string& cmd_name);
	virtual ~Commond();
	std::string Name();
	virtual common::SerializationAble* Apply(RaftServer*,std::string *save_error,bool need_return) = 0;
};

}
}

#endif /* I_COMMOND_HPP_ */
