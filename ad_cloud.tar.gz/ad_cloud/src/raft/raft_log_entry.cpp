
#include "raft_log_entry.hpp"
#include "../common/log.hpp"
#include <cassert>
namespace adcloud {
namespace raft {
RaftLogEntry::RaftLogEntry():log_(NULL),index_(0),term_(0),position(0),cmd_(NULL),ev_(NULL),common::SerializationAble(TypeName){

}
RaftLogEntry::RaftLogEntry(RaftLog* log,uint64_t index,uint64_t term,Commond*cmd,Event* ev)
:log_(log),index_(index),term_(term),cmd_(cmd),ev_(ev),position(0),common::SerializationAble(TypeName){
	ev_->Ref();
}

RaftLogEntry::~RaftLogEntry() {
	if(ev_)ev_->notify_.Notify();
	if(ev_)ev_->UnRef();
}
uint32_t RaftLogEntry::GetLength(){
	return sizeof(index_)+sizeof(term_)+cmd_->Length();
}
void RaftLogEntry::EncodeBody(common::BufferWriter &buf){
	buf.NET_WriteUint64(index_);
	buf.NET_WriteUint64(term_);
	uint32_t pre = buf.FreeSize();
	uint32_t sz = cmd_->Length();
	cmd_->Encode(buf);
	if(( pre - buf.FreeSize() ) != sz){
		LOG(WARN) << cmd_->Name() << sz << ":" << pre - buf.FreeSize();
		assert( ( pre - buf.FreeSize() ) == sz);
	}
}
void RaftLogEntry::DecodeBody(common::BufferReader &buf){
	index_ = buf.HOST_ReadUint64();
	term_ = buf.HOST_ReadUint64();
	cmd_ = static_cast<Commond*>( common::SerializationAble::Decode(buf) );
}
const char* RaftLogEntry::TypeName = "adcloud.raft.RaftLogEntry";
} /* namespace raft */
} /* namespace adcloud */
