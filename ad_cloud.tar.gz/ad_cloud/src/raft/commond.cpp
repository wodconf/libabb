
#include "commond.hpp"

namespace adcloud {
namespace raft {

#define CMD_PRE "_CMD_"
#define CMD_SIZE 5
#define GET_CMD_TYPE_NAME(cmdname) CMD_PRE+(cmdname)
void Commond::RegistCreator(const std::string& name,type_createor fn){
	SerializationAble::RegistCreator(GET_CMD_TYPE_NAME(name),fn);
}
bool Commond::IsCommond(common::SerializationAble* sa){
	return (sa->GetTypeName().size() > CMD_SIZE &&  sa->GetTypeName().substr(0,CMD_SIZE) == CMD_PRE );
}
Commond::Commond(const std::string& cmd_name):common::SerializationAble(GET_CMD_TYPE_NAME(cmd_name)){

}
Commond::~Commond(){

}
std::string Commond::Name(){
	return this->GetTypeName().substr(CMD_SIZE);
}

} /* namespace translate */
} /* namespace adcloud */
