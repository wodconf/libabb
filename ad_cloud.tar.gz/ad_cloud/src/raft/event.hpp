
#ifndef AD_CLOUD_RAFT_EVENT_HPP_
#define AD_CLOUD_RAFT_EVENT_HPP_

#include "../common/notification.hpp"
#include "../common/serialization_able.hpp"
#include "../common/ref_object.hpp"
namespace adcloud {
namespace raft {

struct Event:public common::RefObject {
	Event(common::SerializationAble* r):req(r),rsp(NULL){
		req->Ref();
	}
	~Event(){
		req->UnRef();
	}
	common::SerializationAble* req;
	void* rsp;
	std::string err;
	common::Notification notify_;
};

} /* namespace raft */
} /* namespace adcloud */

#endif /* EVENT_HPP_ */
