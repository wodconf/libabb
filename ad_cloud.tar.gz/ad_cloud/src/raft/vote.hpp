
#ifndef VOTE_REQUEST_HPP_
#define VOTE_REQUEST_HPP_
#include "../common/serialization_able.hpp"
namespace adcloud {
namespace raft {

class VoteRequest :public common::SerializationAble{
public:
	static const char* TypeName ;
public:
	VoteRequest();
	VoteRequest(uint64_t Term,uint64_t LastLogIndex,uint64_t LastLogTerm,const std::string& name);
	~VoteRequest();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
public:
	uint64_t Term;
	uint64_t LastLogIndex;
	uint64_t LastLogTerm;
	std::string CandidateName;
};

class VoteResponce :public common::SerializationAble{
public:
	static const char* TypeName ;
public:
	VoteResponce();
	VoteResponce(uint64_t Term,bool VoteGranted);
	~VoteResponce();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
public:
	uint64_t Term;
	bool VoteGranted;
};

} /* namespace raft */
} /* namespace adcloud */

#endif /* VOTE_REQUEST_HPP_ */
