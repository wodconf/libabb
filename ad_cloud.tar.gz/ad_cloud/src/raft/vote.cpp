
#include "vote.hpp"

namespace adcloud {
namespace raft {
const char* VoteRequest::TypeName = "adcloud.raft.VoteRequest";
VoteRequest::VoteRequest()
:Term(0),LastLogIndex(0),LastLogTerm(0),common::SerializationAble(TypeName)
{
}
VoteRequest::VoteRequest(uint64_t Term,
		uint64_t LastLogIndex,
		uint64_t LastLogTerm,
		const std::string& name)
:Term(Term),LastLogIndex(LastLogIndex),LastLogTerm(LastLogTerm),CandidateName(name),common::SerializationAble(TypeName)
{
}

VoteRequest::~VoteRequest() {

}
uint32_t VoteRequest::GetLength(){
	return sizeof(Term)+sizeof(LastLogIndex)+sizeof(LastLogTerm)+CandidateName.size()+1;
}
void VoteRequest::EncodeBody(common::BufferWriter &buf){
	buf.NET_WriteUint64(Term);
	buf.NET_WriteUint64(LastLogIndex);
	buf.NET_WriteUint64(LastLogTerm);
	buf << CandidateName;
}
void VoteRequest::DecodeBody(common::BufferReader &buf){
	Term = buf.HOST_ReadUint64();
	LastLogIndex = buf.HOST_ReadUint64();
	LastLogTerm = buf.HOST_ReadUint64();
	buf >> CandidateName;
}

const char* VoteResponce::TypeName = "adcloud.raft.VoteResponce";
VoteResponce::VoteResponce(uint64_t Term,bool VoteGranted):Term(Term),VoteGranted(VoteGranted),common::SerializationAble(TypeName) {

}
VoteResponce::VoteResponce():Term(0),VoteGranted(false),common::SerializationAble(TypeName) {

}

VoteResponce::~VoteResponce() {

}
uint32_t VoteResponce::GetLength(){
	return sizeof(Term) + sizeof(VoteGranted);
}
void VoteResponce::EncodeBody(common::BufferWriter &buf){
	buf.NET_WriteUint64(Term);
	buf << VoteGranted;
}
void VoteResponce::DecodeBody(common::BufferReader &buf){
	Term = buf.HOST_ReadUint64();
	buf >> VoteGranted;
}
} /* namespace raft */
} /* namespace adcloud */
