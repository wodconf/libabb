/*
 * raft_init.hpp
 *
 *  Created on: 2014-5-13
 *      Author: wd
 */

#ifndef RAFT_INIT_HPP_
#define RAFT_INIT_HPP_


namespace adcloud {
namespace raft {
void Init();
}
}


#endif /* RAFT_INIT_HPP_ */
