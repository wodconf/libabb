
#ifndef JOIN_COMMOND_HPP_
#define JOIN_COMMOND_HPP_

#include "commond.hpp"

namespace adcloud {
namespace raft {


class JoinCommond:public Commond {
public:
	static const char* CmdName ;
public:
	JoinCommond();
	virtual ~JoinCommond();
	virtual const std::string& NodeName() = 0;

};


}
}

#endif /* JOIN_COMMOND_HPP_ */
