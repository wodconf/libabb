/*
 * snapshot.hpp
 *
 *  Created on: 2014-5-14
 *      Author: wd
 */

#ifndef SNAPSHOT_HPP_
#define SNAPSHOT_HPP_

#include <string>
#include <vector>
#include "../common/serialization_able.hpp"
#include "../common/buffer.hpp"
namespace adcloud {
namespace raft {
struct PeerInfo{
	std::string name;
	std::string addr;
};
class Snapshot {
public:
	Snapshot();
	Snapshot(uint64_t LastIndex,
			uint64_t LastTerm,
			const std::vector<PeerInfo>& peers,
			const std::string& path);
	virtual ~Snapshot();
	uint64_t LastIndex;
	uint64_t LastTerm;
	std::vector<PeerInfo> Peers;
	std::string Path;
	common::Buffer state;
	bool Save();
	void Remove();
	uint32_t GetLength();
	void EncodeBody(common::BufferWriter &buf);
	void DecodeBody(common::BufferReader &buf);
	static Snapshot* Load(const std::string& path);
};
class SnapshotRequest:public  common::SerializationAble{
public:
	static const char* TypeName;
public:
	SnapshotRequest();
	SnapshotRequest(const std::string& LeaderName,const Snapshot& snap);
	~SnapshotRequest();
	uint64_t LastIndex;
	uint64_t LastTerm;
	std::string LeaderName;
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};
class SnapshotResponce:public  common::SerializationAble{
public:
	static const char* TypeName;
public:
	SnapshotResponce();
	SnapshotResponce(bool suc);
	~SnapshotResponce();
	bool success;
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};
class SnapshotRecoveryRequest :public common::SerializationAble{
public:
	static const char* TypeName;
public:
	SnapshotRecoveryRequest();
	SnapshotRecoveryRequest(const std::string& LeaderName,Snapshot& snap);
	~SnapshotRecoveryRequest();
	uint64_t LastIndex;
	uint64_t LastTerm;
	std::string LeaderName;
	std::vector<PeerInfo> Peers;
	common::Buffer state;
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};

class SnapshotRecoveryResponce:public common::SerializationAble {
public:
	static const char* TypeName ;
public:
	SnapshotRecoveryResponce();
	SnapshotRecoveryResponce(uint64_t Term,bool Success,uint64_t CommitIndex);
	~SnapshotRecoveryResponce();
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
public:
	uint64_t Term;
	bool Success;
	uint64_t CommitIndex;
};
} /* namespace raft */
} /* namespace adcloud */

#endif /* SNAPSHOT_HPP_ */
