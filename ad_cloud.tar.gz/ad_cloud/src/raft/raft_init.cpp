#include "raft_init.hpp"
#include "append_entries.hpp"
#include "vote.hpp"
#include "raft_log_entry.hpp"
#include "snapshot.hpp"
namespace adcloud {
namespace raft {
void Init(){
	common::SerializationAble::RegistCreator(AppendEntriesResponce::TypeName,common::T_SerializationAbleCreator<AppendEntriesResponce>);
	common::SerializationAble::RegistCreator(AppendEntriesRequest::TypeName,common::T_SerializationAbleCreator<AppendEntriesRequest>);
	common::SerializationAble::RegistCreator(VoteRequest::TypeName,common::T_SerializationAbleCreator<VoteRequest>);
	common::SerializationAble::RegistCreator(VoteResponce::TypeName,common::T_SerializationAbleCreator<VoteResponce>);
	common::SerializationAble::RegistCreator(RaftLogEntry::TypeName,common::T_SerializationAbleCreator<RaftLogEntry>);
	common::SerializationAble::RegistCreator(SnapshotRecoveryRequest::TypeName,common::T_SerializationAbleCreator<SnapshotRecoveryRequest>);
	common::SerializationAble::RegistCreator(SnapshotRecoveryResponce::TypeName,common::T_SerializationAbleCreator<SnapshotRecoveryResponce>);
	common::SerializationAble::RegistCreator(SnapshotRequest::TypeName,common::T_SerializationAbleCreator<SnapshotRequest>);
	common::SerializationAble::RegistCreator(SnapshotResponce::TypeName,common::T_SerializationAbleCreator<SnapshotResponce>);
}
}
}
