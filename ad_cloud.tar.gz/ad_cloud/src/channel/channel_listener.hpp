/*
 * channel_listener.hpp
 *
 *  Created on: 2014-5-30
 *      Author: wd
 */

#ifndef CHANNEL_LISTENER_HPP_
#define CHANNEL_LISTENER_HPP_
#include <string>
#include "../translate/message.hpp"
namespace adcloud {
namespace channel {
class ChannelClient;
class Channel;
class IChannelClientListener{
public:
	virtual ~IChannelClientListener(){}
	virtual void L_ChannelClient_OnMessage(ChannelClient* cli) = 0;
	virtual void L_ChannelClient_OnClose(ChannelClient* cli) = 0;
};
class IChannelServerListener{
public:
	virtual ~IChannelServerListener(){}
	virtual void L_ChannelServer_OnChannelOpen(const std::string& id) = 0;
	virtual void L_ChannelServer_OnChannelMessage(const std::string&id,translate::Message*) = 0;
	virtual void L_ChannelServer_OnChannelClose(const std::string& id) = 0;
};
class IChannelListener{
public:
	virtual ~IChannelListener(){}
	virtual void L_ChannelClient_OnMessage(Channel* channel) = 0;
	virtual void L_ChannelClient_OnClose(Channel* channel) = 0;
};


} /* namespace monprxoy */
} /* namespace adcloud */
#endif /* CHANNEL_LISTENER_HPP_ */
