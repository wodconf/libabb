/*
 * channel.hpp
 *
 *  Created on: 2014-5-30
 *      Author: wd
 */

#ifndef CHANNEL_HPP_
#define CHANNEL_HPP_

namespace adcloud {
namespace channel {

class Channel {
public:
	Channel();
	~Channel();
private:
	
};

} /* namespace monprxoy */
} /* namespace adcloud */

#endif /* CHANNEL_HPP_ */
