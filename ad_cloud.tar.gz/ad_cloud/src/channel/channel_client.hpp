/*
 * channel_client.hpp
 *
 *  Created on: 2014-5-30
 *      Author: wd
 */

#ifndef CHANNEL_CLIENT_HPP_
#define CHANNEL_CLIENT_HPP_

#include "../translate/connection.hpp"
#include "../translate/connector.hpp"
#include "channel_listener.hpp"
#include "../common/notification.hpp"
namespace adcloud {
namespace channel {

class ChannelClient :public translate::Connection::Listener,translate::Connector::Listener,IChannelListener{
public:
	ChannelClient(const std::string& id,const abb::net::IPAddr& addr);
	~ChannelClient();
	bool Open();
	void Close();
	virtual void L_Connection_OnMessage(translate::Connection* self,translate::Message*msg);
	virtual void L_Connection_OnClose(translate::Connection* self);
	virtual void L_Connector_OnOpen(translate::Connection* ptr);
	virtual void L_Connector_OnOpenFail();
private:
	Channel* chan_;
	abb::net::IPAddr addr_;
	std::string id_;
	translate::Connection* conn_;
	translate::Connector ctor_;
	common::Notification notify_;
	enum{
		STATE_INITED,
		STATE_OPENING,
		STATE_OPENED,
		STATE_REOPENING,
		STATE_CLOSED
	};
	int state_;
};

} /* namespace monprxoy */
} /* namespace adcloud */

#endif /* CHANNEL_CLIENT_HPP_ */
