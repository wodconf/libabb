
#ifndef CHANNEL_SERVER_HPP_
#define CHANNEL_SERVER_HPP_

#include "../translate/acceptor.hpp"
#include "../translate/connection.hpp"

namespace adcloud {
namespace channel {
class Channel;
class ChannelServer :public translate::Acceptor::Listener,translate::Connection::Listener{
public:
	ChannelServer();
	~ChannelServer();
	virtual void L_Connection_OnMessage(translate::Connection* self,translate::Message*msg);
	virtual void L_Connection_OnClose(translate::Connection* self);
	virtual void L_Acceptor_OnConnection(translate::Connection* conn);
private:

};

} /* namespace monprxoy */
} /* namespace adcloud */

#endif /* CHANNEL_SERVER_HPP_ */
