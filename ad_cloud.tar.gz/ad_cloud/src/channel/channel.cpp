/*
 * channel.cpp
 *
 *  Created on: 2014-5-30
 *      Author: wd
 */

#include "channel.hpp"

namespace adcloud {
namespace channel {

Channel::Channel() {
	// TODO Auto-generated constructor stub

}

Channel::~Channel() {
	// TODO Auto-generated destructor stub
}

} /* namespace monprxoy */
} /* namespace adcloud */
