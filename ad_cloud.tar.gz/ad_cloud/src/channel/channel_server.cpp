/*
 * channel_server.cpp
 *
 *  Created on: 2014-5-30
 *      Author: wd
 */

#include "channel_server.hpp"

namespace adcloud {
namespace channel {

ChannelServer::ChannelServer() {
	// TODO Auto-generated constructor stub

}

ChannelServer::~ChannelServer() {
	// TODO Auto-generated destructor stub
}

} /* namespace monprxoy */
} /* namespace adcloud */
