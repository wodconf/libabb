/*
 * channel_client.cpp
 *
 *  Created on: 2014-5-30
 *      Author: wd
 */

#include "channel_client.hpp"
#include "../common/time.hpp"
namespace adcloud {
namespace channel {

ChannelClient::ChannelClient(const std::string& id,const abb::net::IPAddr& addr)
:id_(id),
 addr_(addr),
 chan_(NULL),
 state_(STATE_INITED),
 conn_(NULL){
	// TODO Auto-generated constructor stub

}

ChannelClient::~ChannelClient() {
	// TODO Auto-generated destructor stub
}
bool ChannelClient::Open(){
	if( !ctor_.Connect(this->addr_) ){
		return false;
	}
}
void ChannelClient::Close(){
	ctor_.Reset();
}
void ChannelClient::L_Connection_OnMessage(translate::Connection* self,translate::Message*msg){

}
void ChannelClient::L_Connection_OnClose(translate::Connection* self){
	conn_->UnRef();
	conn_ = NULL;
	if(this->state_ == STATE_OPENING){
		self->UnRef();
	}
}
void ChannelClient::L_Connector_OnOpen(translate::Connection* ptr){
	ptr->SetListner(this);
}
void ChannelClient::L_Connector_OnOpenFail(){

}
} /* namespace monprxoy */
} /* namespace adcloud */
