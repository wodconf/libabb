/*
 * cmd_lose_master.cpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#include "cmd_lose_master.hpp"

#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {
const char* CMDLoseMaster::CmdName = "CMDLoseMaster";
CMDLoseMaster::CMDLoseMaster():raft::Commond(CmdName) {
}

CMDLoseMaster::~CMDLoseMaster() {
}
common::SerializationAble* CMDLoseMaster::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoLoseMaster(name,need_return);
}
uint32_t CMDLoseMaster::GetLength() {
	return name.length()+1;
}
void CMDLoseMaster::EncodeBody(common::BufferWriter &buf) {
	buf << name;
}
void CMDLoseMaster::DecodeBody(common::BufferReader &buf) {
	buf >> name;
}
} /* namespace type */
} /* namespace adcloud */
