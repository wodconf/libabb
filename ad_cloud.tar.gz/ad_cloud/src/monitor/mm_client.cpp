#include "mm_client.hpp"

#include "../type/type_add_app.hpp"
#include "../type/type_del_app.hpp"
#include "../type/type_add_master.hpp"
#include "../type/type_lose_master.hpp"
#include "../type/type_get_app_at.hpp"
#include "../type/type_add_gate.hpp"
#include "../type/type_gate_stat.hpp"
#include "../type/type_lose_gate.hpp"
#include "../type/type_get_master.hpp"
#include "mm_rpc_method.hpp"
namespace adcloud{
namespace mon{
MonitorClient::MonitorClient()
:c_pool_(this),
 rpc_client_(new rpc::RpcClient(this)),
 index_(0)
{

}
MonitorClient::~MonitorClient(){

}
bool MonitorClient::AddMaster(const std::string& name,
		const std::string& host,
		const std::string& in_host,
		uint16_t gate_port,
		uint16_t app_port,
		uint16_t om_port,
		uint32_t max_num){
	type::TAddMasterReq req;
	req.app_port = app_port;
	req.gate_port = gate_port;
	req.host = host;
	req.in_host = in_host;
	req.name = name;
	req.om_port = om_port;
	req.max_num = max_num;
	std::string err;
	type::TAddMasterRsp* rsp = static_cast<type::TAddMasterRsp*>( this->rpc_client_->Call(METHOD_ADD_MASTER,&req,err) );
	if(!rsp){
		LOG(DEBUG) << "AddMaster Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}
bool MonitorClient::GetMaster(std::map<std::string,std::string>& om){
	std::string err;
	type::TGetMasterRsp* rsp = static_cast<type::TGetMasterRsp*>( this->rpc_client_->Call(METHOD_GET_MASTER,NULL,err) );
	if(!rsp){
		LOG(DEBUG) << "GetMaster Fail: " << err;
		return false;
	}
	om = rsp->om_map;
	rsp->UnRef();
	return true;
}
bool MonitorClient::LoseMaster(const std::string& name){
	type::TLoseMasterReq req;
	req.name = name;
	std::string err;
	type::TLoseMasterRsp* rsp = static_cast<type::TLoseMasterRsp*>(this->rpc_client_->Call(METHOD_LOSE_MASTER,&req,err));
	if(!rsp){
		LOG(DEBUG) << "LoseMaster Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}

bool MonitorClient::MasterAddApp(const std::string& name,const std::string& app_id,uint32_t num){
	type::TAddAppReq req;
	req.name = name;
	req.app_id = app_id;
	std::string err;
	type::TAddAppRsp* rsp = static_cast<type::TAddAppRsp*>(this->rpc_client_->Call(METHOD_MASTER_ADD_APP,&req,err));
	if(!rsp){
		LOG(DEBUG) << "AddApp Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}
bool MonitorClient::MasterDelApp(const std::string& name,const std::string& app_id){
	type::TDelAppReq req;
	req.name = name;
	req.app_id = app_id;
	std::string err;
	type::TDelAppRsp* rsp = static_cast<type::TDelAppRsp*>(this->rpc_client_->Call(METHOD_MASTER_DEL_APP,&req,err));
	if(!rsp){
		LOG(DEBUG) << "MasterDelApp Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}

bool MonitorClient::GetAppAt(const std::string&app_id,std::string& maddr){
	type::TGetAppAtReq req;
	req.app_id = app_id;
	std::string err;
	type::TGetAppAtRsp* rsp = static_cast<type::TGetAppAtRsp*>(this->rpc_client_->Call(METHOD_GET_APP_AT,&req,err));
	if(!rsp){
		LOG(DEBUG) << "GetAppAt Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	if(s){
		maddr = rsp->addr;
	}
	rsp->UnRef();
	return s;
}
bool MonitorClient::AddGate(const std::string& name,const std::string addr){
	type::TAddGateReq req;
	req.addr = addr;
	req.name = name;
	std::string err;
	type::TAddGateRsp* rsp = static_cast<type::TAddGateRsp*>(this->rpc_client_->Call(METHOD_ADD_GATE,&req,err));
	if(!rsp){
		LOG(DEBUG) << "AddGate Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}
bool MonitorClient::LoseGate(const std::string&name){
	type::TLoseGateReq req;
	req.name = name;
	std::string err;
	type::TLoseGateRsp* rsp = static_cast<type::TLoseGateRsp*>(this->rpc_client_->Call(METHOD_LOSE_GATE,&req,err));
	if(!rsp){
		LOG(DEBUG) << "LoseGate Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}
bool MonitorClient::GateAddApp(const std::string& name,const std::string& app_id){
	type::TAddAppReq req;
	req.name = name;
	req.app_id = app_id;
	std::string err;
	type::TAddAppRsp* rsp = static_cast<type::TAddAppRsp*>(this->rpc_client_->Call(METHOD_GATE_ADD_APP,&req,err));
	if(!rsp){
		LOG(DEBUG) << "GateAddApp Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}
bool MonitorClient::GateDelApp(const std::string& name,const std::string& app_id){
	type::TDelAppReq req;
	req.name = name;
	req.app_id = app_id;
	std::string err;
	type::TDelAppRsp* rsp = static_cast<type::TDelAppRsp*>(this->rpc_client_->Call(METHOD_GATE_DEL_APP,&req,err));
	if(!rsp){
		LOG(DEBUG) << "GateDelApp Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}

bool MonitorClient::GateStat(const std::string& name,int num_cli,int cpu,int mem){
	type::TGateStatReq req;
	req.name = name;
	req.num_client = num_cli;
	req.cpu = cpu;
	req.mem = mem;
	std::string err;
	type::TGateStatRsp* rsp = static_cast<type::TGateStatRsp*>(this->rpc_client_->Call(METHOD_GATE_STAT,&req,err));
	if(!rsp){
		LOG(DEBUG) << "GateStat Fail: " << err;
		return false;
	}
	bool s = rsp->success;
	rsp->UnRef();
	return s;
}
type::TGetFreeMasterRsp* MonitorClient::CallGetFreeMaster(type::TGetFreeMasterReq* req,std::string& error){
	type::TGetFreeMasterRsp* rsp = static_cast<type::TGetFreeMasterRsp*>(this->rpc_client_->Call(METHOD_GET_FREE_MASTER,req,error));
	return rsp;
}
bool MonitorClient::GetMasterMap(std::map<std::string,std::string>& om ){
	return false;
}

bool MonitorClient::ISend_Send(translate::Message& msg){
	if(cur_addr_.empty()){
		index_=(index_+1)%this->addr_arr_.size();
		cur_addr_ = this->addr_arr_[index_];
	}
	return this->c_pool_.SendToAddr(msg,cur_addr_);
}
void MonitorClient::L_ClientPool_ConnectionReset(const std::string& addr){
	LOG(DEBUG) << "MasterMonClient ConnectClose:" << addr;
	cur_addr_.clear();
	this->rpc_client_->OnClose();
}
void MonitorClient::L_ClientPool_ConnectionMessage(const std::string& addr,translate::Message* msg){
	if(msg->GetTag() == rpc::MRpcResponce::TAG){
		this->rpc_client_->OnMessage(static_cast<rpc::MRpcResponce*>(msg));
	}else{
		LOG(WARN) << msg->GetTagString();
	}
}

}
}
