#ifndef ADCLOUD_MASTER_MON_CLIENT_HPP_
#define ADCLOUD_MASTER_MON_CLIENT_HPP_ 

#include "../common/buffer.hpp"
#include "../common/mutex.hpp"
#include "../rpc/rpc_client.hpp"
#include "../translate/client_pool.hpp"
#include "../type/type_get_free_master.hpp"
#include <vector>
namespace adcloud{
namespace mon{
class MonitorClient:public rpc::RpcClient::ISend,translate::ClientPool::Listener{
public:
	typedef std::vector<std::string> StringArray;
	MonitorClient();
	virtual ~MonitorClient();
	void SetAddrs(const StringArray& arr){
		addr_arr_ = arr;
	}
	bool AddMaster(const std::string& name,
			const std::string& host,
			const std::string& in_host,
			uint16_t gate_port,
			uint16_t app_port,
			uint16_t om_port,
			uint32_t max_num);
	bool GetMaster(std::map<std::string,std::string>& om);
	bool LoseMaster(const std::string& name);
	bool MasterAddApp(const std::string& name,const std::string& app_id,uint32_t num);
	bool MasterDelApp(const std::string& name,const std::string& app_id);
	bool GetAppAt(const std::string&app_id,std::string& maddr);
	bool GetMasterMap(std::map<std::string,std::string>& om );

	bool AddGate(const std::string& name,const std::string addr);
	bool LoseGate(const std::string&name);
	bool GateAddApp(const std::string& name,const std::string& app_id);
	bool GateDelApp(const std::string& name,const std::string& app_id);

	bool GateStat(const std::string& name,int num_cli,int cpu,int mem);
	type::TGetFreeMasterRsp* CallGetFreeMaster(type::TGetFreeMasterReq* req,std::string& error);
public:
	virtual bool ISend_Send(translate::Message& msg);
	virtual void L_ClientPool_ConnectionReset(const std::string& addr);
	virtual void L_ClientPool_ConnectionMessage(const std::string& addr,translate::Message* msg);

private:
	rpc::RpcClient* rpc_client_;
	translate::ClientPool c_pool_;
	std::string cur_addr_;
	StringArray addr_arr_;
	int index_;
};
}
}
#endif
