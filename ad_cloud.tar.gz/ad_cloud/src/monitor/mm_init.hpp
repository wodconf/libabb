/*
 * master_mon_init.hpp
 *
 *  Created on: 2014-5-13
 *      Author: wd
 */

#ifndef MASTER_MON_INIT_HPP_
#define MASTER_MON_INIT_HPP_


namespace adcloud {
namespace mon {
	void Init();
}
}


#endif /* MASTER_MON_INIT_HPP_ */
