/*
 * cmd_lose_gate.cpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#include "cmd_lose_gate.hpp"
#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {
const char* CMDLoseGate::CmdName = "CMDLoseGate";
CMDLoseGate::CMDLoseGate():raft::Commond(CmdName) {
}

CMDLoseGate::~CMDLoseGate() {
}
common::SerializationAble* CMDLoseGate::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoLoseGate(name,need_return);
}
uint32_t CMDLoseGate::GetLength() {
	return name.length()+1;
}
void CMDLoseGate::EncodeBody(common::BufferWriter &buf) {
	buf << name;
}
void CMDLoseGate::DecodeBody(common::BufferReader &buf) {
	buf >> name;
}

} /* namespace mon */
} /* namespace adcloud */
