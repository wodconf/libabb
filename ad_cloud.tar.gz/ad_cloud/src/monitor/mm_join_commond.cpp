
#include "mm_join_commond.hpp"
#include "mm_monitor.hpp"
#include "../raft/raft_server.hpp"
namespace adcloud{
namespace mon{
MMJoinCommond::MMJoinCommond() {

}

MMJoinCommond::~MMJoinCommond() {
}
MMJoinCommond::MMJoinCommond(const std::string& nodename,const std::string& addr,const std::string& mon_addr)
:node_name_(nodename),raft_addr_(addr),mon_addr_(mon_addr){

}
common::SerializationAble* MMJoinCommond::Apply(raft::RaftServer*svr,std::string *save_error,bool need_return){
	svr->AddPeer(this->node_name_,this->raft_addr_);
	Monitor* mon = (Monitor*)svr->Context();
	mon->AddPeer(mon_addr_);
	svr->FlushCommitIndex();
	if(need_return){
		rpc::TRpcBool* b = new rpc::TRpcBool();
		b->success = true;
		return b;
	}
	return NULL;
}
uint32_t MMJoinCommond::GetLength(){
	return this->mon_addr_.size() + 1 + node_name_.size()+1 + raft_addr_.size()+1;
}
void MMJoinCommond::EncodeBody(common::BufferWriter &buf){
	buf << this->node_name_ << this->raft_addr_ << this->mon_addr_;
}
void MMJoinCommond::DecodeBody(common::BufferReader &buf){
	buf >> this->node_name_ >> this->raft_addr_ >> this->mon_addr_;
}
}}
