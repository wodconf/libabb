
#ifndef MM_RPC_NAME_HPP_
#define MM_RPC_NAME_HPP_



#define METHOD_ADD_GATE "AddGate"
#define METHOD_LOSE_GATE "LoseGate"
#define METHOD_GATE_ADD_APP "GateAddApp"
#define METHOD_GATE_DEL_APP "GateDelApp"
#define METHOD_GATE_STAT "GateStat"
#define METHOD_ADD_MASTER "AddMaster"
#define METHOD_LOSE_MASTER "LoseMaster"
#define METHOD_MASTER_ADD_APP "MasterAddApp"
#define METHOD_MASTER_DEL_APP "MasterDelApp"
#define METHOD_GET_APP_AT "GatAppAt"
#define METHOD_GET_MASTER "GetMaster"

#define METHOD_GET_FREE_MASTER "GetFreeMaster"
#endif /* MM_RPC_NAME_HPP_ */
