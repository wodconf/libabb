
#ifndef MASTER_INFO_HPP_
#define MASTER_INFO_HPP_

#include <map>
#include <stdlib.h>
#include <sstream>
#include <stdint.h>
namespace adcloud {
namespace mon {

class MasterInfo {
public:
	MasterInfo(const std::string& name,
			const std::string& host,
			const std::string& in_host,
			uint16_t gate_port,
			uint16_t app_port,
			uint16_t om_port,
			uint32_t max_num)
:name(name),
 host(host),
 in_host(in_host),
 gate_port(gate_port),
 app_port(app_port),
 om_port(om_port),
 cur_num(0),
 max_num(max_num){

	}
	~MasterInfo(){
		AppMap::iterator iter = app_map.begin();
		for(;iter != app_map.end();iter++){
			delete iter->second;
		}
		app_map.clear();
	}
	void AddApp(const std::string& appid,uint32_t num){
		if(app_map.find(appid) == app_map.end()){
			app_map[appid] = new AppInfo(num);
			cur_num+= num;
		}
	}
	bool CanAddApp(uint32_t num){
		LOG(DEBUG) << max_num << ":" << cur_num;
		return (max_num-cur_num) > num;
	}
	void DelApp(const std::string& appid){
		AppMap::iterator iter = app_map.find(appid);
		if(iter != app_map.end()){
			cur_num -= iter->second->num;
			delete iter->second;
			app_map.erase(iter);
		}
	}
	bool AppExist(const std::string& appid){
		return app_map.find(appid) != app_map.end();
	}
	std::string GetGateAddr(){
		std::ostringstream s;
		s << host << ":" << gate_port;
		return s.str();
	}
	std::string GetOmAddr(){
		std::ostringstream s;
		s << in_host << ":" << om_port;
		return s.str();
	}
	std::string GetAppAddr(){
		std::ostringstream s;
		s << host << ":" << app_port;
		return s.str();
	}
	const std::string& GetName(){return name;}
public:
	std::string name;
	std::string host;
	std::string in_host;
	uint16_t gate_port;
	uint16_t app_port;
	uint16_t om_port;
	uint32_t max_num;
	struct AppInfo{
		AppInfo(uint32_t num):num(num){}
		~AppInfo(){};
		uint32_t num;
	};
	uint32_t cur_num;
	typedef std::map<std::string,AppInfo*> AppMap;
	AppMap app_map;
};

} /* namespace type */
} /* namespace adcloud */

#endif /* MASTER_INFO_HPP_ */
