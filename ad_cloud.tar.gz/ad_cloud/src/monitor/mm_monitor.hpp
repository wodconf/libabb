
#ifndef MASTER_MON_HPP_
#define MASTER_MON_HPP_


#include "../rpc/rpc_service.hpp"
#include "../common/mutex.hpp"
#include "../mon_raft/peer_server.hpp"
#include "../common/define.hpp"

#include "../type/type_add_app.hpp"
#include "../type/type_del_app.hpp"
#include "../type/type_add_master.hpp"
#include "../type/type_lose_master.hpp"
#include "../type/type_get_app_at.hpp"
#include "../type/type_add_gate.hpp"
#include "../type/type_lose_gate.hpp"
#include "../type/type_gate_stat.hpp"
#include "../type/type_get_master.hpp"
#include "../translate/acceptor.hpp"
#include "../translate/connection.hpp"

#include "mm_config.hpp"
#include "mm_gate_info.hpp"
#include "mm_master_info.hpp"
#include <map>


namespace adcloud {
namespace mon {
class Monitor;
class AddMasterFunction;
class LoseMasterFunction;
class MasterAddAppFunction;
class MasterDelAppFunction;
class GetAppAtFunction;

class AddGateFunction;
class LoseGateFunction;
class GateAddAppFunction;
class GateDelAppFunction;
class GateStatFucntion;

class FGetMaster;

class FGetFreeMaster;

class Monitor:public translate::Acceptor::Listener,translate::Connection::Listener,monraft::IJoinCommondFactory,raft::IStateMachine {
public:
	Monitor();
	~Monitor();
	bool Init(Config* cfg);
	bool Start();
	void Stop(){
		this->actor_->SetEnable(false);
		this->peer_svr_->Stop();
		this->rpc_svr_->Stop();
	}
	type::TAddMasterRsp* DoAddMaster(const std::string& name,
			const std::string& host,
			const std::string& in_host,
			uint16_t gate_port,
			uint16_t app_port,
			uint16_t om_port,uint32_t max_num,bool bneedret);
	type::TLoseMasterRsp* DoLoseMaster(const std::string& name,bool bneedret);
	type::TAddAppRsp* DoMasterAddApp(const std::string& name,const std::string& appid,uint32_t max_num,bool bneedret);
	type::TDelAppRsp* DoMasterDelApp(const std::string& name,const std::string& appid,bool bneedret);

	type::TAddAppRsp* DoGateAddApp(const std::string& name,const std::string& appid,bool bneedret);
	type::TDelAppRsp* DoGateDelApp(const std::string& name,const std::string& appid,bool bneedret);

	type::TAddGateRsp* DoAddGate(const std::string&name,const std::string& addr,bool bneedret);
	type::TLoseGateRsp* DoLoseGate(const std::string&name,bool bneedret);

	type::TGateStatRsp* DoGateStat(const std::string& name,int num_cli,int cpu,int men,bool bneedret);

	bool GetFreeMaster(uint32_t num,std::string& addr);
	bool MasterHasApp(const std::string& app,std::string* mastername);
	virtual void L_Connection_OnMessage(translate::Connection* self,translate::Message*msg);
	virtual void L_Connection_OnClose(translate::Connection* self);
	virtual void L_Acceptor_OnConnection(translate::Connection*);
	virtual raft::JoinCommond * CreateJoinCommond();
	virtual bool Save(common::Buffer& buf);
	virtual bool Recovery(common::Buffer& buf);
	void AddPeer(const std::string& addr){
		peers_.push_back(addr);
	}
	void RemovePeer(const std::string& addr){
		StringArray::iterator iter = peers_.begin();
		for(;iter != peers_.end();iter++){
			peers_.erase(iter);
			return;
		}
	}
private:
	friend class AddMasterFunction;
	friend class LoseMasterFunction;
	friend class MasterAddAppFunction;
	friend class MasterDelAppFunction;
	friend class GetAppAtFunction;
	friend class FGetMaster;
	friend class FGetFreeMaster;
	FGetFreeMaster* get_free_master_fn_;
	FGetMaster * get_master_fn_;
	AddMasterFunction* add_master_fn_;
	LoseMasterFunction* lose_master_fn_;
	MasterAddAppFunction* add_app_fn_;
	MasterDelAppFunction* del_app_fn_;
	GetAppAtFunction* get_app_at_fn_;

	friend class AddGateFunction;
	friend class LoseGateFunction;
	friend class GateAddAppFunction;
	friend class GateDelAppFunction;
	friend class GateStatFucntion;
	AddGateFunction* add_gate_fn_;
	LoseGateFunction* lose_gate_fn_;
	GateAddAppFunction* gate_add_app_fn_;
	GateDelAppFunction* gate_del_app_fn_;
	GateStatFucntion* gate_stat_fn_;

	common::Mutex mtx_;
	typedef std::map<std::string,MasterInfo*> MasterMap;
	MasterMap master_map_;

	common::Mutex gate_mtx_;
	typedef std::map<std::string,GateInfo*> GateMap;
	GateMap gate_map_;

	typedef std::vector<std::string> StringArray;
	StringArray peers_;

	monraft::PeerServer* peer_svr_;
	rpc::RpcService* rpc_svr_;
	translate::Acceptor* actor_;
	Config* cfg_;
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(Monitor);
};

} /* namespace mastermon */
} /* namespace adcloud */

#endif /* MASTER_MON_HPP_ */
