/*
 * cmd_gate_stat.cpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#include "cmd_gate_stat.hpp"
#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {

const char* CMDGateStat::CmdName = "CMDGateStat";
CMDGateStat::CMDGateStat():raft::Commond(CmdName),num_client(0),cpu(0),mem(0){

}

CMDGateStat::~CMDGateStat() {
}
common::SerializationAble* CMDGateStat::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoGateStat(name,num_client,cpu,mem,need_return);
}
uint32_t CMDGateStat::GetLength() {
	return name.length()+1 + sizeof(num_client) + sizeof(cpu) + sizeof(mem);
}
void CMDGateStat::EncodeBody(common::BufferWriter &buf) {
	buf << name;
	buf.NET_WriteUint16(num_client);
	buf.NET_WriteUint16(cpu);
	buf.NET_WriteUint32(mem);
}
void CMDGateStat::DecodeBody(common::BufferReader &buf) {
	buf >> name;
	num_client = buf.HOST_ReadUint16();
	cpu = buf.HOST_ReadUint16();
	mem = buf.HOST_ReadUint32();
}

} /* namespace mon */
} /* namespace adcloud */
