/*
 * master_mon_init.cpp
 *
 *  Created on: 2014-5-13
 *      Author: wd
 */




#include "mm_init.hpp"
#include "cmd_master_add_app.hpp"
#include "cmd_add_master.hpp"
#include "cmd_master_del_app.hpp"
#include "cmd_lose_master.hpp"
#include "cmd_add_gate.hpp"
#include "cmd_lose_gate.hpp"
#include "cmd_gate_add_app.hpp"
#include "cmd_gate_del_app.hpp"
#include "cmd_gate_stat.hpp"
#include "mm_join_commond.hpp"
#include "../raft/raft_init.hpp"
namespace adcloud {
namespace mon {
void Init(){
	raft::Commond::RegistCreator(CMDMasterAddApp::CmdName,common::T_SerializationAbleCreator<CMDMasterAddApp>);
	raft::Commond::RegistCreator(CMDMasterDelApp::CmdName,common::T_SerializationAbleCreator<CMDMasterDelApp>);
	raft::Commond::RegistCreator(CMDAddMaster::CmdName,common::T_SerializationAbleCreator<CMDAddMaster>);
	raft::Commond::RegistCreator(CMDLoseMaster::CmdName,common::T_SerializationAbleCreator<CMDLoseMaster>);
	raft::Commond::RegistCreator(MMJoinCommond::CmdName,common::T_SerializationAbleCreator<MMJoinCommond>);

	raft::Commond::RegistCreator(CMDGateAddApp::CmdName,common::T_SerializationAbleCreator<CMDGateAddApp>);
	raft::Commond::RegistCreator(CMDGateDelApp::CmdName,common::T_SerializationAbleCreator<CMDGateDelApp>);
	raft::Commond::RegistCreator(CMDAddGate::CmdName,common::T_SerializationAbleCreator<CMDAddGate>);
	raft::Commond::RegistCreator(CMDLoseGate::CmdName,common::T_SerializationAbleCreator<CMDLoseGate>);
	raft::Commond::RegistCreator(CMDGateStat::CmdName,common::T_SerializationAbleCreator<CMDGateStat>);

	raft::Init();
}
}
}
