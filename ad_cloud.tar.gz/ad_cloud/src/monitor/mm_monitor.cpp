

#include "mm_monitor.hpp"

#include "cmd_add_master.hpp"
#include "cmd_master_del_app.hpp"
#include "cmd_master_add_app.hpp"
#include "cmd_lose_master.hpp"
#include "cmd_add_gate.hpp"
#include "cmd_gate_add_app.hpp"
#include "cmd_gate_del_app.hpp"
#include "cmd_gate_stat.hpp"
#include "cmd_lose_gate.hpp"
#include "../type/type_get_free_master.hpp"
#include "mm_join_commond.hpp"
#include <cassert>
#include "mm_rpc_method.hpp"
namespace adcloud {
namespace mon {

class AddMasterFunction:public rpc::RpcService::IRpcFunction{
public:
	AddMasterFunction(Monitor* mm):self(mm){}
	virtual ~AddMasterFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TAddMasterReq::TypeName);
		type::TAddMasterReq* req = static_cast<type::TAddMasterReq*>(arg);
		CMDAddMaster* cmd = new CMDAddMaster();
		cmd->app_port = req->app_port;
		cmd->host = req->host;
		cmd->gate_port = req->gate_port;
		cmd->name = req->name;
		cmd->om_port = req->om_port;
		cmd->in_host = req->in_host;
		cmd->max_num = req->max_num;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		req->UnRef();
		cmd->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};
class LoseMasterFunction:public rpc::RpcService::IRpcFunction{
public:
	LoseMasterFunction(Monitor* mm):self(mm){}
	virtual ~LoseMasterFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TLoseMasterReq::TypeName);
		type::TLoseMasterReq* req = static_cast<type::TLoseMasterReq*>(arg);
		CMDLoseMaster* cmd = new CMDLoseMaster();
		cmd->name = req->name;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		cmd->UnRef();
		req->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};
class FGetFreeMaster:public rpc::RpcService::IRpcFunction{
public:
	FGetFreeMaster(Monitor* mm):self(mm){}
	virtual ~FGetFreeMaster(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TGetFreeMasterReq::TypeName);
		type::TGetFreeMasterReq* req = static_cast<type::TGetFreeMasterReq*>(arg);
		uint32_t num = req->app_user_num;
		std::string addr;
		std::string name;
		if(this->self->MasterHasApp(req->appid,&name)){
			err = "app is exist at " + name;
			req->UnRef();
			return NULL;
		}
		req->UnRef();
		if( self->GetFreeMaster(num,addr) ){
			type::TGetFreeMasterRsp *rsp = new type::TGetFreeMasterRsp();
			rsp->addr = addr;
			return rsp;
		}else{
			err = "no free master";
			return NULL;
		}
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	Monitor* self;
};
class MasterAddAppFunction:public rpc::RpcService::IRpcFunction{
public:
	MasterAddAppFunction(Monitor* mm):self(mm){}
	virtual ~MasterAddAppFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TAddAppReq::TypeName);
		type::TAddAppReq* req = static_cast<type::TAddAppReq*>(arg);
		CMDMasterAddApp* cmd = new CMDMasterAddApp();
		cmd->name = req->name;
		cmd->appid = req->app_id;
		cmd->num = req->num;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		cmd->UnRef();
		req->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};
class MasterDelAppFunction:public rpc::RpcService::IRpcFunction{
public:
	MasterDelAppFunction(Monitor* mm):self(mm){}
	virtual ~MasterDelAppFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){

		assert(arg->GetTypeName() == type::TDelAppReq::TypeName);
		type::TDelAppReq* req = static_cast<type::TDelAppReq*>(arg);
		CMDMasterDelApp* cmd = new CMDMasterDelApp();
		cmd->name = req->name;
		cmd->appid = req->app_id;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		cmd->UnRef();
		req->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};

class GetAppAtFunction:public rpc::RpcService::IRpcFunction{
public:
	GetAppAtFunction(Monitor* mm):self(mm){}
	virtual ~GetAppAtFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TGetAppAtReq::TypeName);
		type::TGetAppAtReq* req = static_cast<type::TGetAppAtReq*>(arg);
		type::TGetAppAtRsp* rsp = new type::TGetAppAtRsp();
		rsp->success = false;
		common::Mutex::Locker l(self->mtx_);
		Monitor::MasterMap::iterator iter;
		for(iter = self->master_map_.begin();iter != self->master_map_.end();iter++){
			if( iter->second->AppExist(req->app_id) ){
				rsp->addr = iter->second->GetGateAddr();
				rsp->success = true;
			}
		}
		req->UnRef();
		return rsp;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};
class GateStatFucntion:public rpc::RpcService::IRpcFunction{
public:
	GateStatFucntion(Monitor* mm):self(mm){}
	virtual ~GateStatFucntion(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TGateStatReq::TypeName);
		type::TGateStatReq* req = static_cast<type::TGateStatReq*>(arg);
		CMDGateStat* cmd = new CMDGateStat();
		cmd->name = req->name;
		cmd->num_client = req->num_client;
		cmd->cpu = req->cpu;
		cmd->mem = req->mem;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		cmd->UnRef();
		req->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:

	Monitor* self;
};
class AddGateFunction:public rpc::RpcService::IRpcFunction{
public:
	AddGateFunction(Monitor* mm):self(mm){}
	virtual ~AddGateFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TAddGateReq::TypeName);
		type::TAddGateReq* req = static_cast<type::TAddGateReq*>(arg);
		CMDAddGate* cmd = new CMDAddGate();
		cmd->name = req->name;
		cmd->addr = req->addr;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		cmd->UnRef();
		req->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};
class LoseGateFunction:public rpc::RpcService::IRpcFunction{
public:
	LoseGateFunction(Monitor* mm):self(mm){}
	virtual ~LoseGateFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TLoseGateReq::TypeName);
		type::TLoseGateReq* req = static_cast<type::TLoseGateReq*>(arg);
		CMDLoseGate* cmd = new CMDLoseGate();
		cmd->name = req->name;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		cmd->UnRef();
		req->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};
class GateAddAppFunction:public rpc::RpcService::IRpcFunction{
public:
	GateAddAppFunction(Monitor* mm):self(mm){}
	virtual ~GateAddAppFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TAddAppReq::TypeName);
		type::TAddAppReq* req = static_cast<type::TAddAppReq*>(arg);
		CMDGateAddApp* cmd = new CMDGateAddApp();
		cmd->name = req->name;
		cmd->appid = req->app_id;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		cmd->UnRef();
		req->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};
class GateDelAppFunction:public rpc::RpcService::IRpcFunction{
public:
	GateDelAppFunction(Monitor* mm):self(mm){}
	virtual ~GateDelAppFunction(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		assert(arg->GetTypeName() == type::TDelAppReq::TypeName);
		type::TDelAppReq* req = static_cast<type::TDelAppReq*>(arg);
		CMDGateDelApp* cmd = new CMDGateDelApp();
		cmd->name = req->name;
		cmd->appid = req->app_id;
		void* ret = self->peer_svr_->ProcessCommond(cmd,err);
		cmd->UnRef();
		req->UnRef();
		return (common::SerializationAble*)ret;
	}
	virtual void Finsh(common::SerializationAble* res){
		res->UnRef();
	}
private:
	Monitor* self;
};
class FGetMaster:public rpc::RpcService::IRpcFunction{
public:
	FGetMaster(Monitor* mm):self(mm){}
	virtual ~FGetMaster(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		if(arg) arg->UnRef();
		type::TGetMasterRsp *rsp = new type::TGetMasterRsp();
		Monitor::MasterMap::iterator iter;
		for(iter = self->master_map_.begin();iter != self->master_map_.end();iter++){
			rsp->om_map[iter->second->GetName()] = iter->second->GetOmAddr();
		}
		return rsp;
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	Monitor* self;
};


/***
 *
 *
 */

Monitor::Monitor()
:peer_svr_(NULL),
 cfg_(NULL),
 add_master_fn_(new AddMasterFunction(this)),
 lose_master_fn_(new LoseMasterFunction(this)),
 add_app_fn_(new MasterAddAppFunction(this)),
 del_app_fn_(new MasterDelAppFunction(this)),
 get_app_at_fn_(new GetAppAtFunction(this)),
 actor_(new translate::Acceptor()),
 add_gate_fn_(new AddGateFunction(this)),
 lose_gate_fn_(new LoseGateFunction(this)),
 gate_add_app_fn_(new GateAddAppFunction(this)),
 gate_del_app_fn_(new GateDelAppFunction(this)),
 gate_stat_fn_(new GateStatFucntion(this)),
 get_master_fn_(new FGetMaster(this)),
 get_free_master_fn_(new FGetFreeMaster(this))

{
	actor_->SetListener(this);
	rpc_svr_ = new rpc::RpcService();
	rpc_svr_->RegistFunction(METHOD_ADD_MASTER,add_master_fn_);
	rpc_svr_->RegistFunction(METHOD_LOSE_MASTER,lose_master_fn_);
	rpc_svr_->RegistFunction(METHOD_MASTER_ADD_APP,add_app_fn_);
	rpc_svr_->RegistFunction(METHOD_MASTER_DEL_APP,del_app_fn_);
	rpc_svr_->RegistFunction(METHOD_GET_APP_AT,get_app_at_fn_);
	rpc_svr_->RegistFunction(METHOD_GET_FREE_MASTER,get_free_master_fn_);

	rpc_svr_->RegistFunction(METHOD_ADD_GATE,add_gate_fn_);
	rpc_svr_->RegistFunction(METHOD_LOSE_GATE,lose_gate_fn_);
	rpc_svr_->RegistFunction(METHOD_GATE_ADD_APP,gate_add_app_fn_);
	rpc_svr_->RegistFunction(METHOD_GATE_DEL_APP,gate_del_app_fn_);
	rpc_svr_->RegistFunction(METHOD_GATE_STAT,gate_stat_fn_);
	rpc_svr_->RegistFunction(METHOD_GET_MASTER,get_master_fn_);

}
Monitor::~Monitor() {
	delete rpc_svr_;
	delete peer_svr_;
	delete this->actor_;
	delete add_master_fn_;
	delete lose_master_fn_;
	delete add_app_fn_;
	delete del_app_fn_;
	delete get_app_at_fn_;
	delete get_free_master_fn_;
	delete get_master_fn_;
}
bool Monitor::Init(Config* cfg){
	cfg_ = cfg;
	abb::net::IPAddr addr;
	if(!addr.SetByString(cfg->mon_addr)){
		LOG(ERROR) << "MasterMon set mon_addr fail, address:"<< cfg->mon_addr;
		return false;
	}
	abb::net::IPAddr raftaddr;
	if(!raftaddr.SetByString(cfg->raft_addr)){
		LOG(ERROR) << "MasterMon set raft_addr fail, address:"<< cfg->raft_addr;
		return false;
	}
	int error;
	if( ! this->actor_->Bind(addr,&error) ){
		LOG(ERROR) << "MasterMon bind mon_addr fail, address:"<< cfg->mon_addr << strerror(error);
		return false;
	}
	translate::Acceptor* actor = new translate::Acceptor();
	if( !actor->Bind(raftaddr,&error) ){
		LOG(ERROR) << "MasterMon bind raft_addr fail, address:"<< cfg->raft_addr  << strerror(error);
		return false;
	}
	monraft::SnapshotConf conf;
	conf.checkingInterval = 1000;
	conf.snapshotThr = 200;
	this->peer_svr_ = new monraft::PeerServer(this,this->cfg_->name,this->cfg_->raft_log_path,this->cfg_->raft_addr,actor,this,conf,this);
	return true;
}
bool Monitor::Start(){
	bool ok = this->peer_svr_->Start(this->cfg_->raft_exist_addr);
	if(ok){
		this->actor_->SetEnable(true);
		rpc_svr_->Start();
	}else{
		LOG(ERROR) << "PEER_SERVER Start Fail";
	}
	return ok;
}
raft::JoinCommond * Monitor::CreateJoinCommond(){
	return new MMJoinCommond(this->cfg_->name,this->cfg_->raft_addr,this->cfg_->mon_addr);
}
bool Monitor::Save(common::Buffer& buf){
	return true;
}
bool Monitor::Recovery(common::Buffer& buf){
	return true;
}
type::TAddMasterRsp* Monitor::DoAddMaster(const std::string& name,
		const std::string& host,
		const std::string& in_host,
		uint16_t gate_port,
		uint16_t app_port,
		uint16_t om_port,uint32_t max_num,bool bneedret)
{
	LOG(DEBUG) << "AddMaster "<< name;
	common::Mutex::Locker l(this->mtx_);
	Monitor::MasterMap::iterator iter = this->master_map_.find(name);
	type::TAddMasterRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TAddMasterRsp();
	}
	if(iter == this->master_map_.end()){
		if(rsp){
			rsp->success = true;
		}
		this->master_map_[name] = new MasterInfo(name,host,in_host,gate_port,app_port,om_port,max_num);
	}else{
		if( iter->second->host == host && iter->second->host == in_host){
			if(rsp){
				rsp->success = true;
			}
			delete iter->second;
			this->master_map_[name] = new MasterInfo(name,host,in_host,gate_port,app_port,om_port,max_num);
		}else{
			if(rsp){
				rsp->success =false;
			}
		}
	}
	return rsp;
}

type::TLoseMasterRsp* Monitor::DoLoseMaster(const std::string& name,bool bneedret){
	LOG(DEBUG) << "LoseMaster "<< name;
	type::TLoseMasterRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TLoseMasterRsp();
	}
	if(rsp)rsp->success = true;
	common::Mutex::Locker l(this->mtx_);
	Monitor::MasterMap::iterator iter = this->master_map_.find(name);
	if(iter != this->master_map_.end()){
		delete iter->second;
		this->master_map_.erase(iter);
	}
	return rsp;
}
type::TAddAppRsp* Monitor::DoMasterAddApp(const std::string& name,const std::string& appid,uint32_t max_num,bool bneedret){
	LOG(DEBUG) << "MasterAddApp "<< name << ":" << appid;
	type::TAddAppRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TAddAppRsp();
	}
	if(this->MasterHasApp(appid,NULL)){
		if(rsp)rsp->success =false;
	}else{
		common::Mutex::Locker l(this->mtx_);
		Monitor::MasterMap::iterator iter = this->master_map_.find(name);
		if(iter != this->master_map_.end()){
			if(iter->second->AppExist(appid)){
				if(rsp)rsp->success =false;
			}else{
				iter->second->AddApp(appid,max_num);
			}
		}else{
			if(rsp)rsp->success =false;
		}
	}
	return rsp;
}
bool Monitor::GetFreeMaster(uint32_t num,std::string& addr){
	common::Mutex::Locker l(this->mtx_);
	Monitor::MasterMap::iterator iter = this->master_map_.begin();
	for(;iter != this->master_map_.end();iter++){
		if(iter->second->CanAddApp(num)){
			addr = iter->second->GetAppAddr();
			return true;
		}
	}
	return false;
}
bool Monitor::MasterHasApp(const std::string& app,std::string* mastername){
	common::Mutex::Locker l(this->mtx_);
	Monitor::MasterMap::iterator iter = this->master_map_.begin();
	for(;iter != this->master_map_.end();iter++){
		if(iter->second->AppExist(app)){
			if(mastername) *mastername = iter->second->name;
			return true;
		}
	}
	return false;
}
type::TDelAppRsp* Monitor::DoMasterDelApp(const std::string& name,const std::string& appid,bool bneedret){
	LOG(DEBUG) << "MasterDelApp "<< name << ":" << appid;
	type::TDelAppRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TDelAppRsp();
	}
	common::Mutex::Locker l(this->mtx_);
	Monitor::MasterMap::iterator iter = this->master_map_.find(name);
	if(iter != this->master_map_.end()){
		if(iter->second->AppExist(appid)){
			iter->second->DelApp(appid);
			if(rsp)rsp->success = true;
		}else{
			if(rsp)rsp->success =false;
		}
	}else{
		if(rsp)rsp->success =false;
	}
	return rsp;
}

type::TAddAppRsp* Monitor::DoGateAddApp(const std::string& name,const std::string& appid,bool bneedret){
	LOG(DEBUG) << "GateAddApp "<< name << ":" << appid;
	type::TAddAppRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TAddAppRsp();
	}
	common::Mutex::Locker l(this->gate_mtx_);
	Monitor::GateMap::iterator iter = this->gate_map_.find(name);
	if(iter != this->gate_map_.end()){
		if(iter->second->AppExist(appid)){
			if(rsp)rsp->success =false;
		}else{
			iter->second->AddApp(appid);
		}
	}else{
		if(rsp)rsp->success =false;
	}
	return rsp;
}
type::TDelAppRsp* Monitor::DoGateDelApp(const std::string& name,const std::string& appid,bool bneedret){
	LOG(DEBUG) << "GateDelApp "<< name << ":" << appid;
	type::TDelAppRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TDelAppRsp();
	}
	common::Mutex::Locker l(this->gate_mtx_);
	Monitor::GateMap::iterator iter = this->gate_map_.find(name);
	if(iter != this->gate_map_.end()){
		if(iter->second->AppExist(appid)){
			iter->second->DelApp(appid);
			if(rsp)rsp->success = true;
		}else{
			if(rsp)rsp->success =false;
		}
	}else{
		if(rsp)rsp->success =false;
	}
	return rsp;
}

type::TAddGateRsp* Monitor::DoAddGate(const std::string&name,const std::string& addr,bool bneedret){
	LOG(DEBUG) << "AddGate "<< name;
	common::Mutex::Locker l(this->gate_mtx_);
	Monitor::GateMap::iterator iter = this->gate_map_.find(name);
	type::TAddGateRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TAddGateRsp();
	}
	if(iter == this->gate_map_.end()){
		if(rsp){
			rsp->success = true;
		}
		this->gate_map_[name] =  new GateInfo(name,addr);
	}else{
		if(iter->second->GetAddr() == addr){
			if(rsp){
				rsp->success =true;
			}
			delete iter->second;
			this->gate_map_[name] =  new GateInfo(name,addr);
		}else{
			if(rsp){
				rsp->success =false;
			}
		}
	}
	return rsp;
}
type::TLoseGateRsp* Monitor::DoLoseGate(const std::string&name,bool bneedret){
	LOG(DEBUG) << "LoseGate "<< name;
	type::TLoseGateRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TLoseGateRsp();
	}
	if(rsp)rsp->success = true;
	common::Mutex::Locker l(this->gate_mtx_);
	Monitor::GateMap::iterator iter = this->gate_map_.find(name);
	if(iter != this->gate_map_.end()){
		delete iter->second;
		this->gate_map_.erase(iter);
	}
	return rsp;
}

type::TGateStatRsp* Monitor::DoGateStat(const std::string& name,int num_cli,int cpu,int mem,bool bneedret){
	type::TGateStatRsp* rsp = NULL;
	if(bneedret){
		rsp = new type::TGateStatRsp();
	}
	if(rsp)rsp->success = true;
	common::Mutex::Locker l(this->gate_mtx_);
	Monitor::GateMap::iterator iter = this->gate_map_.find(name);
	if(iter != this->gate_map_.end()){
		iter->second->num_cli = num_cli;
		iter->second->cpu = cpu;
		iter->second->mem = mem;
	}
	return rsp;
}

void Monitor::L_Connection_OnMessage(translate::Connection* self,translate::Message*msg){
	if(msg->GetTag() == rpc::MRpcRequest::TAG){
		this->rpc_svr_->AsycRpcExecute(static_cast<rpc::MRpcRequest*>(msg));
	}
}
void Monitor::L_Connection_OnClose(translate::Connection* self){
	self->UnRef();
}
void Monitor::L_Acceptor_OnConnection(translate::Connection* conn){
	conn->SetListner(this);
}
} /* namespace translate */
} /* namespace adcloud */
