
#include "cmd_master_del_app.hpp"

#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {
const char* CMDMasterDelApp::CmdName = "CMDMasterDelApp";
CMDMasterDelApp::CMDMasterDelApp():raft::Commond(CmdName)  {
}

CMDMasterDelApp::~CMDMasterDelApp() {
}
common::SerializationAble* CMDMasterDelApp::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoMasterDelApp(name,appid,need_return);
}
uint32_t CMDMasterDelApp::GetLength() {
	return name.length()+1+appid.length()+1;
}
void CMDMasterDelApp::EncodeBody(common::BufferWriter &buf) {
	buf << name << appid;
}
void CMDMasterDelApp::DecodeBody(common::BufferReader &buf) {
	buf >> name >> appid;
}
} /* namespace type */
} /* namespace adcloud */
