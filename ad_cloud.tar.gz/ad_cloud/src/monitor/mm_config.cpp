
#include "mm_config.hpp"
#include "../common/string_tool.hpp"
#include "../common/log.hpp"
namespace adcloud {
namespace mon {



Config::Config() {

}
Config::~Config() {

}
bool Config::Parse(common::ArgParse& arg_parse){
	std::string val;
	if(! arg_parse.GetValue("addr",mon_addr) ){
		LOG(ERROR) << "ARG (adrr) NOT Exist";
		return false;
	}
	if( !arg_parse.GetValue("peer-addr",raft_addr) ){
		LOG(ERROR) << "ARG (peer-addr) NOT Exist";
		return false;
	}
	if( arg_parse.GetValue("peers",val) ){
		common::StringTool::Split(val,",",this->raft_exist_addr);
	}
	if( !arg_parse.GetValue("data-dir",this->raft_log_path)){
		LOG(ERROR) << "ARG (data-dir) NOT Exist";
		return false;
	}
	if( !arg_parse.GetValue("name",this->name)){
		LOG(ERROR) << "ARG (name) NOT Exist";
		return false;
	}
	return true;
}
} /* namespace mastermon */
} /* namespace adcloud */
