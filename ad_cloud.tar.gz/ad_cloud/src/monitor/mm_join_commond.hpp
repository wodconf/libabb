/*
 * mm_join_commond.hpp
 *
 *  Created on: 2014-5-13
 *      Author: wd
 */

#ifndef MM_JOIN_COMMOND_HPP_
#define MM_JOIN_COMMOND_HPP_

#include "../raft/join_commond.hpp"
namespace adcloud{
namespace mon{

class MMJoinCommond:public raft::JoinCommond {
public:
	MMJoinCommond();
	MMJoinCommond(const std::string& nodename,const std::string& addr,const std::string& mon_addr);
	virtual ~MMJoinCommond();
	virtual common::SerializationAble* Apply(raft::RaftServer*,std::string *save_error,bool need_return);
	virtual const std::string& NodeName(){
		return this->node_name_;
	}
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
private:
	std::string mon_addr_;
	std::string node_name_;
	std::string raft_addr_;
};

}
}


#endif /* MM_JOIN_COMMOND_HPP_ */
