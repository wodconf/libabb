/*
 * cmd_add_gate.cpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#include "cmd_add_gate.hpp"
#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {
const char* CMDAddGate::CmdName = "CMDAddGate";
CMDAddGate::CMDAddGate():raft::Commond(CmdName){
}

CMDAddGate::~CMDAddGate() {
}
common::SerializationAble* CMDAddGate::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoAddGate(this->name,this->addr,need_return);
}
uint32_t CMDAddGate::GetLength() {
	return name.length()+addr.length()+2;
}
void CMDAddGate::EncodeBody(common::BufferWriter &buf) {
	buf << name;
	buf << addr;
}
void CMDAddGate::DecodeBody(common::BufferReader &buf) {
	buf >> name;
	buf >> addr;
}

} /* namespace mon */
} /* namespace adcloud */
