
#ifndef MASTER_MON_CONFIG_HPP_
#define MASTER_MON_CONFIG_HPP_

#include <stdint.h>
#include <string>
#include <vector>
#include "../common/arg_parse.hpp"
namespace adcloud {
namespace mon {

class Config {
public:
	Config();
	~Config();
	bool Parse( common::ArgParse& arg_parse);
	std::string mon_addr;
	std::string raft_addr;
	std::vector<std::string> raft_exist_addr;
	std::string raft_log_path;
	std::string name;
};

} /* namespace mastermon */
} /* namespace adcloud */

#endif /* MASTER_MON_CONFIG_HPP_ */
