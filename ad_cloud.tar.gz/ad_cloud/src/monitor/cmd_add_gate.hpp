/*
 * cmd_add_gate.hpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#ifndef CMD_ADD_GATE_HPP_
#define CMD_ADD_GATE_HPP_

#include "../raft/commond.hpp"
namespace adcloud {
namespace mon {

class CMDAddGate:public raft::Commond {
public:
	static const char* CmdName;
	CMDAddGate();
	virtual ~CMDAddGate();
	std::string name;
	std::string addr;
	virtual common::SerializationAble* Apply(raft::RaftServer*,std::string *save_error,bool need_return);
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};

}}
#endif /* CMD_ADD_GATE_HPP_ */
