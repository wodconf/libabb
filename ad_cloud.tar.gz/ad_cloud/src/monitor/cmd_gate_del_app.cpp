
#include "cmd_gate_del_app.hpp"
#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {

const char* CMDGateDelApp::CmdName = "CMDGateDelApp";
CMDGateDelApp::CMDGateDelApp():raft::Commond(CmdName)  {
}

CMDGateDelApp::~CMDGateDelApp() {
}
common::SerializationAble* CMDGateDelApp::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoGateDelApp(name,appid,need_return);
}
uint32_t CMDGateDelApp::GetLength() {
	return name.length()+1+appid.length()+1;
}
void CMDGateDelApp::EncodeBody(common::BufferWriter &buf) {
	buf << name << appid;
}
void CMDGateDelApp::DecodeBody(common::BufferReader &buf) {
	buf >> name >> appid;
}

} /* namespace mon */
} /* namespace adcloud */
