/*
 * cmd_lose_master.hpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#ifndef CMD_LOSE_MASTER_HPP_
#define CMD_LOSE_MASTER_HPP_
#include "../raft/commond.hpp"
namespace adcloud {
namespace mon {

class CMDLoseMaster:public raft::Commond {
public:
	static const char* CmdName;
	CMDLoseMaster();
	virtual ~CMDLoseMaster();
	std::string name;
	virtual common::SerializationAble* Apply(raft::RaftServer*,std::string *save_error,bool need_return);
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};
} /* namespace type */
} /* namespace adcloud */

#endif /* CMD_LOSE_MASTER_HPP_ */
