
#include "cmd_master_add_app.hpp"

#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {
const char* CMDMasterAddApp::CmdName = "CMDMasterAddApp";
CMDMasterAddApp::CMDMasterAddApp():raft::Commond(CmdName),num(0) {
}

CMDMasterAddApp::~CMDMasterAddApp() {
}
common::SerializationAble* CMDMasterAddApp::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoMasterAddApp(name,appid,num,need_return);
}
uint32_t CMDMasterAddApp::GetLength() {
	return name.length()+1+appid.length()+1 + sizeof(num);
}
void CMDMasterAddApp::EncodeBody(common::BufferWriter &buf) {
	buf << name << appid;
	buf.NET_WriteUint32(num);
}
void CMDMasterAddApp::DecodeBody(common::BufferReader &buf) {
	buf >> name >> appid;
	num = buf.HOST_ReadUint32();
}
} /* namespace type */
} /* namespace adcloud */
