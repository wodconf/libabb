
#include "cmd_add_master.hpp"
#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {
const char* CMDAddMaster::CmdName = "CMDAddMaster";
CMDAddMaster::CMDAddMaster():raft::Commond(CmdName), gate_port(0),app_port(0),om_port(0),max_num(0) {
}

CMDAddMaster::~CMDAddMaster() {
}
common::SerializationAble* CMDAddMaster::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoAddMaster(this->name,this->host,in_host,gate_port,app_port,om_port,max_num,need_return);
}
uint32_t CMDAddMaster::GetLength() {
	return name.length()+1+host.length()+1+in_host.length()+1+sizeof(uint16_t)*3 + sizeof(max_num);
}
void CMDAddMaster::EncodeBody(common::BufferWriter &buf) {
	buf << name;
	buf << host;
	buf << in_host;
	buf.NET_WriteUint16(gate_port);
	buf.NET_WriteUint16(app_port);
	buf.NET_WriteUint16(om_port);
	buf.NET_WriteUint32(max_num);
}
void CMDAddMaster::DecodeBody(common::BufferReader &buf) {
	buf >> name;
	buf >> host;
	buf >> in_host;
	gate_port = buf.HOST_ReadUint16();
	app_port = buf.HOST_ReadUint16();
	om_port = buf.HOST_ReadUint16();
	max_num = buf.HOST_ReadUint32();
}
} /* namespace type */
} /* namespace adcloud */
