/*
 * cmd_gate_stat.hpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#ifndef CMD_GATE_STAT_HPP_
#define CMD_GATE_STAT_HPP_
#include "../raft/commond.hpp"
namespace adcloud {
namespace mon {
class CMDGateStat:public raft::Commond {
public:
	static const char* CmdName;
	CMDGateStat();
	virtual ~CMDGateStat();
	std::string name;
	uint16_t num_client;
	uint16_t cpu;
	uint32_t mem;
	virtual common::SerializationAble* Apply(raft::RaftServer*,std::string *save_error,bool need_return);
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};

} /* namespace mon */
} /* namespace adcloud */

#endif /* CMD_GATE_STAT_HPP_ */
