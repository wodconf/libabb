/*
 * cmd_lose_gate.hpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#ifndef CMD_LOSE_GATE_HPP_
#define CMD_LOSE_GATE_HPP_
#include "../raft/commond.hpp"
namespace adcloud {
namespace mon {

class CMDLoseGate:public raft::Commond {
public:
	static const char* CmdName;
	CMDLoseGate();
	virtual ~CMDLoseGate();
	std::string name;
	virtual common::SerializationAble* Apply(raft::RaftServer*,std::string *save_error,bool need_return);
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};
} /* namespace mon */
} /* namespace adcloud */

#endif /* CMD_LOSE_GATE_HPP_ */
