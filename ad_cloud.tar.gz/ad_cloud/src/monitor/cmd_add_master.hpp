
#ifndef CMD_ADD_MASTER_HPP_
#define CMD_ADD_MASTER_HPP_

#include "../raft/commond.hpp"
namespace adcloud {
namespace mon {

class CMDAddMaster:public raft::Commond {
public:
	static const char* CmdName;
	CMDAddMaster();
	virtual ~CMDAddMaster();
	std::string name;
	std::string host;
	std::string in_host;
	uint16_t gate_port;
	uint16_t app_port;
	uint16_t om_port;
	uint32_t max_num;
	virtual common::SerializationAble* Apply(raft::RaftServer*,std::string *save_error,bool need_return);
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};

} /* namespace type */
} /* namespace adcloud */

#endif /* CMD_ADD_MASTER_HPP_ */
