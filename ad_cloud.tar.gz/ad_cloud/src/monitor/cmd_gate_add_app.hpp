
#ifndef CMD_GATE_ADD_APP_HPP_
#define CMD_GATE_ADD_APP_HPP_

#include "../raft/commond.hpp"

namespace adcloud {
namespace mon {

class CMDGateAddApp:public raft::Commond {
public:
	static const char* CmdName;
	CMDGateAddApp();
	virtual ~CMDGateAddApp();
	std::string name;
	std::string appid;
	virtual common::SerializationAble* Apply(raft::RaftServer*,std::string *save_error,bool need_return);
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};
} /* namespace mon */
} /* namespace adcloud */

#endif /* CMD_GATE_ADD_APP_HPP_ */
