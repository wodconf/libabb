/*
 * mm_gate_info.hpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#ifndef MM_GATE_INFO_HPP_
#define MM_GATE_INFO_HPP_

#include <string>
#include <set>
namespace adcloud {
namespace mon {

class GateInfo {
public:
	GateInfo(const std::string& name,const std::string& addr):name(name),addr(addr),num_cli(0),cpu(0),mem(0){

	}
	~GateInfo(){}
	void AddApp(const std::string& appid){
		if(app_set_.find(appid) == app_set_.end()){
			app_set_.insert(appid);
		}
	}
	void DelApp(const std::string& appid){
		AppSet::iterator iter = app_set_.find(appid);
		if(iter != app_set_.end()){
			app_set_.erase(iter);
		}
	}
	bool AppExist(const std::string& appid){
		return app_set_.find(appid) != app_set_.end();
	}
	const std::string& GetAddr(){
		return addr;
	}
	const std::string& GetName(){return name;}
public:
	int num_cli;
	int cpu;
	int mem;
private:
	std::string name;
	std::string addr;
	typedef std::set<std::string> AppSet;
	AppSet app_set_;

};

} /* namespace type */
} /* namespace adcloud */

#endif /* MM_GATE_INFO_HPP_ */
