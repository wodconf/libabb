
#include "cmd_gate_add_app.hpp"
#include "mm_monitor.hpp"
namespace adcloud {
namespace mon {
const char* CMDGateAddApp::CmdName = "CMDGateAddApp";
CMDGateAddApp::CMDGateAddApp():raft::Commond(CmdName) {
}

CMDGateAddApp::~CMDGateAddApp() {
}
common::SerializationAble* CMDGateAddApp::Apply(raft::RaftServer* raft_svr,std::string *save_error,bool need_return){
	Monitor* mon = static_cast<Monitor*>( raft_svr->Context() );
	return mon->DoGateAddApp(name,appid,need_return);
}
uint32_t CMDGateAddApp::GetLength() {
	uint32_t sz=  name.length()+1+appid.length()+1;
	return sz;
}
void CMDGateAddApp::EncodeBody(common::BufferWriter &buf) {
	buf << name << appid;
}
void CMDGateAddApp::DecodeBody(common::BufferReader &buf) {
	buf >> name >> appid;
}


} /* namespace mon */
} /* namespace adcloud */
