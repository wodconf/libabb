/*
 * cmd_del_app.hpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#ifndef CMD_DEL_APP_HPP_
#define CMD_DEL_APP_HPP_

#include "../raft/commond.hpp"
namespace adcloud {
namespace mon {

class CMDMasterDelApp:public raft::Commond {
public:
	static const char* CmdName;
	CMDMasterDelApp();
	virtual ~CMDMasterDelApp();
	std::string name;
	std::string appid;
	virtual common::SerializationAble* Apply(raft::RaftServer*,std::string *save_error,bool need_return);
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf);
	virtual void DecodeBody(common::BufferReader &buf);
};

} /* namespace type */
} /* namespace adcloud */

#endif /* CMD_DEL_APP_HPP_ */
