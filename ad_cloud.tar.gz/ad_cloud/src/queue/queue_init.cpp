/*
 * queue_init.cpp
 *
 *  Created on: 2014-5-21
 *      Author: wd
 */


#include "queue_init.hpp"
#include "type_queue.hpp"
#include "type_queue_message.hpp"
#include "queue_config.hpp"

namespace adcloud {
namespace queue {
bool Init(int queue_time_out_second,
		int queue_message_df,
		int queue_auth_times){
	if( QueueConfig::Instance().Init(queue_time_out_second,queue_message_df,queue_auth_times) ){
		common::SerializationAble::RegistCreator(TQueueMessageRequest::TypeName,common::T_SerializationAbleCreator<TQueueMessageRequest>);
		common::SerializationAble::RegistCreator(TQueueMessageResponce::TypeName,common::T_SerializationAbleCreator<TQueueMessageResponce>);
		common::SerializationAble::RegistCreator(TQueueRequest::TypeName,common::T_SerializationAbleCreator<TQueueRequest>);
		common::SerializationAble::RegistCreator(TQueueResponce::TypeName,common::T_SerializationAbleCreator<TQueueResponce>);
		return true;
	}else{
		return false;
	}

}
}
}
