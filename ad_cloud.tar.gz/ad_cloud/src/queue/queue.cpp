/*
 * queue.cpp
 *
 *  Created on: 2014-5-21
 *      Author: wd
 */

#include "queue.hpp"
#include "queue_config.hpp"
#include "queue_translate.hpp"
#include "queue_code.hpp"
#include "../common/time.hpp"
namespace adcloud {
namespace queue {

Queue::Queue(const std::string& id,Listener* lis,const std::string& addr,QueueTranslate* tr)
:id_(id),
 lis_(lis),
 buf_chan_(256),
 bstop_(false),
 timeout_(0),
 addr_(addr),
 translate_(tr),
 keep_alive_timeout_(0),
 pre_buf_(NULL)
{
}

Queue::~Queue() {

}
bool Queue::Open(const std::string& selfaddr){
	int index = 0;
	bool bok = false;
	while(index <QueueConfig::Instance().GetQueueAuthTimes() && !this->bstop_){
		TQueueRequest req;
		req.name = this->GetName();
		req.addr = selfaddr;
		std::string err;
		TQueueResponce* rsp = translate_->SendOpenQueue(addr_,&req,err);

		if(rsp){
			bok =  rsp->code == CODE_SUCCESS;
			rsp->UnRef();
			break;
		}else{
			LOG(DEBUG) << "err:" << err;
		}
		index++;
		common::time::Sleep(1000);
	}
	return bok;
}
void Queue::Leave(){
	int index = 0;
	while(index < 2 ){
		TQueueRequest req;
		req.name =  this->id_;
		std::string err;
		TQueueResponce* rsp =  translate_->SendCloseQueue(this->addr_,&req,err);
		if(rsp){
			rsp->UnRef();
			break;
		}
		index++;
	}
}
void Queue::Start(){
	thread_.Start(ThreadMain,this);
	thread_send_.Start(ThreadMainSend,this);
	pthread_detach(thread_.ID());
	pthread_detach(thread_send_.ID());
}
void Queue::Stop(){
	lis_ = NULL;
	this->bstop_ = true;
	buf_chan_.Push(NULL);
}
void Queue::PushMessage(translate::Message* msg){
	if(!msg) return;
	common::Mutex::Locker l( mtx_ );
	if(this->bstop_) return;
	msg->Ref();
	cur_list_.push_back(msg);
}
void Queue::NotifyMessage(abb::base::Buffer *buf){
	this->timeout_ = 0;
	if(buf){
		buf_chan_.Push(buf);
	}
}
abb::base::Buffer* Queue::GetBuffer(){
		mtx_.Lock();
		if(cur_list_.size() > 0){
			MsgList tmp = cur_list_;
			cur_list_.clear();
			mtx_.UnLock();
			//abb::base::Buffer* buf = new abb::base::Buffer();
			if(tmp.size() > 5000){
				LOG(DEBUG) << this->id_<<".queue.cache.size" << tmp.size();
			}
			for(int i=0;i<tmp.size();i++){
				//tmp[i]->Encode(*buf);
				tmp[i]->UnRef();
			}
			//return buf;
			return NULL;
		}
		else{
			mtx_.UnLock();
			return NULL;
		}
	}
void Queue::Loop(){
	this->Ref();
	while(!bstop_){
		abb::base::Buffer *buf = NULL;
		if( buf_chan_.PollTimeout(1000,&buf) ){
			if(!buf){
				continue;
			}
			common::BufferReader sbuf(buf->Data(),buf->Size());
			while( sbuf.DataSize() > 0 && lis_){
				translate::Message* msg = translate::Message::DecodeMessage(sbuf);
				if(msg){
					buf->GaveRd(msg->Length());
					Listener* lis = lis_;
					if(lis)lis->L_Queue_OnMessage(this,msg);
					msg->UnRef();
				}else{
					LOG(INFO) << this->id_ <<".queue.parse.message.fail.size=" << sbuf.DataSize();
					break;
				}
			}
			delete buf;
		}else{
			this->timeout_++;
			if(this->timeout_ >= QueueConfig::Instance().GetQueueTimeoutSecond()){
				LOG(DEBUG) << this->id_<<".queue.timeout";
				bstop_ = true;
			}
		}
	}

	abb::base::Buffer *buf = NULL;
	while(buf_chan_.PollTimeout(0,&buf)){
		if(buf) delete buf;
	}
	this->Leave();
	Listener* lis = lis_;
	if(lis) lis->L_Queue_OnTimeout(this);
	this->UnRef();
}
void Queue::LoopSend(){
	this->Ref();
	int config_df = QueueConfig::Instance().GetQueueMessageDiff();
	while(!this->bstop_){
		if(this->notify_.WaitTimeout(config_df)) continue;
		abb::base::Buffer* buf = NULL;
		if(pre_buf_){
			buf = pre_buf_;
			pre_buf_ = NULL;
		}else{
			buf = this->GetBuffer();
		}
		bool bflush  = false;
		if(buf){
			bflush = true;
		}else{
			keep_alive_timeout_++;
			if(keep_alive_timeout_*config_df > 1000){
				bflush = true;
			}
		}
		if(!bflush) continue;
		keep_alive_timeout_ = 0;
		TQueueMessageRequest req;
		req.queue_id =  this->GetName();
		req.buf = buf;
		std::string err;
		TQueueMessageResponce* rsp = this->translate_->SendQueueMessage(this->addr_,&req,err);
		if(!rsp){
			if(buf){
				req.buf = NULL;
				pre_buf_ = buf;
			}
		}else{
			if(buf)delete buf;
			if(rsp->code != CODE_SUCCESS && rsp->code != CODE_QUEUE_EMPTY){
				LOG(DEBUG) << this->id_<<".queue.close.code" << rsp->code;
				this->bstop_ =true;
			}
			rsp->UnRef();
		}
	}
	for(int i=0;i<cur_list_.size();i++){
		cur_list_[i]->UnRef();
	}
	if(pre_buf_)delete pre_buf_;
	this->UnRef();
}
} /* namespace queue */
} /* namespace adcloud */
