/*
 * queue_translate.cpp
 *
 *  Created on: 2014-5-29
 *      Author: wd
 */

#include "queue_translate.hpp"
#include "queue_rpc_function.hpp"
namespace adcloud {
namespace queue {

QueueTranslate::QueueTranslate() {
	// TODO Auto-generated constructor stub

}

QueueTranslate::~QueueTranslate() {
	// TODO Auto-generated destructor stub
}
TQueueResponce* QueueTranslate::SendOpenQueue(const std::string& addr,TQueueRequest* req,std::string& err){
	return static_cast<TQueueResponce*>(pool_.Call(addr,QUEUE_OPEN,req,err));
}
TQueueResponce* QueueTranslate::SendCloseQueue(const std::string& addr,TQueueRequest* req,std::string& err){
	return static_cast<TQueueResponce*>(pool_.Call(addr,QUEUE_CLOSE,req,err));
}
TQueueMessageResponce* QueueTranslate::SendQueueMessage(const std::string& addr,TQueueMessageRequest* req,std::string& err){
	return static_cast<TQueueMessageResponce*>(pool_.Call(addr,QUEUE_MESSAGE,req,err));
}
//TQueueResponce* rsp = static_cast<TQueueResponce*>(this->client_->Call(QUEUE_OPEN,&req,err));
} /* namespace monprxoy */
} /* namespace adcloud */
