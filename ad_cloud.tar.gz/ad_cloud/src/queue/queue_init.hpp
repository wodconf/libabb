
#ifndef QUEUE_INIT_HPP_
#define QUEUE_INIT_HPP_


namespace adcloud {
namespace queue {
bool Init(int queue_time_out_second,
int queue_message_df,
int queue_auth_times);
}
}


#endif /* QUEUE_INIT_HPP_ */
