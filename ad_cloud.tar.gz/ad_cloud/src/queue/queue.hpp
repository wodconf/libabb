
#ifndef ADCLOUD_QUEUE_HPP_
#define ADCLOUD_QUEUE_HPP_
#include <abb/base/buffer.hpp>
#include "../translate/message.hpp"
#include "../common/mutex.hpp"
#include "../common/chan.hpp"
#include "../common/thread.hpp"
#include "../common/notification.hpp"
#include "../common/ref_object.hpp"
#include "../translate/client_pool.hpp"
#include "../rpc/rpc_client.hpp"
#include <map>
namespace adcloud {
namespace queue {
class QueueTranslate;
class Queue :public common::RefObject{
public:
	class Listener{
	public:
		virtual ~Listener(){}
		virtual void L_Queue_OnMessage(Queue*,translate::Message* msg) = 0;
		virtual void L_Queue_OnTimeout(Queue*) = 0;
	};
	Queue(const std::string& id,Listener* lis,const std::string& addr,QueueTranslate* tr);
	~Queue();
	bool Open(const std::string& selfaddr);
	void Start();
	void Stop();
	void PushMessage(translate::Message* msg);
	void NotifyMessage(abb::base::Buffer *buf);
	const std::string& GetName(){
		return id_;
	}
private:
	void Leave();
	abb::base::Buffer* GetBuffer();
	static void* ThreadMain(void*arg){
		Queue* chan = (Queue*)arg;
		chan->Loop();
		return NULL;
	}

	void Loop();
	static void* ThreadMainSend(void*arg){
		Queue* chan = (Queue*)arg;
		chan->LoopSend();
		return NULL;
	}

	void LoopSend();
private:
	bool bstop_;
	std::string id_;
	abb::base::Buffer* pre_buf_;
	common::Mutex mtx_;
	Listener* lis_;
	common::Thread thread_;
	common::Thread thread_send_;
	common::Chan<abb::base::Buffer *> buf_chan_;
	int timeout_;
	QueueTranslate* translate_;
	std::string addr_;
	common::Notification notify_;
	int keep_alive_timeout_;
	typedef std::vector<translate::Message*> MsgList;
	MsgList cur_list_;
};

} /* namespace queue */
} /* namespace adcloud */

#endif /* QUEUE_HPP_ */
