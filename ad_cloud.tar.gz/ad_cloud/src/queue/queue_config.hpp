/*
 * queue_config.hpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#ifndef QUEUE_CONFIG_HPP_
#define QUEUE_CONFIG_HPP_
#include "../common/config_file.hpp"
namespace adcloud {
namespace queue {

class QueueConfig {
public:
	int GetQueueTimeoutSecond(){
		return queue_time_out_second;
	}
	int GetQueueMessageDiff(){
		return queue_message_df;
	}
	int GetQueueAuthTimes(){
		return queue_auth_times;
	}
	bool Init(int timeout,int df,int auth){
		if( timeout > 0 && df > 0 && auth > 0){
			queue_time_out_second = timeout;
			queue_message_df  = df;
			queue_auth_times  = auth;
			return true;
		}
		return false;
	};
private:
	int queue_time_out_second;
	int queue_message_df;
	int queue_auth_times;
public:
	static QueueConfig& Instance(){
		return instance;
	}
private:
	QueueConfig();
	~QueueConfig();
	static QueueConfig instance;
};
} /* namespace monraft */
} /* namespace adcloud */

#endif /* QUEUE_CONFIG_HPP_ */
