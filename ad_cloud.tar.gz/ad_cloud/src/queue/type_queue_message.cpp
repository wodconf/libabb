
#include "type_queue_message.hpp"
#include <cassert>
namespace adcloud {
namespace queue {

const char * TQueueMessageRequest::TypeName = "QMSGREQ";
TQueueMessageRequest::TQueueMessageRequest():common::SerializationAble(TypeName),buf(NULL){

}
TQueueMessageRequest::~TQueueMessageRequest(){
}
uint32_t TQueueMessageRequest::GetLength() {
	uint32_t sz = queue_id.length() + 1;
	if(buf){
		sz += buf->Size();
	}
	return sz;
}
void TQueueMessageRequest::EncodeBody(common::BufferWriter &w) {
	w << queue_id;
	if(buf){
		w.Write(buf->Data(),buf->Size());
	}
}
void TQueueMessageRequest::DecodeBody(common::BufferReader &r) {
	r >> queue_id;
	if(r.DataSize() > 0){
		buf = new abb::base::Buffer();
		buf->Write(r.DataPtr(),r.DataSize());
	}
}
TQueueMessageResponce::TQueueMessageResponce():common::SerializationAble(TypeName),code(0){

}
TQueueMessageResponce::~TQueueMessageResponce(){
}
uint32_t TQueueMessageResponce::GetLength() {
	uint32_t sz = sizeof(code);
	return sz;
}
void TQueueMessageResponce::EncodeBody(common::BufferWriter &w) {
	w << code;
}
void TQueueMessageResponce::DecodeBody(common::BufferReader &r) {
	r >> code;
}
const char * TQueueMessageResponce::TypeName  = "QMSGRSP";
} /* namespace queue */
} /* namespace adcloud */
