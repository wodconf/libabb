

#ifndef QUEUE_SERVICE_HPP_
#define QUEUE_SERVICE_HPP_

#include "../rpc/rpc_service.hpp"
#include <string>
#include "../translate/message.hpp"
#include "../common/rw_lock.hpp"
#include "queue.hpp"
#include <map>
namespace adcloud {
namespace queue {
class FQueueOpen;
class FQueueMessage;
class FQueueClose;
class TQueueResponce;
class TQueueMessageResponce;
class QueueTranslate;
class QueueService :public Queue::Listener{
public:
	class Listener{
	public:
		virtual ~Listener(){}
		virtual void L_QueueService_OnQueueOpen(const std::string& id) = 0;
		virtual void L_QueueService_OnQueueMessage(const std::string& id,translate::Message* msg) = 0;
		virtual void L_QueueService_OnQueueClose(const std::string& id) = 0;
	};
	class IAuth{
	public:
		virtual ~IAuth(){}
		virtual bool AuthOk(const std::string& id) = 0;
	};
	QueueService(Listener* lis,IAuth* auth,rpc::RpcService * rpc,const std::string& addr);
	virtual ~QueueService();
	bool PushMessageToQueue(const std::string& id,translate::Message* msg);
	bool CloseQueue(const std::string& id);
	bool HasQueue(const std::string& id);
	virtual void L_Queue_OnMessage(Queue*,translate::Message* msg);
	virtual void L_Queue_OnTimeout(Queue*);
	bool OpenQueue(const std::string& id,const std::string& addr);
private:
	TQueueResponce* OnOpenQueue(const std::string& id,const std::string& addr);
	TQueueResponce* OnCloseQueue(const std::string& id);
	TQueueMessageResponce* OnQueueMessage(const std::string& id,abb::base::Buffer *buf);
private:
	bool AuthCAS(const std::string& id);
	void EraseAuth(const std::string& id);
	void AddQueue(const std::string& id,Queue* q);
	Queue* GetQueue(const std::string& id);
private:
	friend class FQueueOpen;
	friend class FQueueMessage;
	friend class FQueueClose;
	FQueueOpen* f_open_;
	FQueueMessage* f_msg_;
	FQueueClose* f_close_;
	typedef std::map< std::string,Queue*> QueueMap;
	typedef std::set< std::string> StringSet;
	StringSet authing_set_;
	common::Mutex authing_mutx_;
	QueueMap queue_map_;
	common::RWLock rw_lock_;
	Listener* lis_;
	IAuth* auth_;
	rpc::RpcService * rpc_svr_;
	QueueTranslate* translate_;
	std::string addr_;
};

} /* namespace queue */
} /* namespace adcloud */

#endif /* QUEUE_SERVICE_HPP_ */
