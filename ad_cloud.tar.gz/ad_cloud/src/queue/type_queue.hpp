/*
 * type_queue.hpp
 *
 *  Created on: 2014-5-21
 *      Author: wd
 */

#ifndef TYPE_QUEUE_HPP_
#define TYPE_QUEUE_HPP_
#include "../common/serialization_able.hpp"
#include <stdint.h>
namespace adcloud {
namespace queue {


class TQueueRequest:public common::SerializationAble{
public:
	static const char * TypeName;
	TQueueRequest();
	virtual ~TQueueRequest();
public:
	std::string name;
	std::string addr;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TQueueResponce:public common::SerializationAble{
public:
	static const char * TypeName;
	TQueueResponce();
	virtual ~TQueueResponce();
public:
	uint8_t code;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};

} /* namespace queue */
} /* namespace adcloud */

#endif /* TYPE_QUEUE_HPP_ */
