
#ifndef TYPE_QUEUE_PUSH_MESSAGE_HPP_
#define TYPE_QUEUE_PUSH_MESSAGE_HPP_
#include "../common/serialization_able.hpp"
#include <stdint.h>
#include <abb/base/buffer.hpp>
namespace adcloud {
namespace queue {
class TQueueMessageRequest:public common::SerializationAble {
public:
	static const char * TypeName;
	TQueueMessageRequest();
	virtual ~TQueueMessageRequest();
	std::string queue_id;
	abb::base::Buffer* buf;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};

class TQueueMessageResponce:public common::SerializationAble{
public:
	static const char * TypeName;
	TQueueMessageResponce();
	virtual ~TQueueMessageResponce();
	uint8_t code;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};


} /* namespace queue */
} /* namespace adcloud */

#endif /* TYPE_QUEUE_PUSH_MESSAGE_HPP_ */
