

#include "queue_service.hpp"
#include "queue_rpc_function.hpp"
#include "queue_code.hpp"
#include "type_queue.hpp"
#include "type_queue_message.hpp"
#include "queue_translate.hpp"
#include "queue.hpp"
#include <cassert>
namespace adcloud {
namespace queue {
class FQueueOpen:public rpc::RpcService::IRpcFunction{
public:
	FQueueOpen(QueueService* mm):self(mm){}
	virtual ~FQueueOpen(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		TQueueRequest * req = static_cast<TQueueRequest*> (arg);
		common::SerializationAble*  ret =  self->OnOpenQueue(req->name,req->addr);
		arg->UnRef();
		return ret;
	}
	virtual void  Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	QueueService* self;
};
class FQueueMessage:public rpc::RpcService::IRpcFunction{
public:
	FQueueMessage(QueueService* mm):self(mm){}
	virtual ~FQueueMessage(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		TQueueMessageRequest * req = static_cast<TQueueMessageRequest*> (arg);
		TQueueMessageResponce*  rsp =  self->OnQueueMessage(req->queue_id,req->buf);
		arg->UnRef();
		return rsp;
	}
	virtual void  Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	QueueService* self;
};
class FQueueClose:public rpc::RpcService::IRpcFunction{
public:
	FQueueClose(QueueService* mm):self(mm){}
	virtual ~FQueueClose(){}
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& err){
		TQueueRequest * req = static_cast<TQueueRequest*> (arg);
		common::SerializationAble*  ret =  self->OnCloseQueue(req->name);
		arg->UnRef();
		return ret;
	}
	virtual void  Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	QueueService* self;
};
QueueService::QueueService(Listener* lis,IAuth* auth,rpc::RpcService * rpc,const std::string& addr):lis_(lis),auth_(auth),rpc_svr_(rpc),addr_(addr) {
	// TODO Auto-generated constructor stub
	f_open_ = new FQueueOpen(this);
	f_msg_  = new FQueueMessage(this);
	f_close_  = new FQueueClose(this);
	rpc_svr_->RegistFunction(QUEUE_OPEN,f_open_);
	rpc_svr_->RegistFunction(QUEUE_MESSAGE,f_msg_);
	rpc_svr_->RegistFunction(QUEUE_CLOSE,f_close_);
	translate_ = new QueueTranslate();
}
QueueService::~QueueService() {
	rpc_svr_->UnRegistFunction(QUEUE_OPEN,f_open_);
	rpc_svr_->UnRegistFunction(QUEUE_MESSAGE,f_msg_);
	rpc_svr_->UnRegistFunction(QUEUE_CLOSE,f_close_);
	delete f_open_;
	delete f_msg_;
	delete f_close_;
}

bool QueueService::PushMessageToQueue(const std::string& id,translate::Message* msg){
	common::RWLock::RLocker r(rw_lock_);
	QueueMap::iterator iter = this->queue_map_.find(id);
	if(iter != this->queue_map_.end()){
		iter->second->PushMessage(msg);
		return true;
	}
	return false;
}
bool QueueService::CloseQueue(const std::string& id){
	Queue* q = NULL;
	{
		common::RWLock::WLocker W(rw_lock_);
		QueueMap::iterator iter = this->queue_map_.find(id);
		if(iter != this->queue_map_.end()){
			queue_map_.erase(iter);
			q = iter->second;
		}
	}
	if(q){
		q->Stop();
		q->UnRef();
		return true;
	}else{
		return false;
	}
}
bool QueueService::AuthCAS(const std::string& id){
	common::Mutex::Locker l(authing_mutx_);
	if( this->authing_set_.find(id) != this->authing_set_.end() ){
		return false;
	}else{
		this->authing_set_.insert(id);
	}
	return true;
}
void QueueService::EraseAuth(const std::string& id){
	common::Mutex::Locker l(authing_mutx_);
	StringSet::iterator iter = this->authing_set_.find(id);
	if( iter != this->authing_set_.end() ){
		authing_set_.erase(iter);
	}
}
void QueueService::AddQueue(const std::string& id,Queue* q){
	common::RWLock::WLocker W(rw_lock_);
	this->queue_map_[id] = q;
}
bool QueueService::OpenQueue(const std::string& id,const std::string& addr){
	if(this->HasQueue(id)){
		return false;
	}
	if(!AuthCAS(id)){
		return false;
	}
	Queue *queue = new Queue(id,this,addr,translate_);
	if( queue->Open(this->addr_) ){
		AddQueue(id,queue);
		EraseAuth(id);
		queue->Start();
		return true;
	}
	EraseAuth(id);
	delete queue;
	return false;
}
bool QueueService::HasQueue(const std::string& id){
	common::RWLock::RLocker r(rw_lock_);
	QueueMap::iterator iter = this->queue_map_.find(id);
	return (iter != this->queue_map_.end());
}
Queue* QueueService::GetQueue(const std::string& id){
	common::RWLock::RLocker r(rw_lock_);
	QueueMap::iterator iter = this->queue_map_.find(id);
	if((iter != this->queue_map_.end())){
		iter->second->Ref();
		return iter->second;
	}
	return NULL;
}
void QueueService::L_Queue_OnMessage(Queue* q,translate::Message* msg){
	this->lis_->L_QueueService_OnQueueMessage(q->GetName(),msg);
}
void QueueService::L_Queue_OnTimeout(Queue* q){
	std::string id = q->GetName();
	LOG(WARN) << id <<".queue.timeout";
	if(this->CloseQueue(id)){
		this->lis_->L_QueueService_OnQueueClose(id);
	}
}
TQueueResponce* QueueService::OnOpenQueue(const std::string& id,const std::string& addr){
	TQueueResponce* rsp = new TQueueResponce();
	abb::net::IPAddr ipaddr;
	if( !ipaddr.SetByString(addr) ){
		rsp->code = CODE_ARGUMENTS_ERROR;
		return rsp;
	}
	if(this->HasQueue(id)){
		rsp->code = CODE_QUEUE_OPEND;
		return rsp;
	}
	if(!AuthCAS(id)){
		rsp->code = CODE_QUEUE_OPEND;
		return rsp;
	}
	if(this->auth_->AuthOk(id)){
		Queue *queue = new Queue(id,this,addr,translate_);
		AddQueue(id,queue);
		EraseAuth(id);
		queue->Start();
		this->lis_->L_QueueService_OnQueueOpen(id);
		rsp->code = CODE_SUCCESS;
	}else{
		EraseAuth(id);
		rsp->code = CODE_AUTH_FAIL;
	}
	return rsp;
}
TQueueResponce* QueueService::OnCloseQueue(const std::string& id){
	TQueueResponce* rsp = new TQueueResponce();
	if(this->CloseQueue(id)){
		rsp->code = CODE_SUCCESS;
		this->lis_->L_QueueService_OnQueueClose(id);
	}else{
		rsp->code = CODE_QUEUE_CLOSED;
	}
	return rsp;
}
TQueueMessageResponce* QueueService::OnQueueMessage(const std::string& id,abb::base::Buffer *buf){
	common::RWLock::RLocker r(rw_lock_);
	TQueueMessageResponce* rsp = new TQueueMessageResponce();
	Queue* que = GetQueue(id);
	if( !que){
		rsp->code = CODE_QUEUE_CLOSED;
	}else{
		rsp->code = CODE_SUCCESS;
		que->NotifyMessage(buf);
		que->UnRef();
	}
	return rsp;
}
} /* namespace queue */
} /* namespace adcloud */
