/*
 * queue_config.cpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#include "queue_config.hpp"

namespace adcloud {
namespace queue {
QueueConfig QueueConfig::instance;
QueueConfig::QueueConfig() {
	queue_time_out_second = 10;
	queue_message_df = 25;
	queue_auth_times = 10;
}

QueueConfig::~QueueConfig() {
	// TODO Auto-generated destructor stub
}

} /* namespace monraft */
} /* namespace adcloud */
