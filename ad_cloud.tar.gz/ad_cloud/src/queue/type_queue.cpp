/*
 * type_queue.cpp
 *
 *  Created on: 2014-5-21
 *      Author: wd
 */

#include "type_queue.hpp"

namespace adcloud {
namespace queue {

const char * TQueueRequest::TypeName = "adcloud.queue.TQueueRequest";
TQueueRequest::TQueueRequest():common::SerializationAble(TypeName){

}
TQueueRequest::~TQueueRequest(){

}
uint32_t TQueueRequest::GetLength() {
	return name.size() + 1 + addr.size() + 1;
}
void TQueueRequest::EncodeBody(common::BufferWriter &buf) {
	buf << name << addr;
}
void TQueueRequest::DecodeBody(common::BufferReader &buf) {
	buf >> name >> addr;
}
const char * TQueueResponce::TypeName = "adcloud.queue.TQueueResponce";
TQueueResponce::TQueueResponce():common::SerializationAble(TypeName),code(0){

}
TQueueResponce::~TQueueResponce(){

}
uint32_t TQueueResponce::GetLength() {
	return sizeof(code);
}
void TQueueResponce::EncodeBody(common::BufferWriter &buf) {
	buf << code;
}
void TQueueResponce::DecodeBody(common::BufferReader &buf) {
	buf >> code;
}

} /* namespace queue */
} /* namespace adcloud */
