/*
 * queue_translate.hpp
 *
 *  Created on: 2014-5-29
 *      Author: wd
 */

#ifndef QUEUE_TRANSLATE_HPP_
#define QUEUE_TRANSLATE_HPP_

#include "type_queue.hpp"
#include "type_queue_message.hpp"

#include "../rpc/rpc_client_pool.hpp"

namespace adcloud {
namespace queue {

class QueueTranslate{
public:
	QueueTranslate();
	~QueueTranslate();
	TQueueResponce* SendOpenQueue(const std::string& addr,TQueueRequest* req,std::string& err);
	TQueueResponce* SendCloseQueue(const std::string& addr,TQueueRequest* req,std::string& err);
	TQueueMessageResponce* SendQueueMessage(const std::string& addr,TQueueMessageRequest* req,std::string& err);
private:
	rpc::RpcClientPool pool_;

};

} /* namespace monprxoy */
} /* namespace adcloud */

#endif /* QUEUE_TRANSLATE_HPP_ */
