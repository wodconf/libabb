/*
 * type_get_free_master.cpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#include "type_get_free_master.hpp"

namespace adcloud {
namespace type {
const char * TGetFreeMasterReq::TypeName = "TGetFreeMasterReq";
TGetFreeMasterReq::TGetFreeMasterReq():common::SerializationAble(TypeName),app_user_num(0){

}
TGetFreeMasterReq::~TGetFreeMasterReq(){

}
uint32_t TGetFreeMasterReq::GetLength() {
	return sizeof(app_user_num) + appid.size()+1;
}
void TGetFreeMasterReq::EncodeBody(common::BufferWriter &buf) {
	buf.NET_WriteUint32(app_user_num);
	buf << appid;
}
void TGetFreeMasterReq::DecodeBody(common::BufferReader &buf) {
	app_user_num = buf.HOST_ReadUint32();
	buf >> appid;
}
const char * TGetFreeMasterRsp::TypeName = "TGetFreeMasterRsp";
TGetFreeMasterRsp::TGetFreeMasterRsp():common::SerializationAble(TypeName){

}
TGetFreeMasterRsp::~TGetFreeMasterRsp(){

}
uint32_t TGetFreeMasterRsp::GetLength(){
	return addr.size()+1;
}
void TGetFreeMasterRsp::EncodeBody(common::BufferWriter &buf){
	buf << addr;
}
void TGetFreeMasterRsp::DecodeBody(common::BufferReader &buf){
	buf >> addr;
}

} /* namespace monraft */
} /* namespace adcloud */
