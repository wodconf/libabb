#include "type_init.hpp"
#include "type_add_master.hpp"
#include "type_lose_master.hpp"
#include "type_add_app.hpp"
#include "type_del_app.hpp"
#include "type_get_app_at.hpp"

#include "type_add_gate.hpp"
#include "type_gate_stat.hpp"
#include "type_lose_gate.hpp"
#include "type_get_master.hpp"
#include "type_get_free_master.hpp"
#include "type_get_gate.hpp"
namespace adcloud{
namespace type{
void Init(){
	common::SerializationAble::RegistCreator(TAddMasterReq::TypeName,common::T_SerializationAbleCreator<TAddMasterReq>);
	common::SerializationAble::RegistCreator(TAddMasterRsp::TypeName,common::T_SerializationAbleCreator<TAddMasterRsp>);

	common::SerializationAble::RegistCreator(TLoseMasterReq::TypeName,common::T_SerializationAbleCreator<TLoseMasterReq>);
	common::SerializationAble::RegistCreator(TLoseMasterRsp::TypeName,common::T_SerializationAbleCreator<TLoseMasterRsp>);

	common::SerializationAble::RegistCreator(TAddAppReq::TypeName,common::T_SerializationAbleCreator<TAddAppReq>);
	common::SerializationAble::RegistCreator(TAddAppRsp::TypeName,common::T_SerializationAbleCreator<TAddAppRsp>);

	common::SerializationAble::RegistCreator(TDelAppReq::TypeName,common::T_SerializationAbleCreator<TDelAppReq>);
	common::SerializationAble::RegistCreator(TDelAppRsp::TypeName,common::T_SerializationAbleCreator<TDelAppRsp>);

	common::SerializationAble::RegistCreator(TGetAppAtReq::TypeName,common::T_SerializationAbleCreator<TGetAppAtReq>);
	common::SerializationAble::RegistCreator(TGetAppAtRsp::TypeName,common::T_SerializationAbleCreator<TGetAppAtRsp>);

	common::SerializationAble::RegistCreator(TAddGateReq::TypeName,common::T_SerializationAbleCreator<TAddGateReq>);
	common::SerializationAble::RegistCreator(TAddGateRsp::TypeName,common::T_SerializationAbleCreator<TAddGateRsp>);

	common::SerializationAble::RegistCreator(TLoseGateReq::TypeName,common::T_SerializationAbleCreator<TLoseGateReq>);
	common::SerializationAble::RegistCreator(TLoseGateRsp::TypeName,common::T_SerializationAbleCreator<TLoseGateRsp>);

	common::SerializationAble::RegistCreator(TGateStatReq::TypeName,common::T_SerializationAbleCreator<TGateStatReq>);
	common::SerializationAble::RegistCreator(TGateStatRsp::TypeName,common::T_SerializationAbleCreator<TGateStatRsp>);

	common::SerializationAble::RegistCreator(TGetMasterRsp::TypeName,common::T_SerializationAbleCreator<TGetMasterRsp>);

	common::SerializationAble::RegistCreator(TGetFreeMasterReq::TypeName,common::T_SerializationAbleCreator<TGetFreeMasterReq>);
	common::SerializationAble::RegistCreator(TGetFreeMasterRsp::TypeName,common::T_SerializationAbleCreator<TGetFreeMasterRsp>);


	common::SerializationAble::RegistCreator(TGetGateRequest::TypeName,common::T_SerializationAbleCreator<TGetGateRequest>);
	common::SerializationAble::RegistCreator(TGetGateResponce::TypeName,common::T_SerializationAbleCreator<TGetGateResponce>);
}
}
}





