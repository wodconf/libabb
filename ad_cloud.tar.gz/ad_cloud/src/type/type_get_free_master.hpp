/*
 * type_get_free_master.hpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#ifndef TYPE_GET_FREE_MASTER_HPP_
#define TYPE_GET_FREE_MASTER_HPP_
#include "../common/serialization_able.hpp"
namespace adcloud {
namespace type {

class TGetFreeMasterReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TGetFreeMasterReq();
	virtual ~TGetFreeMasterReq();
public:
	uint32_t app_user_num;
	std::string appid;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TGetFreeMasterRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TGetFreeMasterRsp();
	virtual ~TGetFreeMasterRsp();
public:
	std::string addr;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
} /* namespace monraft */
} /* namespace adcloud */

#endif /* TYPE_GET_FREE_MASTER_HPP_ */
