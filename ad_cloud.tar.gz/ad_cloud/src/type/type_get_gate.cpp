#include "type_get_gate.hpp"

namespace adcloud {
namespace type {
const char * TGetGateRequest::TypeName = "TGetGateRequest";
TGetGateRequest::TGetGateRequest():common::SerializationAble(TypeName){

}
TGetGateRequest::~TGetGateRequest(){

}
uint32_t TGetGateRequest::GetLength() {
	return appid.size()+1;
}
void TGetGateRequest::EncodeBody(common::BufferWriter &buf) {
	buf << appid;
}
void TGetGateRequest::DecodeBody(common::BufferReader &buf) {
	buf >> appid;
}
const char * TGetGateResponce::TypeName = "TGetGateResponce";
TGetGateResponce::TGetGateResponce():common::SerializationAble(TypeName){

}
TGetGateResponce::~TGetGateResponce(){

}
uint32_t TGetGateResponce::GetLength(){
	uint32_t sz = 1;
	for(int i=0;i<addr_list.size();i++){
		sz+=addr_list[i].length()+1;
	}
	return sz;
}
void TGetGateResponce::EncodeBody(common::BufferWriter &buf){
	buf << uint8_t(addr_list.size());
	for(int i=0;i<addr_list.size();i++){
		buf << addr_list[i];
	}
}
void TGetGateResponce::DecodeBody(common::BufferReader &buf){
	uint8_t sz;
	buf >> sz;
	for(int i=0;i<sz;i++){
		std::string addr;
		buf >> addr;
		addr_list.push_back(addr);
	}
}

} /* namespace monraft */
} /* namespace adcloud */
