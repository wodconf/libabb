/*
 * type_lose_gate.hpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#ifndef TYPE_LOSE_GATE_HPP_
#define TYPE_LOSE_GATE_HPP_

#include "../common/serialization_able.hpp"
#include <string>

namespace adcloud {
namespace type {

class TLoseGateReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TLoseGateReq();
	virtual ~TLoseGateReq();
public:
	std::string name;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TLoseGateRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TLoseGateRsp();
	virtual ~TLoseGateRsp();
public:
	bool success;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};

} /* namespace type */
} /* namespace adcloud */

#endif /* TYPE_LOSE_GATE_HPP_ */
