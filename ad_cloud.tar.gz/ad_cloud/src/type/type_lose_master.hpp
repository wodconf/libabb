
#ifndef TYPE_LOSE_MASTER_HPP_
#define TYPE_LOSE_MASTER_HPP_

#include "../common/serialization_able.hpp"
#include <string>

namespace adcloud {
namespace type {

class TLoseMasterReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TLoseMasterReq();
	virtual ~TLoseMasterReq();
public:
	std::string name;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TLoseMasterRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TLoseMasterRsp();
	virtual ~TLoseMasterRsp();
public:
	bool success;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};

} /* namespace type */
} /* namespace adcloud */

#endif /* TYPE_LOSE_MASTER_HPP_ */
