/*
 * type_get_app_at.cpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#include "type_get_app_at.hpp"

namespace adcloud {
namespace type {

const char * TGetAppAtReq::TypeName = "adcloud.type.TGetAppAtReq";
TGetAppAtReq::TGetAppAtReq():common::SerializationAble(TypeName){

}
TGetAppAtReq::~TGetAppAtReq(){

}
uint32_t TGetAppAtReq::GetLength() {
	return app_id.size()+1;
}
void TGetAppAtReq::EncodeBody(common::BufferWriter &buf) {
	buf << app_id;
}
void TGetAppAtReq::DecodeBody(common::BufferReader &buf) {
	buf >> app_id;
}
const char * TGetAppAtRsp::TypeName  = "adcloud.type.TGetAppAtRsp";
TGetAppAtRsp::TGetAppAtRsp():common::SerializationAble(TypeName),success(true){

}
TGetAppAtRsp::~TGetAppAtRsp(){

}
uint32_t TGetAppAtRsp::GetLength() {
	return sizeof(success) + addr.size() + 1;
}
void TGetAppAtRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success << addr;
}
void TGetAppAtRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success >> addr;
}

} /* namespace type */
} /* namespace adcloud */
