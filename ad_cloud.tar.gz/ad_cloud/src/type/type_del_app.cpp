/*
 * type_del_app.cpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#include "type_del_app.hpp"

namespace adcloud {
namespace type {

const char * TDelAppReq::TypeName = "adcloud.type.TDelAppReq";
TDelAppReq::TDelAppReq():common::SerializationAble(TypeName){

}
TDelAppReq::~TDelAppReq(){

}
uint32_t TDelAppReq::GetLength() {
	return name.size() + 1 + app_id.size()+1;
}
void TDelAppReq::EncodeBody(common::BufferWriter &buf) {
	buf << name << app_id;
}
void TDelAppReq::DecodeBody(common::BufferReader &buf) {
	buf >> name >> app_id;
}
const char * TDelAppRsp::TypeName  = "adcloud.type.TDelAppRsp";
TDelAppRsp::TDelAppRsp():common::SerializationAble(TypeName),success(true){

}
TDelAppRsp::~TDelAppRsp(){

}
uint32_t TDelAppRsp::GetLength() {
	return sizeof(success);
}
void TDelAppRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success;
}
void TDelAppRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success;
}
} /* namespace type */
} /* namespace adcloud */
