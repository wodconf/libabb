/*
 * type_gate_stat.hpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#ifndef TYPE_GATE_STAT_HPP_
#define TYPE_GATE_STAT_HPP_
#include "../common/serialization_able.hpp"
namespace adcloud {
namespace type {

class TGateStatReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TGateStatReq();
	virtual ~TGateStatReq();
public:
	std::string name;
		uint16_t num_client;
		uint16_t cpu;
		uint32_t mem;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TGateStatRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TGateStatRsp();
	virtual ~TGateStatRsp();
public:
	bool success;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
} /* namespace type */
} /* namespace adcloud */

#endif /* TYPE_GATE_STAT_HPP_ */
