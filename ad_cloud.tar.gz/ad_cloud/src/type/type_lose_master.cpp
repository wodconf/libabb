/*
 * type_lose_master.cpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#include "type_lose_master.hpp"

namespace adcloud {
namespace type {
const char * TLoseMasterReq::TypeName = "adcloud.type.TLoseMasterReq";
TLoseMasterReq::TLoseMasterReq():common::SerializationAble(TypeName){

}
TLoseMasterReq::~TLoseMasterReq(){

}
uint32_t TLoseMasterReq::GetLength() {
	return name.size() + 1;
}
void TLoseMasterReq::EncodeBody(common::BufferWriter &buf) {
	buf << name;
}
void TLoseMasterReq::DecodeBody(common::BufferReader &buf) {
	buf >> name;
}
const char * TLoseMasterRsp::TypeName  = "adcloud.type.TLoseMasterRsp";
TLoseMasterRsp::TLoseMasterRsp():common::SerializationAble(TypeName),success(true){

}
TLoseMasterRsp::~TLoseMasterRsp(){

}
uint32_t TLoseMasterRsp::GetLength() {
	return sizeof(success);
}
void TLoseMasterRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success;
}
void TLoseMasterRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success;
}

} /* namespace type */
} /* namespace adcloud */
