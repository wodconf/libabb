
#ifndef TYPE_GET_GATE_HPP_
#define TYPE_GET_GATE_HPP_
#include "../common/serialization_able.hpp"
#include <vector>
namespace adcloud {
namespace type {

class TGetGateRequest:public common::SerializationAble{
public:
	static const char * TypeName;
	TGetGateRequest();
	virtual ~TGetGateRequest();
public:
	std::string appid;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TGetGateResponce:public common::SerializationAble{
public:
	static const char * TypeName;
	TGetGateResponce();
	virtual ~TGetGateResponce();
public:
	std::vector<std::string> addr_list;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
} /* namespace monraft */
} /* namespace adcloud */

#endif /* TYPE_GET_FREE_MASTER_HPP_ */
