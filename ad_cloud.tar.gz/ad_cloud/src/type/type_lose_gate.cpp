/*
 * type_lose_gate.cpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#include "type_lose_gate.hpp"

namespace adcloud {
namespace type {
const char * TLoseGateReq::TypeName = "adcloud.type.TLoseGateReq";
TLoseGateReq::TLoseGateReq():common::SerializationAble(TypeName){

}
TLoseGateReq::~TLoseGateReq(){

}
uint32_t TLoseGateReq::GetLength() {
	return name.size() + 1;
}
void TLoseGateReq::EncodeBody(common::BufferWriter &buf) {
	buf << name;
}
void TLoseGateReq::DecodeBody(common::BufferReader &buf) {
	buf >> name;
}
const char * TLoseGateRsp::TypeName  = "adcloud.type.TLoseGateRsp";
TLoseGateRsp::TLoseGateRsp():common::SerializationAble(TypeName),success(true){

}
TLoseGateRsp::~TLoseGateRsp(){

}
uint32_t TLoseGateRsp::GetLength() {
	return sizeof(success);
}
void TLoseGateRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success;
}
void TLoseGateRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success;
}

} /* namespace type */
} /* namespace adcloud */
