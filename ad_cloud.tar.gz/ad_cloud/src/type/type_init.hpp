
#ifndef TYPE_INIT_HPP_
#define TYPE_INIT_HPP_

namespace adcloud{
namespace type{
extern void Init();
}
}



#endif /* TYPE_INIT_HPP_ */
