/*
 * type_gate_stat.cpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#include "type_gate_stat.hpp"

namespace adcloud {
namespace type {

const char * TGateStatReq::TypeName = "adcloud.type.TGateStatReq";
TGateStatReq::TGateStatReq():common::SerializationAble(TypeName),num_client(0),cpu(0),mem(0){

}
TGateStatReq::~TGateStatReq(){

}
uint32_t TGateStatReq::GetLength() {
	return name.length()+1 + sizeof(num_client) + sizeof(cpu) + sizeof(mem);
}
void TGateStatReq::EncodeBody(common::BufferWriter &buf) {
	buf << name;
		buf.NET_WriteUint16(num_client);
		buf.NET_WriteUint16(cpu);
		buf.NET_WriteUint32(mem);
}
void TGateStatReq::DecodeBody(common::BufferReader &buf) {
	buf >> name;
		num_client = buf.HOST_ReadUint16();
		cpu = buf.HOST_ReadUint16();
		mem = buf.HOST_ReadUint32();
}
const char * TGateStatRsp::TypeName  = "adcloud.type.TGateStatRsp";
TGateStatRsp::TGateStatRsp():common::SerializationAble(TypeName),success(true){

}
TGateStatRsp::~TGateStatRsp(){

}
uint32_t TGateStatRsp::GetLength() {
	return sizeof(success);
}
void TGateStatRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success;
}
void TGateStatRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success;
}

} /* namespace type */
} /* namespace adcloud */
