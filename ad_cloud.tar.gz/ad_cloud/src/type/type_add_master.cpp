#include "type_add_master.hpp"
namespace adcloud{
namespace type{
const char * TAddMasterReq::TypeName = "adcloud.type.TAddMasterReq";
TAddMasterReq::TAddMasterReq():common::SerializationAble(TypeName),gate_port(0),app_port(0),om_port(0),max_num(0){
}
TAddMasterReq::~TAddMasterReq(){
}
uint32_t TAddMasterReq::GetLength() {
	return name.length()+1+host.length()+1+in_host.length()+1+sizeof(uint16_t)*3 + sizeof(max_num);
}
void TAddMasterReq::EncodeBody(common::BufferWriter &buf) {
	buf << name;
	buf << host;
	buf << in_host;
	buf.NET_WriteUint16(gate_port);
	buf.NET_WriteUint16(app_port);
	buf.NET_WriteUint16(om_port);
	buf.NET_WriteUint32(max_num);
}
void TAddMasterReq::DecodeBody(common::BufferReader &buf) {
	buf >> name;
	buf >> host;
	buf >> in_host;
	gate_port = buf.HOST_ReadUint16();
	app_port = buf.HOST_ReadUint16();
	om_port = buf.HOST_ReadUint16();
	max_num = buf.HOST_ReadUint32();
}


const char * TAddMasterRsp::TypeName = "adcloud.type.TAddMasterRsp";
TAddMasterRsp::TAddMasterRsp():common::SerializationAble(TypeName),success(false){
}
TAddMasterRsp::~TAddMasterRsp(){
}
uint32_t TAddMasterRsp::GetLength() {
	uint32_t sz = sizeof(success);
	sz += sizeof(uint16_t);

	return sz;
}
void TAddMasterRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success;
}
void TAddMasterRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success;
}
}}
