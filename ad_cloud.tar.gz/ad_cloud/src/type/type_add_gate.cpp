/*
 * type_add_gate.cpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#include "type_add_gate.hpp"

namespace adcloud {
namespace type {

const char * TAddGateReq::TypeName = "adcloud.type.TAddGateReq";
TAddGateReq::TAddGateReq():common::SerializationAble(TypeName){

}
TAddGateReq::~TAddGateReq(){

}
uint32_t TAddGateReq::GetLength() {
	return name.size() + 1 + addr.size()+1;
}
void TAddGateReq::EncodeBody(common::BufferWriter &buf) {
	buf << name << addr;
}
void TAddGateReq::DecodeBody(common::BufferReader &buf) {
	buf >> name >> addr;
}
const char * TAddGateRsp::TypeName  = "adcloud.type.TAddGateRsp";
TAddGateRsp::TAddGateRsp():common::SerializationAble(TypeName),success(true){

}
TAddGateRsp::~TAddGateRsp(){

}
uint32_t TAddGateRsp::GetLength() {
	return sizeof(success);
}
void TAddGateRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success;
}
void TAddGateRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success;
}

} /* namespace type */
} /* namespace adcloud */
