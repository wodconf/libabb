/*
 * type_get_master.hpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#ifndef TYPE_GET_MASTER_HPP_
#define TYPE_GET_MASTER_HPP_
#include "../common/serialization_able.hpp"
namespace adcloud {
namespace type {


class TGetMasterRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TGetMasterRsp();
	virtual ~TGetMasterRsp();
public:
	typedef std::map<std::string,std::string> SSMAP;
	SSMAP om_map;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
} /* namespace monraft */
} /* namespace adcloud */

#endif /* TYPE_GET_MASTER_HPP_ */
