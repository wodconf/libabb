/*
 * type_add_gate.hpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#ifndef TYPE_ADD_GATE_HPP_
#define TYPE_ADD_GATE_HPP_
#include "../common/serialization_able.hpp"
#include <string>
namespace adcloud {
namespace type {

class TAddGateReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TAddGateReq();
	virtual ~TAddGateReq();
public:
	std::string name;
	std::string addr;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TAddGateRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TAddGateRsp();
	virtual ~TAddGateRsp();
public:
	bool success;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};

} /* namespace type */
} /* namespace adcloud */

#endif /* TYPE_ADD_GATE_HPP_ */
