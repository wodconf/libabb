/*
 * type_get_app_at.hpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#ifndef TYPE_GET_APP_AT_HPP_
#define TYPE_GET_APP_AT_HPP_
#include "../common/serialization_able.hpp"
namespace adcloud {
namespace type {

class TGetAppAtReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TGetAppAtReq();
	virtual ~TGetAppAtReq();
public:
	std::string app_id;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TGetAppAtRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TGetAppAtRsp();
	virtual ~TGetAppAtRsp();
public:
	bool success;
	std::string addr;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};

} /* namespace type */
} /* namespace adcloud */

#endif /* TYPE_GET_APP_AT_HPP_ */
