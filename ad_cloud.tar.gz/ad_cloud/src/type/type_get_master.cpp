/*
 * type_get_master.cpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#include "type_get_master.hpp"

namespace adcloud {
namespace type {


const char * TGetMasterRsp::TypeName = "adcloud.type.TGetMasterRsp";
TGetMasterRsp::TGetMasterRsp():common::SerializationAble(TypeName){
}
TGetMasterRsp::~TGetMasterRsp(){
}
uint32_t TGetMasterRsp::GetLength() {
	uint32_t sz = sizeof(uint16_t);
	for(SSMAP::iterator iter = om_map.begin();iter!=om_map.end();iter++){
		sz+=iter->first.size()+1;
		sz+=iter->second.size()+1;
	}
	return sz;
}
void TGetMasterRsp::EncodeBody(common::BufferWriter &buf) {
	buf.NET_WriteUint16(om_map.size());
	for(SSMAP::iterator iter = om_map.begin();iter!=om_map.end();iter++){
		buf << iter->first << iter->second;
	}
}
void TGetMasterRsp::DecodeBody(common::BufferReader &buf) {
	uint16_t sz = buf.HOST_ReadUint16();
	std::string key,val;
	for(int i=0;i<sz;i++){
		buf >> key >> val;
		om_map[key] = val;
	}
}
} /* namespace monraft */
} /* namespace adcloud */
