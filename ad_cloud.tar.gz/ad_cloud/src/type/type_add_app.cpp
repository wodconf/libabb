/*
 * type_add_app.cpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#include "type_add_app.hpp"


namespace adcloud {
namespace type {
const char * TAddAppReq::TypeName = "adcloud.type.TAddAppReq";
TAddAppReq::TAddAppReq():common::SerializationAble(TypeName),num(0){

}
TAddAppReq::~TAddAppReq(){

}
uint32_t TAddAppReq::GetLength() {
	return name.size() + 1 + app_id.size()+1 + sizeof(num);
}
void TAddAppReq::EncodeBody(common::BufferWriter &buf) {
	buf << name << app_id;
	buf.NET_WriteUint32(num);
}
void TAddAppReq::DecodeBody(common::BufferReader &buf) {
	buf >> name >> app_id;
	num = buf.HOST_ReadUint32();
}
const char * TAddAppRsp::TypeName  = "adcloud.type.TAddAppRsp";
TAddAppRsp::TAddAppRsp():common::SerializationAble(TypeName),success(true){

}
TAddAppRsp::~TAddAppRsp(){

}
uint32_t TAddAppRsp::GetLength() {
	return sizeof(success);
}
void TAddAppRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success;
}
void TAddAppRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success;
}

} /* namespace type */
} /* namespace adcloud */

