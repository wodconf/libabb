
#ifndef MASTER_TYPE_HPP_
#define MASTER_TYPE_HPP_

#include "../common/serialization_able.hpp"
#include <map>
#include <string>

namespace adcloud{
namespace type{

class TAddMasterReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TAddMasterReq();
	virtual ~TAddMasterReq();
public:
	std::string name;
	std::string host;
	std::string in_host;
	uint16_t gate_port;
	uint16_t app_port;
	uint16_t om_port;
	uint32_t max_num;

private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TAddMasterRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TAddMasterRsp();
	virtual ~TAddMasterRsp();
public:
	bool success;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};

}
}


#endif /* MASTER_TYPE_HPP_ */
