/*
 * type_del_app.hpp
 *
 *  Created on: 2014-5-12
 *      Author: wd
 */

#ifndef TYPE_DEL_APP_HPP_
#define TYPE_DEL_APP_HPP_
#include "../common/serialization_able.hpp"
namespace adcloud {
namespace type {

class TDelAppReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TDelAppReq();
	virtual ~TDelAppReq();
public:
	std::string name;
	std::string app_id;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
class TDelAppRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TDelAppRsp();
	virtual ~TDelAppRsp();
public:
	bool success;
private:
	virtual uint32_t GetLength() ;
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
} /* namespace type */
} /* namespace adcloud */

#endif /* TYPE_DEL_APP_HPP_ */
