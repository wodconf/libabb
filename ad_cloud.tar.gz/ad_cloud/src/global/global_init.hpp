

#ifndef GLOBAL_CONTEXT_HPP_
#define GLOBAL_CONTEXT_HPP_
#include "../common/arg_parse.hpp"
#include <vector>
namespace adcloud{
namespace global{
	int Init(common::ArgParse& arg);
}
}


#endif /* GLOBAL_CONTEXT_HPP_ */
