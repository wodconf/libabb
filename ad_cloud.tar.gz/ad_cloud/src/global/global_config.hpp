/*
 * adcloud_config.hpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#ifndef ADCLOUD_CONFIG_HPP_
#define ADCLOUD_CONFIG_HPP_
#include <string>
namespace adcloud {
namespace global {

class GlobalConfig {
public:
	GlobalConfig();
	~GlobalConfig();
	bool Parse(const std::string& path);
	int poller_thread_num;
	int queue_time_out_second;
	int queue_message_df;
	int queue_auth_times;
};

} /* namespace monraft */
} /* namespace adcloud */

#endif /* ADCLOUD_CONFIG_HPP_ */
