#include "global_init.hpp"

#include "../message/message_init.hpp"
#include "../translate/init.hpp"
#include "../rpc/init_rpc.hpp"
#include "../type/type_init.hpp"
#include "../queue/queue_init.hpp"
#include "global_config.hpp"
#include<signal.h>
namespace adcloud{
namespace global{
	int Init(common::ArgParse& arg){
		GlobalConfig config;
		std::string path;
		if(arg.GetValue("conf-path",path)){
			if( !config.Parse(path) ){
				LOG(WARN) << "GlobalConfig.Parse.fail";
				return -1;
			}
		}
		message::Init();
		translate::Init(config.poller_thread_num);
		rpc::Init();
		if( ! queue::Init(config.queue_time_out_second,config.queue_message_df,config.queue_auth_times) ){
			LOG(WARN) << "Queue.init.fail";
			return -1;
		}
		type::Init();
		struct sigaction act;
		act.sa_handler = SIG_IGN;
		if (sigaction(SIGPIPE, &act, NULL) != 0) {
			return -1;
		}
		return 0;
	}
}
}
