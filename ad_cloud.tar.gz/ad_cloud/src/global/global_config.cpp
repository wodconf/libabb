/*
 * adcloud_config.cpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#include "global_config.hpp"
#include "../common/config_file.hpp"
#include <stdlib.h>
namespace adcloud {
namespace global {

GlobalConfig::GlobalConfig() {
	queue_time_out_second = 10;
	queue_message_df = 10;
	queue_auth_times = 10;
	poller_thread_num = 4;
}

GlobalConfig::~GlobalConfig() {

}
bool GlobalConfig::Parse(const std::string& path){
	common::ConfigFile file;
	if( ! file.Parse(path) ){
		return false;
	}
	std::string val;
	if( file.GetValue("queue_time_out_second",val) ){
		queue_time_out_second = atoi(val.c_str());
		if(queue_time_out_second <= 0) return false;
	}
	if( file.GetValue("queue_message_df",val) ){
		queue_message_df = atoi(val.c_str());
		if(queue_message_df <= 0) return false;
	}
	if( file.GetValue("queue_auth_times",val) ){
		queue_auth_times = atoi(val.c_str());
		if(queue_auth_times <= 0) return false;
	}
	if( file.GetValue("poller_thread_num",val) ){
		poller_thread_num = atoi(val.c_str());
		if(poller_thread_num <= 0) return false;
	}
	return true;
}
} /* namespace monraft */
} /* namespace adcloud */
