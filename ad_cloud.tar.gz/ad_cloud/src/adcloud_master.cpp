
#include "master/master.hpp"
#include "global/global_init.hpp"
#include "master/master_config.hpp"
#include <stdlib.h>

using namespace adcloud;
int main(int argc,const char* argv[]){
	common::ArgParse parse;
	parse.Parse(argc,argv);
	if( global::Init(parse) != 0){
		LOG(ERROR) << "global.init.fail";
	}
	master::Config cfg;
	if( ! cfg.Parse(parse) ){
		LOG(ERROR) << "master.config.parse.fail";
		exit(-1);
	}
	master::MASTER* m = new master::MASTER();
	if( !m->Init(&cfg) ){
		LOG(ERROR) << "master.init.fail";
		exit(-1);
	}
	m->Start();
	return 0;
}
