


#include "global/global_init.hpp"
#include "monitor_proxy/mp_proxy.hpp"
#include "common/arg_parse.hpp"
#include "monitor_proxy/mp_config.hpp"
#include "common/time.hpp"
#include <stdlib.h>
using namespace adcloud;


int main(int argc,const char* argv[]){
	common::ArgParse parse;
	parse.Parse(argc,argv);
	if( global::Init(parse) != 0){
		LOG(ERROR) << "global.init.fail";
	}
	monproxy::Config cfg;
	if( ! cfg.Parse(parse) ){
		LOG(ERROR) << "config.parse.fail";
		exit(-1);
	}
	abb::base::g_min_log_level = abb::base::LOGLEVEL_DEBUG;
	monproxy::MonitorProxy* mp = new monproxy::MonitorProxy();
	if( !mp->Init(&cfg) ){
		LOG(ERROR) << "monitor.proxy.init.fail";
		exit(-1);
	}
	mp->Start();
	return 0;
}
