



#include "../../global/global_init.hpp"
#include "../../monitor/mm_client.hpp"

#include "sstream"
using namespace adcloud;
int main(int argc,const char* argv[]){
	adcloud::common::ArgParse arg;
	arg.Parse(argc,argv);
	adcloud::global::Init(arg);
	mon::MonitorClient cli;
	std::vector<std::string> addrs;
	addrs.push_back("127.0.0.1:8004");
	addrs.push_back("127.0.0.1:8005");
	addrs.push_back("127.0.0.1:8006");
	cli.SetAddrs(addrs);

	cli.AddGate("gate1","127.0.0.1:9002");
	int index = 0;
	while(true){
		std::ostringstream s;
		s << "app" << index++;
		cli.GateAddApp("gate1",s.str());
	}
}
