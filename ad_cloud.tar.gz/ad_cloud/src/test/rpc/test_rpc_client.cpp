#include "../../rpc/rpc_client.hpp"
#include "../../common/log.hpp"
#include "../../rpc/rpc_message.hpp"
#include "type.hpp"
#include "../../common/log.hpp"
#include "../../translate/connection.hpp"
#include "../../translate/connector.hpp"

#include "../../message/message_init.hpp"
#include "../../translate/init.hpp"
#include "../../translate/tcp_client.hpp"
#include "../../translate/client_pool.hpp"
#include "../../common/time.hpp"
#include "../../common/thread.hpp"
using namespace adcloud::rpc;
using namespace adcloud::translate;
using namespace adcloud::message;
using namespace adcloud::translate;
using namespace adcloud::common;

class Sender:public RpcClient::ISend, adcloud::translate::ClientPool::Listener{
public:
	Sender():cli(this),pool_(this){
	}
	virtual ~Sender(){};
	virtual bool ISend_Send(Message& msg){
		return pool_.SendToAddr(msg,"127.0.0.1:5555");
	}
	int CallAdd(int a,int b,int timeout = 0){
		AddArg add;
		add.a = a;
		add.b = b;
		std::string err;
		AddReply* rsp = (AddReply*)cli.Call("add",&add,err,timeout);
		if(rsp){
			return rsp->a;
		}
		return -1;
	}
	virtual void L_ClientPool_ConnectionReset(const std::string& addr){
		AD_CLOUD_INFO <<"L_Client_OnCLose";
		cli.OnClose();
	}
	virtual void L_ClientPool_ConnectionMessage(const std::string& addr,Message* msg){
		AD_CLOUD_INFO <<"L_ClientPool_ConnectionMessage:" << addr;
		if(msg->GetTag() == adcloud::rpc::MRpcResponce::TAG){
			AD_CLOUD_INFO <<"MRpcResponce:" << addr;
			cli.OnMessage(static_cast<adcloud::rpc::MRpcResponce*>(msg));
		}
	}
private:
	RpcClient cli;
	adcloud::translate::ClientPool pool_;
};
void* ThreadMain(void*arg){
	Sender *s= (Sender*)arg;
	while(true){
		int ret = s->CallAdd(4,5,200);
		adcloud::common::time::Sleep(10);
	}
	return NULL;
}
int main(){
	adcloud::translate::Init(4);
	adcloud::message::Init();
	std::string str(AddArg::TYPE);
	std::string str1(AddReply::TYPE);
	SerializationAble::RegistCreator(str,T_SerializationAbleCreator<AddArg>);
	SerializationAble::RegistCreator(str1,T_SerializationAbleCreator<AddReply>);
	Sender sender;
	adcloud::common::Thread td;
	td.Start(ThreadMain,&sender);
	adcloud::common::time::Sleep(100);
	AD_CLOUD_INFO << "CallAdd add back";
	int ret = sender.CallAdd(1,2);
	AD_CLOUD_INFO << "add back" << ret;
	while(true){
		sender.CallAdd(1,2);
		adcloud::common::time::Sleep(10);
	}
	adcloud::translate::Destroy();
}

