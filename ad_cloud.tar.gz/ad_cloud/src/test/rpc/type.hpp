
#ifndef TYPE_HPP_
#define TYPE_HPP_

#include "../../common/serialization_able.hpp"

class AddArg:public adcloud::common::SerializationAble{
public:
	static const char* TYPE;;
	AddArg():adcloud::common::SerializationAble(TYPE),a(0),b(0){}
	virtual ~AddArg(){};
private:

	virtual uint32_t GetLength(){
		return sizeof(a)+sizeof(b);
	}
	virtual void EncodeBody(adcloud::common::BufferWriter &buf){
		buf.NET_WriteUint32(a);
		buf.NET_WriteUint32(b);
	}
	virtual void DecodeBody(adcloud::common::BufferReader &buf){
		a = buf.HOST_ReadUint32();
		b = buf.HOST_ReadUint32();
	}
public:
	unsigned a;
	unsigned b;
};
const char* AddArg::TYPE = "AddArg";
class AddReply:public adcloud::common::SerializationAble{
public:
	static const char* TYPE;
	AddReply():adcloud::common::SerializationAble(TYPE),a(0){}
	virtual ~AddReply(){};
private:
	virtual uint32_t GetLength(){
		return sizeof(a);
	}
	virtual void EncodeBody(adcloud::common::BufferWriter &buf){
		buf.NET_WriteUint32(a);
	}
	virtual void DecodeBody(adcloud::common::BufferReader &buf){
		a = buf.HOST_ReadUint32();
	}
public:
	unsigned a;
};
const char* AddReply::TYPE = "AddReply";
#endif /* TYPE_HPP_ */
