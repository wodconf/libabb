#include "../../rpc/rpc_service.hpp"
#include "../../rpc/rpc_message.hpp"
#include "../../common/time.hpp"
#include "type.hpp"
#include "../../common/log.hpp"
#include "../../common/log.hpp"
#include "../../translate/connection.hpp"
#include "../../translate/acceptor.hpp"

#include "../../message/message_init.hpp"
#include "../../translate/init.hpp"
using namespace adcloud::common;
using namespace adcloud::message;
using namespace adcloud::translate;
using namespace adcloud::rpc;

adcloud::rpc::RpcService srv;
class Add:public RpcService::IRpcFunction{
public:
	virtual ~Add(){

	}
	SerializationAble* CallFunction(SerializationAble*req,std::string &err){
		AD_CLOUD_INFO << "ADD";
		adcloud::common::time::Sleep(1000);
		AddArg* add = (AddArg*)req;
		AddReply* rep = new AddReply();
		rep->a = add->a + add->b;
		return rep;
	}
	void Finsh(SerializationAble* res){
		res->UnRef();
	}
};
class ConnListener:public adcloud::translate::Connection::Listener{
public:
	virtual ~ConnListener(){

	};
	virtual void L_Connection_OnMessage(Connection* self,Message*msg){
		AD_CLOUD_INFO << "L_Connection_OnMessage TAG" << msg->GetTag();
		if(msg->GetTag() == MRpcRequest::TAG){
			srv.AsycRpcExecute(static_cast<MRpcRequest*>(msg));
		}
	}
	virtual void L_Connection_OnClose(Connection* self){
		AD_CLOUD_INFO << "L_Connection_OnClose";
		self->UnRef();
	}
};

class AListener:public adcloud::translate::Acceptor::Listener{
public:
	virtual ~AListener(){
	};
	void L_Acceptor_OnConnection(Connection* conn){
		AD_CLOUD_INFO << "L_Acceptor_OnConnection";
		conn->SetListner(new ConnListener());
	}
};
int main(){
	adcloud::translate::Init(4);
	adcloud::message::Init();
	AListener lis;
	Acceptor ct(&lis);
	abb::net::IPAddr addr;
	addr.SetV4("127.0.0.1",5555);
	ct.Bind(addr,NULL);
	ct.SetEnable(true);
	std::string str(AddArg::TYPE);
	std::string str1(AddReply::TYPE);
	SerializationAble::RegistCreator(str,T_SerializationAbleCreator<AddArg>);
	SerializationAble::RegistCreator(str1,T_SerializationAbleCreator<AddReply>);
	srv.Start();
	Add add;
	srv.RegistFunction("add",&add);
	while(true){
		adcloud::common::time::Sleep(1000);
	}
	adcloud::translate::Destroy();
}
