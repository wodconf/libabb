#include "../../global/global_init.hpp"
#include "../../common/time.hpp"
#include "../../common/log.hpp"
#include "../../message/client_message.hpp"
#include "../../translate/connector.hpp"
#include <abb/base/buffer.hpp>
#include <stdlib.h>
using namespace adcloud::message;
using namespace adcloud::translate;
char * buf;
int SIZE = 100;
std::string os_id;
class Client:public adcloud::translate::Connector::Listener,adcloud::translate::Connection::Listener{
public:
	Client():ct_(this),conn_(NULL),bok(false){

	}
	void Connect(const abb::net::IPAddr& addr){
		ct_.Connect(addr);
	}
	virtual ~Client(){}
	virtual void L_Connector_OnOpen(Connection* conn){
		AD_CLOUD_INFO <<  "L_Connector_OnOpen";
		conn->SetListner(this);
		conn_  = conn;
		SendReq();
	}
	virtual void L_Connector_OnOpenFail(){
		AD_CLOUD_INFO << "L_Connector_OnOpenFail";
	}
	virtual void L_Connection_OnMessage(Connection* self,Message*msg){
		if(msg->GetTag() == MClientRegBak::TAG){
			AD_CLOUD_INFO << "Regist Ok";
			bok = true;
		}

		msg->Print();
	}
	virtual void L_Connection_OnClose(Connection* self){
		AD_CLOUD_INFO << "L_Connection_OnClose" << strerror(self->GetErrorCode());
	}
	void SendReq(){
		MClientReg Reg;
		Reg.os_id = os_id;
		conn_->Send(Reg);
	}
	void SendData(){
		if(bok){
			if(conn_){

				MClientMessage msg;
				msg.data = buf;
				msg.size = SIZE;
				conn_->Send(msg);
			}
		}
	}
private:
	bool bok;
	Connector ct_;
	Connection* conn_;
};

int main(int argc,const char* argv[]){
	if(argc < 2){
		LOG(WARN) << "arguments.error";
		return -1;
	}
	adcloud::common::ArgParse arg;
	arg.Parse(argc,argv);
	adcloud::global::Init(arg);
	std::vector<Client*> arr;
	abb::net::IPAddr addr;
	addr.SetV4("127.0.0.1",9200);
	int max = 2;
	os_id = argv[1];
	if (argc >= 3){
		max = atoi(argv[2]);
	}
	if (argc >= 4){
		SIZE = atoi(argv[3]);
	}
	buf = new char[SIZE];
	for(int i=0;i<max;i++){
		Client* cli = new Client();
		cli->Connect(addr);
		arr.push_back(cli);
	}
	while(true){
		adcloud::common::time::Sleep(10);
		for(int i=0;i<arr.size();i++){
			arr[i]->SendData();
		}
	}
}

