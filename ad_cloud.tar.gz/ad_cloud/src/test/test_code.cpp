#include "../global/global_init.hpp"
#include "../common/time.hpp"
#include "../common/log.hpp"
#include "../message/client_message.hpp"
#include "../message/app_message.hpp"
#include <abb/base/buffer.hpp>
#include <stdlib.h>
using namespace adcloud;

int main(int argc,const char* argv[]){
	if(argc < 2){
		LOG(WARN) << "arguments.error";
		return -1;
	}
	uint64_t pre =  common::time::MSNow();
	common::ArgParse arg;
	arg.Parse(argc,argv);
	adcloud::global::Init(arg);
	int max = atoi(argv[1]);
	abb::base::Buffer ab;
	message::MAppClientIn in;
	message::MAppClientOut out;
	message::MAppClientData data;
	in.client_id = 1;
	in.gate_id = "gate1&app1";
	out.client_id = 1;
	out.gate_id = "gate1&app1";
	data.client_id = 1;
	data.gate_id = "gate1&app1";
	char buf[] = "hello";
	data.data = buf;
	data.size = sizeof(buf);


	for(int i=0;i<max;i++){
		if(i%3 == 0){
			in.Encode(ab);
		}else if(i%3==1){
			data.Encode(ab);
		}else{
			out.Encode(ab);
		}
	}


	adcloud::common::BufferReader reader(ab.Data(),ab.Size());
	for(int i=0;i<max;i++){
		translate::Message* msg = translate::Message::DecodeMessage(reader);
		if(!msg){
			LOG(INFO) << "decode num" << i << "max:" << max;
			return -1;
		}
	}
	uint64_t df = common::time::MSNow() - pre;
	LOG(INFO) << "decode  OK " << df << " ms";
	return 1;
}
