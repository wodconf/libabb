/*
 * test_queue_client.cpp
 *
 *  Created on: 2014-5-21
 *      Author: wd
 */



#include "../../global/global_init.hpp"
#include "../../common/time.hpp"
#include "../../queue/queue_service.hpp"
#include "../../message/app_message.hpp"
#include "../../rpc/rpc_server.hpp"
#include <sstream>
#include <stdlib.h>
struct Info{
	int num_pkt;
	int num_client;
};
typedef std::map<std::string,Info> APPMAP;
APPMAP app_map;
using namespace adcloud;
struct Listener:public queue::QueueService::Listener{
	virtual ~Listener(){}
	virtual void L_QueueService_OnQueueOpen(const std::string& id){
		LOG(DEBUG) << "L_QueueClient_OnOpen";
	}
	virtual void L_QueueService_OnQueueMessage(const std::string& id,translate::Message* msg){
		if(msg->GetTag() == message::MAppClientIn::TAG){
			app_map[id].num_client ++;
		}else if(msg->GetTag() == message::MAppClientOut::TAG){
			app_map[id].num_client --;
		}else if(msg->GetTag() == message::MAppClientData::TAG){
			app_map[id].num_pkt ++;
		}
	}
	virtual void L_QueueService_OnQueueClose(const std::string& id){
		LOG(DEBUG) << "L_QueueClient_OnCLose";
	}

	std::string name;
};
int main(int argc,const char* argv[]){
	adcloud::common::ArgParse arg;
	arg.Parse(argc,argv);
	adcloud::global::Init(arg);
	std::string addr = "127.0.0.1:7839";
	rpc::RpcServer rpc_svr_;
	abb::net::IPAddr ipaddr;
	ipaddr.SetByString(addr);
	rpc_svr_.Bind(ipaddr,NULL);
	rpc_svr_.Start();
	Listener lis;
	queue::QueueService svr(&lis,NULL,rpc_svr_.GetRpcService(),addr);
	int max = 1;
	if (argc >= 2){
		max = atoi(argv[1]);
	}
	for(int i=0;i<max;i++){
		std::ostringstream s;
		s << "app" << i;
		svr.OpenQueue(s.str(),"127.0.0.1:8766");
		app_map[s.str()] = Info();
	}
	while(true){
		adcloud::common::time::Sleep(1000);
		APPMAP::iterator iter = app_map.begin();
		for( ;iter != app_map.end();iter++){
			if(iter->second.num_pkt > 0){
				LOG(INFO) << "SVR:" <<iter->first<<"num_client:" << iter->second.num_client << "num_pkt:" << iter->second.num_pkt;
				iter->second.num_pkt = 0;
			}
		}
	}
}
