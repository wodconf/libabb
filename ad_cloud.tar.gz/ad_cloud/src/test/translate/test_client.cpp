#include "../../common/log.hpp"
#include "../../common/time.hpp"
#include "../../translate/connection.hpp"
#include "../../translate/connector.hpp"

#include "../../message/message_init.hpp"
#include "../../translate/init.hpp"

using namespace adcloud::message;
using namespace adcloud::translate;

class ConnListener:public adcloud::translate::Connection::Listener{
public:
	virtual ~ConnListener(){

	};
	virtual void L_Connection_OnMessage(Connection* self,Message*msg){
		AD_CLOUD_INFO << "L_Connection_OnMessage";
		if(msg->GetTag() == MMasterData::TAG){
			MMasterData* req = static_cast<MMasterData*>(msg);
			AD_CLOUD_INFO << "from_os_id" << req->from_os_id << " os_id:" << req->os_id;
		}
		AD_CLOUD_INFO << "tag" << msg->GetTag();

		msg->Print();
	}
	virtual void L_Connection_OnClose(Connection* self){
		AD_CLOUD_INFO << "L_Connection_OnClose";
		self->UnRef();
	}
};

class Listener:public adcloud::translate::Connector::Listener{
public:
	virtual ~Listener(){

	};
	virtual void L_Connector_OnOpen(Connection* conn){
		AD_CLOUD_INFO <<  "L_Connector_OnOpen";
		conn->SetListner(new ConnListener());
		int i;
		MMasterData md;
		md.from_os_id = "123";
		md.os_id = "123";
		md.data = (char*)&i;
		md.size = sizeof(i);
		conn->Send(md);
	}
	virtual void L_Connector_OnOpenFail(){
		AD_CLOUD_INFO << "L_Connector_OnOpenFail";
	}
};

int main(){
	adcloud::translate::Init(4);
	adcloud::message::Init();
	Listener lis;
	Connector ct(&lis);
	abb::net::IPAddr addr;
	addr.SetV4("127.0.0.1",5555);
	ct.Connect(addr);
	while(true){
		adcloud::common::time::Sleep(1000);
	}
	adcloud::translate::Destroy();
}
