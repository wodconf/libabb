#include "../../common/log.hpp"
#include "../../common/time.hpp"
#include "../../translate/connection.hpp"
#include "../../translate/acceptor.hpp"

#include "../../message/message_init.hpp"
#include "../../translate/init.hpp"

using namespace adcloud::message;
using namespace adcloud::translate;

class ConnListener:public adcloud::translate::Connection::Listener{
public:
	virtual ~ConnListener(){

	};
	virtual void L_Connection_OnMessage(Connection* self,Message*msg){
		AD_CLOUD_INFO << "tag" << msg->GetTag();

		msg->Print();
		self->Send(*msg);
	}
	virtual void L_Connection_OnClose(Connection* self){
		AD_CLOUD_INFO << "L_Connection_OnClose";
		self->UnRef();
	}
};

class AListener:public adcloud::translate::Acceptor::Listener{
public:
	virtual ~AListener(){

	};
	void L_Acceptor_OnConnection(Connection* conn){
		AD_CLOUD_INFO <<  "L_Acceptor_OnConnection";
		conn->SetListner(new ConnListener());
	}
};
#include "../../common/notification.hpp"
int main(){
	adcloud::translate::Init(4);
	adcloud::message::Init();
	AListener lis;
	Acceptor ct(&lis);
	abb::net::IPAddr addr;
	addr.SetV4("127.0.0.1",5555);
	ct.Bind(addr,NULL);
	ct.SetEnable(true);
	adcloud::common::Notification notify;
	int index = 10;
	while(index > 0){
		//adcloud::common::time::Sleep(1000);
		int now = adcloud::common::time::MSNow();
		notify.WaitTimeout(3868);
		int df = adcloud::common::time::MSNow() - now;
		LOG(INFO) << df;
		index --;
	}
	adcloud::translate::Destroy();
}
