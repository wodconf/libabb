#include <map>

#include <iostream>
#include <string>
int main(){
	int * p = NULL;
	int a;



	int bfreed_ = 0;
	bool ret = __sync_bool_compare_and_swap(&bfreed_,0,0);
	std::cout << ret  << bfreed_ << std::endl;
}
