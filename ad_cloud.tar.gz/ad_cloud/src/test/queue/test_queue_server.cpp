/*
 * test_queue_server.cpp
 *
 *  Created on: 2014-5-21
 *      Author: wd
 */




#include "../../global/global_init.hpp"

#include "../../rpc/rpc_service.hpp"
#include "../../common/time.hpp"
#include "../../rpc/rpc_server.hpp"
#include "../../queue/queue_service.hpp"
using namespace adcloud;

class Server:public queue::QueueService::IAuth,queue::QueueService::Listener{
public:
	Server(){
		abb::net::IPAddr addr;
		addr.SetV4("127.0.0.1",4567);
		svr.Bind(addr,NULL);
		svr.Start();
		que_svr_ = new queue::QueueService(this,this,svr.GetRpcService(),"127.0.0.1:4567");
	}
	virtual ~Server(){

	}
	virtual void L_QueueService_OnQueueOpen(const std::string& id) {
		LOG(DEBUG) << "L_QueueService_OnQueueOpen";
	}
	virtual void L_QueueService_OnQueueMessage(const std::string& id,translate::Message* msg) {
		LOG(DEBUG) << "L_QueueService_OnQueueMessage";
	}
	virtual void L_QueueService_OnQueueClose(const std::string& id){
		LOG(DEBUG) << "L_QueueService_OnQueueClose";
	}
	virtual bool AuthOk(const std::string& id){
		LOG(DEBUG) << "AuthOk";
		return true;
	}
	queue::QueueService* que_svr_;
	rpc::RpcServer svr;
};

int main(int argc,const char* argv[]){
	adcloud::common::ArgParse arg;
	arg.Parse(argc,argv);
	adcloud::global::Init(arg);
	Server svr;
	while(true){
		adcloud::common::time::Sleep(1000);
	}
}
