
#ifndef CLIENT_SERVICE_HPP_
#define CLIENT_SERVICE_HPP_

#include <map>
#include <vector>
#include <string>
#include "../common/buffer.hpp"
#include "../common/define.hpp"
#include "../common/mutex.hpp"
#include "../translate/acceptor.hpp"
#include "../translate/connection.hpp"
#include <abb/base/thread_pool.hpp>
#include "../queue/queue_service.hpp"
#include "../rpc/rpc_server.hpp"

#include <cassert>
namespace adcloud{ namespace gate{
class GATE;
class ClientGroup;
class Client;
class Register;
class ClientService :public translate::Acceptor::Listener,queue::QueueService::Listener{
public:
	ClientService(GATE* g);
	~ClientService();
	bool Init(const std::string& gate_addr,const std::string& queue_addr);
	void Start();

	void ClientRegist(Client* cli);
	void ClientMessage(Client* cli,void* buf,int size);
	void ClientClose(Client* cli);
	void SendMessageById(translate::Message& msg,uint32_t id);
	void SendDataById(void*buf,int sz,uint32_t id);
	void CloseById(uint32_t id);
	bool PushMessageToQueue(const std::string& qname,translate::Message* msg);


	virtual void L_QueueService_OnQueueOpen(const std::string& id);
	virtual void L_QueueService_OnQueueMessage(const std::string& id,translate::Message* msg);
	virtual void L_QueueService_OnQueueClose(const std::string& id);
	virtual void L_Acceptor_OnConnection(translate::Connection*);
private:
	void GetGroupBack(const std::string& qname,ClientGroup* group);
	void ClientRegistOk(ClientGroup* group,uint32_t id);
	typedef std::vector<uint32_t> RegistClientArray;
	typedef std::map<std::string,ClientGroup*> ClientGroupMap;
	typedef std::map<std::string,RegistClientArray*> WaitGroupMap;
	typedef std::map<std::string,uint64_t> AppFireMap;

	typedef std::map<uint32_t,Client*> ClientMap;
	ClientMap client_map_;
	uint32_t start_id_;
	AppFireMap app_fire_map_;
	ClientGroupMap cg_map_;
	WaitGroupMap wait_map_;
	common::RWLock cg_lock_;
	common::RWLock client_lock_;
	translate::Acceptor actor_;
	GATE *gate_;
	abb::base::ThreadPool pool_;
	queue::QueueService* queue_svr_;
	rpc::RpcServer* rpc_svr_;
	friend class Register;
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(ClientService);
};

}}


#endif /* CLIENT_SERVICE_HPP_ */
