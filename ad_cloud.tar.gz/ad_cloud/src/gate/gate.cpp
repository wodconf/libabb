

#include "gate.hpp"
#include "../message/gate_message.hpp"
#include "../common/log.hpp"
#include "client_group.hpp"
#include "gate_config.hpp"
#include "../common/time.hpp"
#include <cstring>
#include <cassert>
using namespace adcloud::gate;

GATE::GATE():cli_svr_(NULL),cli_(NULL),cfg_(NULL){
}
GATE::~GATE(){
	if(cli_svr_){
		delete cli_svr_;
	}
}
void GATE::Start(){
	this->cli_svr_->Start();
	LOG(INFO) << "gate start";
	while(true){
		common::time::Sleep(1000);
	}
}
bool GATE::Init(Config* cfg){
	cfg_ = cfg;
	name_ = cfg->name;
	LOG(INFO) << name_;
	cli_svr_ = new ClientService(this);
	if( !cli_svr_->Init(cfg->addr,cfg->queue_addr)){
		delete cli_svr_;
		return false;
	}

	cli_ = new mon::MonitorClient();
	cli_->SetAddrs(cfg->mon_addrs);
	return Regist();
}
bool GATE::Regist(){
	int retry = 3;
	while(retry>0){
		if(this->cli_->AddGate(this->name_,this->cfg_->addr)){
			LOG(INFO) << "Regist success";
			return true;
		}
		--retry;
	}
	LOG(INFO) << "Regist failed";
	return false;
}
bool GATE::GetMasterByApp(const std::string& appid,std::string& addr){
	return cli_->GetAppAt(appid,addr);
}
