
#include "client_group.hpp"
#include "client.hpp"
#include "../message/gate_message.hpp"
#include "client_service.hpp"
#include "../message/client_message.hpp"
using namespace adcloud::gate;
ClientGroup::ClientGroup(const std::string& qid,
		ClientService* svr)
:svr_(svr),queue_id_(qid)
{

}
ClientGroup::~ClientGroup(){
	Clear();
}
void ClientGroup::NotifyClientIn(uint32_t id){
	common::Mutex::Locker lock(mtx_);
	message::MGateClientIn* msg = new message::MGateClientIn();
	msg->cid = id;
	this->svr_->PushMessageToQueue(queue_id_,msg);
	msg->UnRef();
	id_scopes_[id] = new ScopeArray();
}
void ClientGroup::NotifyClientMessage(uint32_t cid,void*buf,int size){
	message::MGateClientData* msg = new message::MGateClientData();
	msg->cid = cid;
	msg->data = (char*)buf;
	msg->size = size;
	msg->bneedfree_ = true;
	this->svr_->PushMessageToQueue(queue_id_,msg);
	msg->UnRef();
}
void ClientGroup::NotifyClientOut(uint32_t cid){
	common::Mutex::Locker lock(mtx_);
	IDScopeMap::iterator iter = id_scopes_.find(cid);
	if( iter != id_scopes_.end()){
		this->id_scopes_.erase(iter);
		ClearSocpe(*iter->second,cid);
		delete iter->second;
		message::MGateClientOut* msg = new message::MGateClientOut() ;
		msg->cid = cid;
		this->svr_->PushMessageToQueue(queue_id_,msg);
		msg->UnRef();
	}
}

void ClientGroup::SendToClient(uint32_t id,void*buf,int size){
	this->svr_->SendDataById(buf,size,id);
}
void ClientGroup::ClearSocpe(const std::vector<std::string>& arr,uint32_t id){
	common::Mutex::Locker lock(scope_mtx_);
	for(std::vector<std::string>::const_iterator citer = arr.begin();citer!=arr.end();citer++){
		IDArray *arr;
		ScopeMap::iterator iter = this->scope_map_.find(*citer);
		if( iter != this->scope_map_.end()){
			arr = iter->second;
			for(IDArray::iterator iter = arr->begin();iter != arr->end();iter++){
				if(*iter == id){
					arr->erase(iter);
					break;
				}
			}
		}
	}
}
void ClientGroup::CloseClient(uint32_t id){
	this->svr_->CloseById(id);
	NotifyClientOut(id);
}
void ClientGroup::AddScope(const std::string& name,uint32_t id){
	common::Mutex::Locker lock(mtx_);
	IDScopeMap::iterator iditer = this->id_scopes_.find(id);
	if(iditer  != id_scopes_.end()){
		common::Mutex::Locker lock(scope_mtx_);
		IDArray *arr;
		ScopeMap::iterator iter = this->scope_map_.find(name);
		if(iter == this->scope_map_.end()){
			arr = this->scope_map_[name] = new IDArray();
		}else{
			arr = iter->second;
			for(IDArray::iterator iter = arr->begin();iter != arr->end();iter++){
				if((*iter) == id){
					return;
				}
			}
		}
		arr->push_back(id);
		iditer->second->push_back(name);
	}
}
void ClientGroup::DelScope(const std::string& name,uint32_t id){

	{
		common::Mutex::Locker lock(scope_mtx_);
		IDArray *arr;
		ScopeMap::iterator iter = this->scope_map_.find(name);
		if(iter != this->scope_map_.end()){
			arr = iter->second;
			for(IDArray::iterator iter = arr->begin();iter != arr->end();iter++){
				if(*iter == id){
					arr->erase(iter);
					break;
				}
			}
		}
	}
	common::Mutex::Locker lock(mtx_);
	IDScopeMap::iterator iditer = this->id_scopes_.find(id);
	if(iditer  != id_scopes_.end()){
		for(ScopeArray::iterator iter = iditer->second->begin();iter != iditer->second->end();iter++){
			if(*iter == name){
				iditer->second->erase(iter);
				break;
			}
		}
	}
}
void ClientGroup::DelAllScope(const std::string& name){
	common::Mutex::Locker lock(scope_mtx_);
	ScopeMap::iterator iter = this->scope_map_.find(name);
	if(iter == this->scope_map_.end()){
		return;
	}
	delete iter->second;
	this->scope_map_.erase(iter);
}
void ClientGroup::SendToScope(const std::string& scope,void*buf,int size){
	common::Mutex::Locker lock(scope_mtx_);
	ScopeMap::iterator iter = this->scope_map_.find(scope);
	if(iter == this->scope_map_.end()){
		return;
	}
	IDArray *arr = iter->second;
	common::Mutex::Locker l(mtx_);
	for(IDArray::iterator iter = arr->begin();iter != arr->end();iter++){
		unsigned int id = *iter;
		this->svr_->SendDataById(buf,size,id);
	}
}
void ClientGroup::Clear(){
	{
		common::Mutex::Locker lock(mtx_);
		IDScopeMap::iterator iter = id_scopes_.begin();
		for( ;iter != id_scopes_.end();iter++){
			this->svr_->CloseById(iter->first);
			delete iter->second;
		}
		id_scopes_.clear();
	}{
		common::Mutex::Locker lock(scope_mtx_);
		IDArray *arr;
		ScopeMap::iterator iter = this->scope_map_.begin();
		for(;iter != this->scope_map_.end();iter++){
			delete iter->second;
		}
		this->scope_map_.clear();
	}
}

void ClientGroup::OnQueueMessage(translate::Message* msg){
	switch(msg->GetTag()){
	case message::MCloseClient::TAG:{
		message::MCloseClient* cmsg = static_cast<message::MCloseClient*>(msg);
		this->CloseClient(cmsg->cid);
		break;
	}
	case message::MGateClientData::TAG:{
		message::MGateClientData* dmsg = static_cast<message::MGateClientData*>(msg);
		this->SendToClient(dmsg->cid,dmsg->data,dmsg->size);
		break;
	}
	case message::MScopeOp::TAG:{
		message::MScopeOp* smsg = static_cast<message::MScopeOp*>(msg);
		if(smsg->badd){
			this->AddScope(smsg->scope,smsg->cid);
		}else{
			this->DelScope(smsg->scope,smsg->cid);
		}
		break;
	}
	case message::MScopeData::TAG:{
		message::MScopeData* sdmsg = static_cast<message::MScopeData*>(msg);
		this->SendToScope(sdmsg->scope,sdmsg->data,sdmsg->size);
		break;
	}
	default:
		break;
	}
}

