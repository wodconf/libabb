#ifndef AD_CLOUD_GATE_CLIENT_GROUP_H_
#define AD_CLOUD_GATE_CLIENT_GROUP_H_
#include <string>
#include <map>
#include <vector>
#include "../common/define.hpp"
#include "../common/mutex.hpp"
#include "../translate/connection.hpp"
#include "../common/notification.hpp"
#include <stdint.h>
namespace adcloud{ namespace gate{

class Client;
class ClientService;
class ClientGroup{
public:
	ClientGroup(const std::string& qid,ClientService* svr);
	virtual ~ClientGroup();
	void NotifyClientIn(uint32_t id);
	void NotifyClientMessage(uint32_t id,void*buf,int size);
	void NotifyClientOut(uint32_t id);
	void OnQueueMessage(translate::Message* msg);
private:
	void SendToClient(uint32_t id,void*buf,int size);
	void ClearSocpe(const std::vector<std::string>& arr,uint32_t id);
	void CloseClient(uint32_t id);
	void AddScope(const std::string& name,uint32_t id);
	void DelScope(const std::string& name,uint32_t id);
	void DelAllScope(const std::string& name);
	void SendToScope(const std::string& scope,void*buf,int size);
	void Clear();
private:
	typedef std::vector<std::string> ScopeArray;
	typedef std::vector<unsigned> IDArray;
	typedef std::map<std::string,IDArray*> ScopeMap;
	typedef std::map<uint32_t,ScopeArray*> IDScopeMap;
	IDScopeMap id_scopes_;
	ScopeMap scope_map_;
	common::Mutex mtx_;
	common::Mutex scope_mtx_;
	ClientService* svr_;
	std::string queue_id_;
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(ClientGroup);
};

}}
#endif
