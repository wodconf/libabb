

#ifndef AD_CLOUD_GATE_GATE_HPP_
#define AD_CLOUD_GATE_GATE_HPP_

#include <map>
#include <vector>
#include <string>
#include "../common/define.hpp"
#include "client_service.hpp"
#include "../monitor/mm_client.hpp"
#include <cassert>
namespace adcloud{ namespace gate{
class ClientGroup;
class Config;
class GATE{
public:
	GATE();
	~GATE();
	bool Init(Config* cfg);
	void Start();
	bool GetMasterByApp(const std::string& appid,std::string& addr);
	const std::string& Name(){
		return name_;
	}
private:
	bool Regist();
private:
	ClientService* cli_svr_;
	std::string name_;
	mon::MonitorClient* cli_;
	Config* cfg_;
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(GATE);
};
}}

#endif /* GATE_HPP_ */
