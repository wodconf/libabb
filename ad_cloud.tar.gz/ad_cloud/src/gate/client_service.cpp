

#include "client_service.hpp"
#include "../message/client_message.hpp"
#include "../common/log.hpp"
#include "client_group.hpp"
#include <cassert>
#include "../common/time.hpp"
#include "gate.hpp"
#include "client.hpp"
namespace adcloud{
namespace gate{
class Register: public abb::base::CallBack{
public:
	Register(ClientService* svr,const std::string& appid):self(svr),appid_(appid){
	}
	~Register(){
	};
	void Call(){
		std::string master_addr;
		bool bsuc =false;
		abb::net::IPAddr addr;
		if( self->gate_->GetMasterByApp(appid_,master_addr) ){

			if( addr.SetByString(master_addr) ){
				bsuc = true;
			}else{
				LOG(DEBUG) << "GetMasterByApp Fail addr format fail" << appid_ << "addr:" << master_addr;
			}
		}else{
			LOG(DEBUG) << "GetMasterByApp Fail" << appid_;
		}

		ClientGroup* group = NULL;
		std::string cname = self->gate_->Name()+"&"+appid_;
		if(bsuc){
			if( self->queue_svr_->OpenQueue(cname,master_addr) ){
				LOG(DEBUG) << cname << ".queue.opend";
				group = new ClientGroup(cname,self);
			}else{
				LOG(DEBUG) << cname << ".queue.openfail";
			}
		}
		self->GetGroupBack(cname,group);
		delete this;
	}
private:
	ClientService* self;
	std::string appid_;
};


ClientService::ClientService(GATE* g):gate_(g),actor_(this),start_id_(1),queue_svr_(NULL),rpc_svr_(NULL){
}
bool ClientService::Init(const std::string& gate_addr,const std::string& queue_addr){
	abb::net::IPAddr addr;
	if( ! addr.SetByString(gate_addr) ){
		LOG(WARN) << "Addr Format fail:" << gate_addr;
		return false;
	}
	int error;
	if( !actor_.Bind(addr,&error)){
		LOG(WARN) << "Addr Bind fail:" << gate_addr <<strerror(error);
		return false;
	}
	if( ! addr.SetByString(queue_addr) ){
		LOG(WARN) << "format fail" << queue_addr;
		return false;
	}
	rpc_svr_ = new rpc::RpcServer();
	if( ! rpc_svr_->Bind(addr,&error) ){
		LOG(WARN) << "bind fail"  << queue_addr << strerror(error);
		return false;
	}
	queue_svr_ = new queue::QueueService(this,NULL,rpc_svr_->GetRpcService(),queue_addr);
	return true;
}
ClientService::~ClientService(){
	for( ClientGroupMap::iterator iter = this->cg_map_.begin();iter!=this->cg_map_.end();iter++){
		delete iter->second;
	}
	if(rpc_svr_){
		delete rpc_svr_;
	}
}
void ClientService::Start(){
	actor_.SetEnable(true);
	pool_.SetNumThread(4);
	pool_.Start();
	rpc_svr_->Start();
}
void ClientService::GetGroupBack(const std::string& qname,ClientGroup* group){
	common::RWLock::WLocker lock(cg_lock_);
	if(group){
		this->cg_map_[qname] = group;
	}else{
		this->app_fire_map_[qname] = common::time::MSNow();
	}
	ClientService::RegistClientArray* arr = this->wait_map_[qname];
	this->wait_map_.erase(qname);
	for(int i=0;i<arr->size();i++){
		uint32_t id = (*arr)[i];
		if(group){
			this->ClientRegistOk(group,id);
		}else{
			this->CloseById(id);
		}
	}
}
void ClientService::ClientRegist(Client* cli){
	common::RWLock::WLocker lock(cg_lock_);
	std::string cname = this->gate_->Name()+"&"+ cli->GetAppid();
	ClientGroupMap::iterator iter = this->cg_map_.find (cname);
	if(iter != cg_map_.end()){
		cli->SetGroup(iter->second);
		cli->RegistOk();
		iter->second->NotifyClientIn(cli->GetId());
		return;
	}else{
		RegistClientArray* arr = NULL;
		AppFireMap::iterator fiter = this->app_fire_map_.find(cname);
		if(fiter != app_fire_map_.end()){
			if( 1000 > ( common::time::MSNow() - fiter->second) ){
				cli->Close();
				return;
			}
		}
		WaitGroupMap::iterator witer = wait_map_.find(cname);
		if(witer == wait_map_.end()){
			arr = new RegistClientArray();
			wait_map_[cname] = arr;
			Register* r = new Register(this,cli->GetAppid());
			this->pool_.Execute(r);
		}else{
			arr = witer->second;
		}
		arr->push_back(cli->GetId());
	}

}
void ClientService::ClientMessage(Client* cli,void* buf,int size){
	ClientGroup* group = cli->GetGroup();
	if(group){
		group->NotifyClientMessage(cli->GetId(),buf,size);
	}
}
void ClientService::ClientClose(Client* cli){
	common::RWLock::WLocker lock(client_lock_);
	this->client_map_.erase(cli->GetId());
	ClientGroup* group = cli->GetGroup();
	if(group){
		group->NotifyClientOut(cli->GetId());
	}
	delete cli;
}

void ClientService::ClientRegistOk(ClientGroup* group,uint32_t id){
	common::RWLock::RLocker lock(client_lock_);
	ClientMap::iterator iter = this->client_map_.find(id);
	if(iter != this->client_map_.end()){
		iter->second->SetGroup(group);
		iter->second->RegistOk();
		group->NotifyClientIn(id);
	}
}
void ClientService::SendMessageById(translate::Message& msg,uint32_t id){
	common::RWLock::RLocker lock(client_lock_);
	ClientMap::iterator iter = this->client_map_.find(id);
	if(iter != this->client_map_.end()){
		iter->second->SendMsg(msg);
	}
}
void ClientService::SendDataById(void*buf,int sz,uint32_t id){
	common::RWLock::RLocker lock(client_lock_);
	ClientMap::iterator iter = this->client_map_.find(id);
	if(iter != this->client_map_.end()){
		iter->second->Send(buf,sz);
	}
}
void ClientService::CloseById(uint32_t id){
	common::RWLock::WLocker lock(client_lock_);
	ClientMap::iterator iter = this->client_map_.find(id);
	if(iter != this->client_map_.end()){
		iter->second->Close();
		iter->second->SetGroup(NULL);
		client_map_.erase(iter);
	}
}//
void ClientService::L_Acceptor_OnConnection(translate::Connection* conn){
	uint32_t id = ++start_id_;
	common::RWLock::WLocker lock(client_lock_);
	client_map_[id] = new Client(this,conn,id);
}

void ClientService::L_QueueService_OnQueueOpen(const std::string& id){

}
void ClientService::L_QueueService_OnQueueMessage(const std::string& id,translate::Message* msg){
	common::RWLock::RLocker lock(cg_lock_);
	ClientGroupMap::iterator iter = this->cg_map_.find(id);
	if(iter != cg_map_.end()){
		iter->second->OnQueueMessage(msg);
		return;
	}
}
void ClientService::L_QueueService_OnQueueClose(const std::string& id){
	LOG(DEBUG) << id << ".queue.closed";
	common::RWLock::WLocker lock(cg_lock_);
	ClientGroupMap::iterator iter = this->cg_map_.find(id);
	if(iter != cg_map_.end()){
		delete  iter->second;
		cg_map_.erase(iter);
	}
}
bool ClientService::PushMessageToQueue(const std::string& qname,translate::Message* msg){
	return this->queue_svr_->PushMessageToQueue(qname,msg);
}
}
}
