#ifndef AD_CLOUD_GATE_CLIENT_H_
#define AD_CLOUD_GATE_CLIENT_H_

#include "../common/define.hpp"
#include "../common/buffer.hpp"
#include "../translate/connection.hpp"
#include <vector>
namespace adcloud{ namespace gate{
class ClientGroup;
class ClientService;
class Client:public translate::Connection::Listener {
public:
	Client(ClientService* svr,translate::Connection* self,int id);
	~Client();
	void RegistOk();
	void SendMsg(translate::Message&msg){
		this->conn_->Send(msg);
	}
	void Send(void*buf,int size);
	void Close(){
		this->conn_->Close();
	}
	void SetGroup(ClientGroup* group){
		group_ = group;
	}
	ClientGroup* GetGroup(){
		return group_;
	}
	const std::string& GetAppid(){
		return appid;
	}
	uint32_t GetId(){
		return id_;
	}
	virtual void L_Connection_OnMessage(translate::Connection* self,translate::Message*msg);
	virtual void L_Connection_OnClose(translate::Connection* self);
private:
	translate::Connection* conn_;
	uint32_t id_;
	ClientGroup* group_;
	ClientService* svr_;
	bool bregist;
	std::string appid;
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(Client);
};

}}


#endif
