
#ifndef GATE_CONFIG_HPP_
#define GATE_CONFIG_HPP_
#include <string>
#include <vector>
#include "../common/arg_parse.hpp"
namespace adcloud {
namespace gate {

class Config {
public:
	Config();
	~Config();
	bool Parse( common::ArgParse& arg_parse);

	std::vector<std::string> mon_addrs;
	int max_user;
	std::string addr;
	std::string name;
	std::string queue_addr;
};

} /* namespace gate */
} /* namespace adcloud */

#endif /* GATE_CONFIG_HPP_ */
