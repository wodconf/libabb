#include "client.hpp"
#include "client_service.hpp"
#include "../message/client_message.hpp"
#include <cassert>
using namespace adcloud::gate;

Client::Client(ClientService* svr,translate::Connection* self,int id)
:conn_(self),id_(id),svr_(svr),bregist(false),group_(NULL)
{
	conn_->SetListner(this);
}
Client::~Client(){
	this->conn_->UnRef();
}
void Client::Send(void*buf,int size){
	message::MClientMessage msg;
	msg.data = buf;
	msg.size = size;
	msg.bneedfree_ = false;
	this->conn_->Send(msg);
}
void Client::RegistOk(){
	bregist = true;
	message::MClientRegBak regback;
	conn_->Send(regback);
}
void Client::L_Connection_OnMessage(translate::Connection* conn,translate::Message*msg){
	if(!bregist){
		if(msg->GetTag() == message::MClientReg::TAG){
			message::MClientReg* req = static_cast< message::MClientReg *>(msg);
			appid= req->os_id;
			svr_->ClientRegist(this);
		}else{
			conn->Close();
		}
	}else{
		if(msg->GetTag() == message::MClientMessage::TAG){
			message::MClientMessage* data = static_cast<message::MClientMessage*>(msg);
			data->bneedfree_ = false;
			svr_->ClientMessage(this,data->data,data->size);
		}
	}
}
void Client::L_Connection_OnClose(translate::Connection* self){
	this->svr_->ClientClose(this);
}

