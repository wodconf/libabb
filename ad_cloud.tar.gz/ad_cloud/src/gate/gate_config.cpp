
#include "gate_config.hpp"
#include "../common/log.hpp"
#include "../common/string_tool.hpp"
#include <stdlib.h>
namespace adcloud {
namespace gate {

Config::Config():max_user(1000) {
	// TODO Auto-generated constructor stub
}

Config::~Config() {
}
bool Config::Parse( common::ArgParse& arg_parse){
	std::string val;
	if(! arg_parse.GetValue("addr",addr) ){
		LOG(ERROR) << "ARG (adrr) NOT Exist";
		return false;
	}
	if(! arg_parse.GetValue("queue-addr",queue_addr) ){
		LOG(ERROR) << "ARG (queue-addr) NOT Exist";
		return false;
	}
	if( arg_parse.GetValue("mons",val) ){
		common::StringTool::Split(val,",",this->mon_addrs);
	}else{
		LOG(ERROR) << "ARG (master-mons) NOT Exist";
		return false;
	}
	if( !arg_parse.GetValue("name",this->name)){
		LOG(ERROR) << "ARG (name) NOT Exist";
		return false;
	}
	if( arg_parse.GetValue("max-user",val)){
		this->max_user = atoi(val.c_str());
		if(max_user <= 0){
			LOG(ERROR) << "ARG (max-user) error";
			return false;
		}
	}
	return true;
}
} /* namespace translate */
} /* namespace adcloud */
