/*
 * type_master_data.cpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#include "type_master_data.hpp"

namespace adcloud {
namespace master {

TMasterDataReq::TMasterDataReq():common::SerializationAble(TypeName),bneedfree_(false),size(0),data(NULL){
}
TMasterDataReq::~TMasterDataReq(){

}
uint32_t TMasterDataReq::GetLength(){
	return from_app.length() + to_app.length() + 2 + size;
}
void TMasterDataReq::EncodeBody(common::BufferWriter& buf){
	buf << from_app;
	buf << to_app;
	buf.Write(this->data,this->size);
}
void TMasterDataReq::DecodeBody(common::BufferReader& buf){
	buf >> from_app;
	buf >> to_app;
	this->data = new char[buf.DataSize()];
	this->size = buf.DataSize();
	this->bneedfree_ = true;
	buf.Read(this->data,this->size);
}
const char * TMasterDataReq::TypeName = "adcloud.master.TMasterDataReq";
TMasterDataRsp::TMasterDataRsp():common::SerializationAble(TypeName),success(false){

}
TMasterDataRsp::~TMasterDataRsp(){

}
uint32_t TMasterDataRsp::GetLength(){
	return sizeof(success);
}
void TMasterDataRsp::EncodeBody(common::BufferWriter &buf) {
	buf << success;
}
void TMasterDataRsp::DecodeBody(common::BufferReader &buf) {
	buf >> success;
}
const char * TMasterDataRsp::TypeName = "adcloud.master.TMasterDataRsp";
} /* namespace monraft */
} /* namespace adcloud */
