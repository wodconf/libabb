/*
 * type_master_data.hpp
 *
 *  Created on: 2014-5-23
 *      Author: wd
 */

#ifndef TYPE_MASTER_DATA_HPP_
#define TYPE_MASTER_DATA_HPP_
#include "../common/serialization_able.hpp"
namespace adcloud {
namespace master {
class TMasterDataReq:public common::SerializationAble{
public:
	static const char * TypeName;
	TMasterDataReq();
	virtual ~TMasterDataReq();
public:
	std::string from_app;
	std::string to_app;
	char* data;
	int size;
	bool bneedfree_;
private:
	uint32_t GetLength();
	void EncodeBody(common::BufferWriter& buf);
	void DecodeBody(common::BufferReader& buf);
};
class TMasterDataRsp:public common::SerializationAble{
public:
	static const char * TypeName;
	TMasterDataRsp();
	virtual ~TMasterDataRsp();
public:
	bool success;
private:
	virtual uint32_t GetLength();
	virtual void EncodeBody(common::BufferWriter &buf) ;
	virtual void DecodeBody(common::BufferReader &buf) ;
};
} /* namespace monraft */
} /* namespace adcloud */

#endif /* TYPE_MASTER_DATA_HPP_ */
