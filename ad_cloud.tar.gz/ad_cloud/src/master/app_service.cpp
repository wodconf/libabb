

#include "app_service.hpp"
#include "../message/app_message.hpp"
#include "master.hpp"
#include <cassert>
namespace adcloud {
namespace master {

AppService::AppService(MASTER* m,rpc::RpcServer* svr,const std::string& addr):m_(m),rpc_svr_(svr) {
	queue_svr_ = new queue::QueueService(this,this,rpc_svr_->GetRpcService(),addr);
}
bool AppService::HasApp(const std::string& appid){
	return queue_svr_->HasQueue(appid);
}
void AppService::Start(){
	rpc_svr_->Start();
}
AppService::~AppService() {

}
bool AppService::AuthOk(const std::string& channelid){
	return this->m_->IsValidAppId(channelid);
}
void AppService::NotifyClientIn(const std::string& appid,const std::string& gateid,uint32_t clientid){
	message::MAppClientIn* msg = new message::MAppClientIn();
	msg->gate_id = gateid;
	msg->client_id = clientid;
	this->queue_svr_->PushMessageToQueue(appid,msg);
	msg->UnRef();
}
void AppService::NotifyClientOut(const std::string& appid,const std::string& gateid,uint32_t clientid){
	message::MAppClientOut* msg = new message::MAppClientOut();
	msg->gate_id = gateid;
	msg->client_id = clientid;
	this->queue_svr_->PushMessageToQueue(appid,msg);
	msg->UnRef();
}
void AppService::NotifyClientData(const std::string& appid,const std::string& gateid,uint32_t clientid,void*buf,int size){
	message::MAppClientData* msg =  new message::MAppClientData();;
	msg->gate_id = gateid;
	msg->client_id = clientid;
	msg->data = buf;
	msg->size = size;
	msg->bneedfree_ = true;
	this->queue_svr_->PushMessageToQueue(appid,msg);
	msg->UnRef();
}
void AppService::NotifyAppData(const std::string&from,std::string& to,void*buf,int size){
	message::MAppOtherAppData* msg = new message::MAppOtherAppData();
	msg->appid = from;
	msg->data = buf;
	msg->size = size;
	msg->bneedfree_ = true;
	this->queue_svr_->PushMessageToQueue(to,msg);
	msg->UnRef();
}
void AppService::L_QueueService_OnQueueOpen(const std::string& id){
	LOG(DEBUG) << "app.enter.success." << id;
	common::Mutex::Locker l(mtx_);
	this->app_id_set_.insert(id);
}
bool AppService::IsAppOpened(const std::string& appid){
	common::Mutex::Locker l(mtx_);
	return this->app_id_set_.find(appid) != app_id_set_.end();
}
void AppService::L_QueueService_OnQueueClose(const std::string& id){
	LOG(DEBUG) << "app.leave.success." << id;
	{
		common::Mutex::Locker l(mtx_);
		AppIdSet::iterator iter = this->app_id_set_.find(id);
		if(iter != this->app_id_set_.end()){
			this->app_id_set_.erase(iter);
		}
	}
	this->m_->AppExist(id);
	this->m_->Gate().AppExit(id);
}
void AppService::L_QueueService_OnQueueMessage(const std::string& id,translate::Message*msg){
	switch(msg->GetTag()){
	case message::MAppCloseClient::TAG:{
		message::MAppCloseClient* cmsg = static_cast<message::MAppCloseClient*>(msg);
		this->m_->Gate().CloseClient(id,cmsg->gate_id,cmsg->client_id);
		break;
	}
	case message::MAppClientData::TAG:{
		message::MAppClientData* dmsg = static_cast<message::MAppClientData*>(msg);
		dmsg->bneedfree_ = false;
		this->m_->Gate().ClientData(id,dmsg->gate_id,dmsg->client_id,dmsg->data,dmsg->size);
		break;
	}
	case message::MAppScopeOp::TAG:{
		message::MAppScopeOp* smsg = static_cast<message::MAppScopeOp*>(msg);
		if(smsg->badd){
			this->m_->Gate().AddScope(id,smsg->gate_id,smsg->client_id,id+smsg->scope);
		}else{
			this->m_->Gate().DelScope(id,smsg->gate_id,smsg->client_id,id+smsg->scope);
		}
		break;
	}
	case message::MAppScopeData::TAG:{
		message::MAppScopeData* sdmsg = static_cast<message::MAppScopeData*>(msg);
		sdmsg->bneedfree_ = false;
		this->m_->Gate().ScopeData(id,id+sdmsg->scope,sdmsg->data,sdmsg->size);
		break;
	}
	case message::MAppOtherAppData::TAG:{
		message::MAppOtherAppData* momsg = static_cast<message::MAppOtherAppData*>(msg);
		momsg->bneedfree_ = false;
		this->m_->OM().SendMasterData(id,momsg->appid,momsg->data,momsg->size);
		break;
	}
	default:
		LOG(DEBUG) << "app.unknow.message.tag." <<  msg->GetTag();
		break;
	}
}
} /* namespace translate */
} /* namespace adcloud */
