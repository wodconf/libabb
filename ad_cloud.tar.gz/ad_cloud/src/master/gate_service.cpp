
#include "gate_service.hpp"
#include "../translate/message.hpp"
#include "../message/gate_message.hpp"
#include "master.hpp"
#include "app_service.hpp"
#include <cassert>
namespace adcloud {
namespace master {

GateService::GateService(MASTER* master,rpc::RpcServer* svr,const std::string& addr):rpc_svr_(svr),master_(master) {
	queue_svr_ = new queue::QueueService(this,this,rpc_svr_->GetRpcService(),addr);
}

GateService::~GateService() {
	{
		common::RWLock::WLocker w(this->a2cs_lock_);
		for(AppToChansMap::iterator iter=this->a2cs_map_.begin();iter!= this->a2cs_map_.end();iter++){
			delete iter->second;
		}
	}
	{
		common::Mutex::Locker w(this->c2c_lock_);
		for(ChannleToClientMap::iterator iter=this->c2c_map_.begin();iter!= this->c2c_map_.end();iter++){
			delete iter->second;
		}
	}
}
void GateService::Start(){
	rpc_svr_->Start();
}
bool GateService::AuthOk(const std::string& gateid){
	std::string appid;
	bool ok = GetAppID(gateid,appid);
	LOG(DEBUG) << "AUTH:" << appid;
	if(ok){
		return this->master_->App().IsAppOpened(appid);
	}else{
		return false;
	}
}
bool GateService::CloseClient(const std::string&appid,const std::string& gateid,uint32_t clientid){
	DelCid(gateid,clientid);
	message::MCloseClient* msg = new message::MCloseClient();
	msg->cid = clientid;
	bool bok = this->queue_svr_->PushMessageToQueue(gateid,msg);
	msg->UnRef();
	return bok;
}
bool GateService::ClientData(const std::string&appid,const std::string& gateid,uint32_t clientid,void* data,int len){
	message::MGateClientData* msg = new message::MGateClientData();
	msg->cid = clientid;
	msg->data = (char*)data;
	msg->size = len;
	msg->bneedfree_ = true;
	bool bok = this->queue_svr_->PushMessageToQueue(gateid,msg);
	msg->UnRef();
	return bok;
}
bool GateService::ScopeData(const std::string&appid,const std::string& scope,void* data,int len){
	message::MScopeData* msg = new message::MScopeData();
	msg->scope = scope;
	msg->data = (char*)data;
	msg->size = len;
	msg->bneedfree_ = true;
	common::RWLock::RLocker r(this->a2cs_lock_);
	StrArray* arr;
	AppToChansMap::iterator iter = this->a2cs_map_.find(appid);
	if(iter == this->a2cs_map_.end()){
		return false;
	}
	arr = iter->second;
	for(int i=0;i<(int)arr->size();i++){
		this->queue_svr_->PushMessageToQueue((*arr)[i],msg);
	}
	msg->UnRef();
	return true;
}
bool GateService::AddScope(const std::string&appid,const std::string& gateid,uint32_t clientid,const std::string& scope){
	message::MScopeOp* msg = new message::MScopeOp();
	msg->cid = clientid;
	msg->badd = true;
	msg->scope = scope;
	bool bok = this->queue_svr_->PushMessageToQueue(gateid,msg);
	msg->UnRef();
	return bok;
}
bool GateService::DelScope(const std::string&appid,const std::string& gateid,uint32_t clientid,const std::string& scope){
	message::MScopeOp* msg = new message::MScopeOp();
	msg->cid = clientid;
	msg->badd = false;
	msg->scope = scope;
	bool bok = this->queue_svr_->PushMessageToQueue(gateid,msg);
	msg->UnRef();
	return bok;
}
void GateService::AppExit(const std::string&appid){
	{
		common::RWLock::WLocker w(this->a2cs_lock_);

		StrArray* arr;
		AppToChansMap::iterator iter = this->a2cs_map_.find(appid);
		if(iter == this->a2cs_map_.end()){
			return ;
		}
		arr = iter->second;
		for(int i=0;i<arr->size();i++){
			c2c_lock_.Lock();
			c2c_map_.erase((*arr)[i]);
			c2c_lock_.UnLock();
			this->queue_svr_->CloseQueue((*arr)[i]);
		}
		this->a2cs_map_.erase(appid);
		delete arr;
	}
	{

	}
}
void GateService::L_QueueService_OnQueueOpen(const std::string& id){
	std::string appid;
	bool ok = GetAppID(id,appid);
	if(!ok){
		this->queue_svr_->CloseQueue(id);
	}
	if( ! master_->App().HasApp(appid) ){
		this->queue_svr_->CloseQueue(id);
	}
	{
		common::RWLock::WLocker w(this->a2cs_lock_);
		StrArray* arr;
		AppToChansMap::iterator iter = this->a2cs_map_.find(appid);
		if(iter == this->a2cs_map_.end()){
			arr = new StrArray();
			this->a2cs_map_[appid] = arr;
		}else{
			arr = iter->second;
		}
		arr->push_back(id);
	}
	common::Mutex::Locker l(c2c_lock_);
	this->c2c_map_[id] = new CIDArray();
	LOG(DEBUG) << "gate.open.success." << id;
}
void GateService::L_QueueService_OnQueueClose(const std::string& id){
	LOG(DEBUG) << "gate.leave.success." << id;
	std::string appid;
	bool ok = GetAppID(id,appid);
	assert(ok);
	{
		common::RWLock::WLocker w(this->a2cs_lock_);
		StrArray* arr;
		AppToChansMap::iterator iter = this->a2cs_map_.find(appid);
		if(iter == this->a2cs_map_.end()){
			return ;
		}
		arr = iter->second;
		for(StrArray::iterator iter = arr->begin();iter != arr->end();iter++){
			if(*iter == id){
				arr->erase(iter);
				break;
			}
		}
		if(arr->size() == 0){
			arr->clear();
		}
	}
	CIDArray* arr = NULL;
	{
		common::Mutex::Locker lo(c2c_lock_);
		ChannleToClientMap::iterator iter = this->c2c_map_.find(id);
		if(c2c_map_.end() != iter ){
			arr = iter->second;
			c2c_map_.erase(iter);
		}
	}
	if(arr){
		CIDArray::iterator iter;
		for(iter = arr->begin();iter != arr->end();iter++){
			this->master_->App().NotifyClientOut(appid,id,*iter);
		}
		delete arr;
	}


}
void GateService::L_QueueService_OnQueueMessage(const std::string& id,translate::Message*msg){
	std::string appid;
	bool ok = GetAppID(id,appid);
	assert(ok);
	switch(msg->GetTag()){
	case message::MGateClientIn::TAG:{
		message::MGateClientIn* inmsg = static_cast<message::MGateClientIn*>(msg);
		//LOG(DEBUG) << appid << ".client.in" << inmsg->cid;
		this->AddCid(id,inmsg->cid);
		master_->App().NotifyClientIn(appid,id,inmsg->cid);
		break;
	}
	case message::MGateClientOut::TAG:{
		message::MGateClientOut* outmsg = static_cast<message::MGateClientOut*>(msg);
		//LOG(DEBUG) << appid << ".client.out" << outmsg->cid;
		this->DelCid(id,outmsg->cid);
		master_->App().NotifyClientOut(appid,id,outmsg->cid);
		break;
	}
	case message::MGateClientData::TAG:{
		message::MGateClientData* datamsg = static_cast<message::MGateClientData*>(msg);
		datamsg->bneedfree_ = false;
		master_->App().NotifyClientData(appid,id,datamsg->cid,datamsg->data,datamsg->size);
		break;
	}
	default:
		LOG(DEBUG) << "gate.unknow.message.tag." <<  msg->GetTag();
		break;
	}
}
bool GateService::GetAppID(const std::string& id,std::string&out){
	int pos = id.find('&');
	if(pos == std::string::npos){
		return false;
	}
	out = id.substr(pos+1);
	return true;
}
void GateService::AddCid(const std::string& chanid,uint32_t cid){
	CIDArray* arr = NULL;
	common::Mutex::Locker lo(c2c_lock_);
	ChannleToClientMap::iterator iter = this->c2c_map_.find(chanid);
	if(c2c_map_.end() != iter ){
		arr = iter->second;
	}
	if(!arr)return;
	arr->push_back(cid);
}
void GateService::DelCid(const std::string& chanid,uint32_t cid){
	CIDArray* arr = NULL;
	common::Mutex::Locker lo(c2c_lock_);
	ChannleToClientMap::iterator iter = this->c2c_map_.find(chanid);
	if(c2c_map_.end() != iter ){
		arr = iter->second;
	}
	if(!arr)return;
	for(CIDArray::iterator iter = arr->begin();iter != arr->end();iter++){
		if(*iter == cid){
			arr->erase(iter);
			break;
		}
	}
}
} /* namespace translate */
} /* namespace adcloud */
