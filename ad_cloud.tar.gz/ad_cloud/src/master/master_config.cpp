
#include "master_config.hpp"
#include "../common/config_file.hpp"
#include "../common/log.hpp"
#include "../common/string_tool.hpp"
#include <cstdlib>
namespace adcloud {
namespace master {

Config::Config()
:gate_port(0),
 app_port(0),
 om_port(0),max_num(10000){

}

Config::~Config() {
}
bool Config::Parse( common::ArgParse& arg_parse){
	std::string val;
	if(! arg_parse.GetValue("host",host) ){
		LOG(ERROR) << "arg.(host).not.exist";
		return false;
	}
	if( !arg_parse.GetValue("inhost",in_host) ){
		LOG(ERROR) << "arg.(inhost).not.exist";
		return false;
	}
	if( arg_parse.GetValue("mons",val) ){
		common::StringTool::Split(val,",",this->mon_addr_list_);
	}else{
		LOG(ERROR) << "arg.(mons).not.exist";
		return false;
	}
	if( arg_parse.GetValue("gate-port",val)){
		this->gate_port = atoi(val.c_str());
	}else{
		LOG(ERROR) << "arg.(gate-port).not.exist";
		return false;
	}
	if( arg_parse.GetValue("app-port",val)){
		this->app_port = atoi(val.c_str());
	}else{
		LOG(ERROR) << "arg.(app-port).not.exist";
		return false;
	}
	if( arg_parse.GetValue("om-port",val)){
		this->om_port = atoi(val.c_str());
	}else{
		LOG(ERROR) << "arg.(om-port).not.exist";
		return false;
	}
	if( arg_parse.GetValue("max-num",val)){
		int num = atoi(val.c_str());
		if(num >0){
			this->max_num = num;
		}else{
			LOG(ERROR) << "arg.(max-num).less.zero";
		}
	}else{
		LOG(ERROR) << "arg.(max-num).not.exist";
		return false;
	}

	if( !arg_parse.GetValue("name",this->name)){
		LOG(ERROR) << "ARG (name) NOT Exist";
		return false;
	}

	return true;
}

} /* namespace translate */
} /* namespace adcloud */
