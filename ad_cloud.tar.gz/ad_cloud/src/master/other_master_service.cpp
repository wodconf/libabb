
#include "other_master_service.hpp"
#include "master.hpp"
#include "../message/m_master_data.hpp"
#include "app_service.hpp"
#include <cassert>
#include "type_master_data.hpp"
#include "other_master.hpp"
namespace adcloud {
namespace master {

class FMasterData:public rpc::RpcService::IRpcFunction{
public:
	FMasterData(MASTER* p):self(p){};
	virtual ~FMasterData(){};
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& save_error){
		TMasterDataReq* req = static_cast<TMasterDataReq*>(arg);
		self->App().NotifyAppData(req->from_app,req->to_app,req->data,req->size);
		TMasterDataRsp* rsp = new TMasterDataRsp();
		rsp->success = true;
		return rsp;
	}
	virtual void Finsh(common::SerializationAble* res){
		if(res)res->UnRef();
	}
private:
	MASTER* self;
};
class FPing:public rpc::RpcService::IRpcFunction{
public:
	FPing(){};
	virtual ~FPing(){};
	virtual common::SerializationAble* CallFunction(common::SerializationAble* arg,std::string& save_error){
		return NULL;
	}
	virtual void Finsh(common::SerializationAble* res){
	}
};
OtherMasterService::OtherMasterService(MASTER* master,rpc::RpcServer* rpc_svr)
:master_(master),
 rpc_svr_(rpc_svr),
 pool_(this),
 master_data_fn_(new FMasterData(master)),
 get_id_(-1),
 ping_id_(-1),
 ping_fn_(new FPing())
{
	rpc_svr_->GetRpcService()->RegistFunction(METHOD_MASTER_DATA,master_data_fn_);
	rpc_svr_->GetRpcService()->RegistFunction(METHOD_MASTER_PING,ping_fn_);
}

OtherMasterService::~OtherMasterService() {

}
void OtherMasterService::Start(){
	rpc_svr_->Start();
	this->GetOtherMaster();
	get_id_ = this->master_->Timer().SetTimer(this,5000,true);
	ping_id_ = this->master_->Timer().SetTimer(this,3000,true);
}
void OtherMasterService::L_Timer_OnTimout(int id){
	if(id == get_id_){
		this->GetOtherMaster();
	}else if(id==ping_id_){
		this->Ping();
		this->CheckLose();
	}
}
void  OtherMasterService::Ping(){
	common::RWLock::RLocker r( rw_lock_ );
	MasterMap::iterator iter = this->addr_master_map_.begin();
	for(;iter != this->addr_master_map_.end();iter++){
		iter->second->Ping();
	}
}
void  OtherMasterService::CheckLose(){
	std::vector<std::string> arr;
	{
		common::RWLock::WLocker r( rw_lock_ );
		MasterMap::iterator iter = this->addr_master_map_.begin();
		for(;iter != this->addr_master_map_.end();){
			if( iter->second->LoseNum() >= 5){
				std::string name = iter->second->GetName();
				iter->second->UnRef();
				this->addr_master_map_.erase(iter++);
				this->name_master_map_.erase(name);
				arr.push_back(name);
			}else{
				iter++;
			}
		}
	}
	for(int i=0;i<arr.size();i++){
		LOG(DEBUG)<<"maser.lose.name="<<arr[i];
		this->master_->MonClient()->LoseMaster( arr[i]);
	}
}
void  OtherMasterService::GetOtherMaster(){
	std::map<std::string,std::string> om;
	if(this->master_->MonClient()->GetMaster(om)){
		common::RWLock::WLocker w( rw_lock_ );
		std::map<std::string,std::string>::iterator iter = om.begin();
		for(;iter!=om.end();iter++){
			MasterMap::iterator m_iter = this->name_master_map_.find(iter->first);
			if(m_iter != this->name_master_map_.end()){
				if(m_iter->second->GetAddr() == iter->second){
					continue;
				}else{
					LOG(DEBUG) << "othermaster.replace.new." << iter->first << "." << iter->second <<".old." << m_iter->first << "." << m_iter->second->GetAddr();
					m_iter->second->UnRef();
					m_iter->second = new OtherMaster(this,iter->second,iter->first);
					this->addr_master_map_[iter->second] = m_iter->second;
				}
			}else if(iter->first == master_->GetName()){
				continue;
			}else{
				LOG(DEBUG) << "othermaster.add." << iter->first << "." << iter->second;
				OtherMaster* m = new OtherMaster(this,iter->second,iter->first);
				this->name_master_map_[iter->first] = m;
				this->addr_master_map_[iter->second] = m;
			}
		}
	}
}
bool  OtherMasterService::SendMasterData(const std::string& fromid,const std::string& toappid,void* data,int size){
	std::string addr;
	if( !this->master_->MonClient()->GetAppAt(toappid,addr) ){
		return false;
	}
	common::RWLock::RLocker r( rw_lock_ );
	MasterMap::iterator iter = this->addr_master_map_.find(addr);
	if(iter != this->addr_master_map_.end()){
		return iter->second->SendMasterData(fromid,toappid,data,size);
	}else{
		return false;
	}
}

void OtherMasterService::L_ClientPool_ConnectionReset(const std::string& addr){
	common::RWLock::RLocker r( rw_lock_ );
	MasterMap::iterator iter = this->addr_master_map_.find(addr);
	if(iter != this->addr_master_map_.end()){
		iter->second->OnClose();
	}
}
void OtherMasterService::L_ClientPool_ConnectionMessage(const std::string& addr,translate::Message* msg){
	if(msg->GetTag() == rpc::MRpcResponce::TAG){
		common::RWLock::RLocker r( rw_lock_ );
		MasterMap::iterator iter = this->addr_master_map_.find(addr);
		if(iter != this->addr_master_map_.end()){
			iter->second->OnRpcMessage(static_cast<rpc::MRpcResponce*>(msg));
		}
	}
}

} /* namespace master */
} /* namespace adcloud */
