
#ifndef OTHER_MASTER_HPP_
#define OTHER_MASTER_HPP_

#include "../rpc/rpc_client.hpp"
#include "../common/ref_object.hpp"
namespace adcloud {
namespace master {
class OtherMasterService;
class OtherMaster :public rpc::RpcClient::ISend,public common::RefObject{
public:
	OtherMaster(OtherMasterService* svr,const std::string& addr,const std::string& name);
	~OtherMaster();
	virtual bool ISend_Send(translate::Message& msg);
	void OnRpcMessage(rpc::MRpcResponce* rpcmsg){
		rpcclient_->OnMessage(rpcmsg);
	}
	void OnClose(){
		rpcclient_->OnClose();
	}
	bool SendMasterData(const std::string& fromid,const std::string& toappid,void* data,int size);
	const std::string GetAddr(){
		return addr_;
	}
	const std::string GetName(){
			return name_;
		}
	void Ping();
	int LoseNum(){
		return lose;
	}
private:
	int lose;
	OtherMasterService* owner_;
	rpc::RpcClient* rpcclient_;
	std::string addr_;
	std::string name_;
};

} /* namespace monraft */
} /* namespace adcloud */

#endif /* OTHER_MASTER_HPP_ */
