

#ifndef APP_SERVICE_HPP_
#define APP_SERVICE_HPP_
#include "../common/mutex.hpp"
#include "../queue/queue_service.hpp"
#include "../rpc/rpc_server.hpp"
#include <map>
#include <set>
#include <string>
#include <vector>
namespace adcloud {
namespace master {
class MASTER;
class AppService :public queue::QueueService::Listener,queue::QueueService::IAuth{
public:
	AppService(MASTER* m,rpc::RpcServer* chan_svr,const std::string& addr);
	~AppService();
	bool HasApp(const std::string& appid);
	void Start();
	void NotifyClientIn(const std::string& appid,const std::string& gateid,uint32_t clientid);
	void NotifyClientOut(const std::string& appid,const std::string& gateid,uint32_t clientid);
	void NotifyClientData(const std::string& appid,const std::string& gateid,uint32_t clientid,void*buf,int size);

	void NotifyAppData(const std::string&from,std::string& to,void*buf,int size);

	virtual void L_QueueService_OnQueueOpen(const std::string& id);
		virtual void L_QueueService_OnQueueMessage(const std::string& id,translate::Message*msg);
		virtual void L_QueueService_OnQueueClose(const std::string& id);
		virtual bool AuthOk(const std::string& channelid);

	bool IsAppOpened(const std::string& appid);

private:
	queue::QueueService* queue_svr_;
	rpc::RpcServer* rpc_svr_;
	common::Mutex mtx_;
	MASTER* m_;
	typedef std::set<std::string> AppIdSet;
	AppIdSet app_id_set_;
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* APP_SERVICE_HPP_ */
