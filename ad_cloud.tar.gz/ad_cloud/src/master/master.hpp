
#ifndef MASTER_H_
#define MASTER_H_

#include "../translate/message.hpp"
#include "app_service.hpp"
#include "gate_service.hpp"
#include "other_master_service.hpp"
#include <string>
#include "../monitor/mm_client.hpp"
#include "../common/timer.hpp"
namespace adcloud {
namespace master {
class Config;
class MASTER {
public:
	MASTER();
	virtual ~MASTER();
	bool Init(Config* cfg);
	void Start();
	void AppExist(const std::string& appid);
	AppService& App(){
		return *this->app_svr_;
	}
	GateService& Gate(){
		return *this->gate_svr_;
	}
	bool IsValidAppId(const std::string& appid);
	OtherMasterService& OM(){
		return *om_svr_;
	}
	mon::MonitorClient* MonClient(){
		return cli_;
	}
	const std::string& GetName(){
		return name_;
	}
	common::Timer& Timer(){
		return timer_;
	}
private:
	bool Regist();
private:
	std::string name_;
	AppService* app_svr_;
	Config* config_;
	GateService* gate_svr_;
	OtherMasterService* om_svr_;
	mon::MonitorClient* cli_;
	common::Timer timer_;
	uint32_t cur_num;
	common::Mutex mtx_;
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* MASTER_H_ */
