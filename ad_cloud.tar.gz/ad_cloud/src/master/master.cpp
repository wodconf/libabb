

#include "master.hpp"
#include "master_config.hpp"
#include "app_service.hpp"
#include "gate_service.hpp"
#include "type_master_data.hpp"
#include "common/time.hpp"
namespace adcloud {
namespace master {

MASTER::MASTER()
:app_svr_( NULL ),
 gate_svr_(NULL),
 om_svr_(NULL),
 config_(NULL),
 cli_(NULL),
 cur_num(0)
{

}
MASTER::~MASTER() {
	if( app_svr_){
		delete app_svr_;
	}
	if( gate_svr_){
		delete app_svr_;
	}
	if( om_svr_){
		delete app_svr_;
	}
	if( cli_){
		delete app_svr_;
	}
}
bool MASTER::Init(Config* config){
	config_ = config;
	abb::net::IPAddr addr;
	if( ! addr.SetV4(config->host.c_str(),config->gate_port) ){
		LOG(WARN) << "format fail" << config->host << ":"<<config->gate_port;
		return false;
	}
	rpc::RpcServer* gate_svr = new rpc::RpcServer();
	int error;
	if( !gate_svr->Bind(addr,&error) ){
		LOG(WARN) << "bind fail" << config->host << ":"<<config->gate_port << strerror(error);
		delete gate_svr;
		return false;
	}
	//
	if( ! addr.SetV4(config->host.c_str(),config->app_port) ){
		LOG(WARN) << "format fail" << config->host << ":"<<config->app_port;
		delete gate_svr;
		return false;
	}
	rpc::RpcServer* app_svr = new rpc::RpcServer();
	if( ! app_svr->Bind(addr,&error) ){
		LOG(WARN) << "bind fail"  << config->host<< ":"<<config->app_port << strerror(error);
		delete gate_svr;
		delete app_svr;
		return false;
	}
	//
	if( ! addr.SetV4(config->in_host.c_str(),config->om_port) ){
		LOG(WARN) << "addr format fail"  << config->in_host << ":"<<config->om_port;
		delete gate_svr;
		delete app_svr;
		return false;
	}
	rpc::RpcServer* other_svr = new rpc::RpcServer();
	if( ! other_svr->Bind(addr,&error) ){
		LOG(WARN) << "bind fail"  << config->in_host << ":"<<config->om_port << strerror(error);
		delete gate_svr;
		delete app_svr;
		delete other_svr;
		return false;
	}
	app_svr_ = new AppService(this,app_svr,config_->GetAppAddr());
	gate_svr_ = new GateService(this,gate_svr,config_->GetGateAddr());
	om_svr_ = new OtherMasterService(this,other_svr);
	cli_ = new mon::MonitorClient();
	cli_->SetAddrs(this->config_->mon_addr_list_);
	name_ = config_->name;

	common::SerializationAble::RegistCreator(TMasterDataReq::TypeName,common::T_SerializationAbleCreator<TMasterDataReq>);
	common::SerializationAble::RegistCreator(TMasterDataRsp::TypeName,common::T_SerializationAbleCreator<TMasterDataRsp>);

	return this->Regist();
}
void MASTER::Start(){
	this->app_svr_->Start();
	this->gate_svr_->Start();
	this->om_svr_->Start();
	LOG(INFO) << "MasterStart";
	while(true){
		timer_.Loop();
	}
}
void MASTER::AppExist(const std::string& appid){
	this->cli_->MasterDelApp(this->name_,appid);
}
bool MASTER::Regist(){
	int retry = 3;
	while(retry>0){
		if( this->cli_->AddMaster(this->name_,config_->host,config_->in_host,config_->gate_port,config_->app_port,config_->om_port,config_->max_num) ){

			LOG(INFO) << "regist success";
			return true;
		}
		--retry;
	}
	return false;
}
bool MASTER::IsValidAppId(const std::string& appid){
	if(appid == "appx") exit(0);
	//TODO auth app and get num;
	uint32_t num = 100;
	common::Mutex::Locker l( mtx_ );
	if(config_->max_num - cur_num < num){
		return false;
	}
	bool bok = this->cli_->MasterAddApp(this->name_,appid,num);
	if(bok){
		cur_num+=num;
	}
	return bok;
}

}
}
