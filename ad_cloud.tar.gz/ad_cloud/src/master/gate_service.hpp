

#ifndef GATE_SERVICE_H_
#define GATE_SERVICE_H_

#include <string>
#include <map>
#include "../queue/queue_service.hpp"
#include "../rpc/rpc_server.hpp"
#include "../common/rw_lock.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
namespace adcloud {
namespace master {
class MASTER;
class GateService :public queue::QueueService::Listener,queue::QueueService::IAuth{
public:
	GateService(MASTER* master,rpc::RpcServer* svr,const std::string& addr);
	~GateService();

	void Start();

	bool CloseClient(const std::string&appid, const std::string& gateid,uint32_t clientid);
	bool ClientData(const std::string&appid, const std::string& gateid,uint32_t clientid,void* data,int len);
	bool ScopeData(const std::string&appid,const std::string& socpe,void* data,int len);
	bool AddScope(const std::string&appid, const std::string& gateid,uint32_t clientid,const std::string& socpe);
	bool DelScope(const std::string&appid, const std::string& gateid,uint32_t clientid,const std::string& socpe);

	void AppExit(const std::string&appid);

	virtual void L_QueueService_OnQueueOpen(const std::string& id);
	virtual void L_QueueService_OnQueueMessage(const std::string& id,translate::Message*msg);
	virtual void L_QueueService_OnQueueClose(const std::string& id);
	virtual bool AuthOk(const std::string& channelid);
private:
	bool GetAppID(const std::string& id,std::string&out);
	/*bool GetChannelIdAndCid(const std::string& id,std::string&chanid,unsigned& cid){
		int pos = id.find('*');
		if(pos == std::string::npos){
			return false;
		}
		chanid = id.substr(0,pos);
		cid = static_cast<unsigned>(atoi(id.substr(pos+1).c_str()));
		return true;
	}
	std::string EncodeCid(const std::string& chanid,unsigned cid){
		std::ostringstream s;
		s << cid;
		return chanid+"*"+s.str();
	}*/
	void AddCid(const std::string& chanid,uint32_t cid);
	void DelCid(const std::string& chanid,uint32_t cid);
private:
	typedef std::vector<uint32_t> CIDArray;
	typedef std::map<std::string,CIDArray*> ChannleToClientMap;
	typedef std::vector<std::string> StrArray;
	typedef std::map<std::string,StrArray*> AppToChansMap;

	ChannleToClientMap c2c_map_;
	AppToChansMap a2cs_map_;
	queue::QueueService* queue_svr_;
	rpc::RpcServer * rpc_svr_;
	MASTER* master_;
	common::Mutex c2c_lock_;
	common::RWLock a2cs_lock_;
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* GATE_SERVICE_H_ */
