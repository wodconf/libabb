

#ifndef MASTER_CONFIG_HPP_
#define MASTER_CONFIG_HPP_
#include <string>
#include <stdint.h>
#include <vector>
#include "../common/arg_parse.hpp"
#include <sstream>
namespace adcloud {
namespace master {

class Config {
public:
	Config();
	~Config();
	bool Parse( common::ArgParse& arg_parse);
	std::string GetGateAddr(){
		std::ostringstream s;
		s << host << ":" << gate_port;
		return s.str();
	}
	std::string GetOmAddr(){
		std::ostringstream s;
		s << in_host << ":" << om_port;
		return s.str();
	}
	std::string GetAppAddr(){
			std::ostringstream s;
			s << host << ":" << app_port;
			return s.str();
		}
	int gate_port;
	int app_port;
	int om_port;
	std::string host;
	std::string in_host;
	std::string name;
	std::vector<std::string> mon_addr_list_;
	uint32_t max_num;
};

} /* namespace master */
} /* namespace adcloud */

#endif
