

#ifndef OTHER_MASTER_SERVICE_HPP_
#define OTHER_MASTER_SERVICE_HPP_
#include <map>
#include "../rpc/rpc_server.hpp"
#include "../translate/client_pool.hpp"
#include "../common/timer.hpp"


#define METHOD_MASTER_DATA "MasterData"

#define METHOD_MASTER_PING "MasterPing"
namespace adcloud {
namespace master {
class MASTER;
class FMasterData;
class FPing;
class OtherMaster;
class OtherMasterService:public translate::ClientPool::Listener,common::Timer::Listener {
public:
	OtherMasterService(MASTER* master,rpc::RpcServer* rpc_svr);
	~OtherMasterService();
	void Start();
	bool SendMasterData(const std::string& fromappid,const std::string& toappid,void* data,int size);
	bool SendMessageToAddr(const std::string& addr,translate::Message& msg){
		return pool_.SendToAddr(msg,addr);
	}
	void L_ClientPool_ConnectionReset(const std::string& addr);
	void L_ClientPool_ConnectionMessage(const std::string& addr,translate::Message* msg);
	virtual void L_Timer_OnTimout(int id);
private:
	void GetOtherMaster();
private:
	void Ping();
	void CheckLose();
	/*void* ThreadMain(void*arg){
		OtherMasterService* s = (OtherMasterService*)(arg);
		s->Loop();
		return NULL;
	}
	void Loop();*/
	typedef std::map<std::string,OtherMaster* >MasterMap;
	MasterMap name_master_map_;
	MasterMap addr_master_map_;
	MASTER* master_;
	rpc::RpcServer* rpc_svr_;
	common::RWLock rw_lock_;
	translate::ClientPool pool_;
	FMasterData * master_data_fn_;
	FPing * ping_fn_;
	int get_id_;
	int ping_id_;
	//common::Thread thread_;
	//common::Notification notify_;
	//bool bstop_;
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* OTHER_MASTER_SERVICE_HPP_ */
