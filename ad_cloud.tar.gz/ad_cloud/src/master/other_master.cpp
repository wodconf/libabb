
#include "other_master.hpp"
#include "other_master_service.hpp"
#include "type_master_data.hpp"
namespace adcloud {
namespace master {




OtherMaster::OtherMaster(OtherMasterService* svr,const std::string& addr,const std::string& name):addr_(addr),owner_(svr),lose(0),name_(name) {
	rpcclient_ = new rpc::RpcClient(this);
}

OtherMaster::~OtherMaster() {
	this->rpcclient_->OnClose();
	this->rpcclient_->UnRef();
}
bool OtherMaster::ISend_Send(translate::Message& msg){
	return this->owner_->SendMessageToAddr(this->addr_,msg);
}
bool OtherMaster::SendMasterData(const std::string& fromid,const std::string& toappid,void* data,int size){
	TMasterDataReq req;
	req.from_app = fromid;
	req.to_app = toappid;
	req.data = (char*)data;
	req.size = size;
	std::string err;
	TMasterDataRsp* rsp = static_cast<TMasterDataRsp*>( this->rpcclient_->Call(METHOD_MASTER_DATA,&req,err) );
	if(rsp){
		bool b = rsp->success;
		rsp->UnRef();
		return b;
	}else{
		LOG(DEBUG) << "MasterData.fail.err." << err;
		return false;
	}
}
void OtherMaster::Ping(){
	std::string err;
	static_cast<TMasterDataRsp*>( this->rpcclient_->Call(METHOD_MASTER_PING,NULL,err) );
	if(!err.empty()){
		lose++;
		LOG(DEBUG) << "ping.timeout->" << this->name_ << ".err=" << err << ".lose=" << lose;
	}else{
		lose = 0;
	}
}
} /* namespace monraft */
} /* namespace adcloud */
