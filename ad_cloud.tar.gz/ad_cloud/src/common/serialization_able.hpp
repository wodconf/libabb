
#ifndef SERIALIZATION_ABLE_HPP_
#define SERIALIZATION_ABLE_HPP_

#include "ref_object.hpp"
#include <string>
#include <map>
#include "buffer_reader.hpp"
#include "buffer_writer.hpp"

namespace adcloud {
namespace common {

class SerializationAble:public RefObject{
public:
	typedef SerializationAble* (*type_createor)();
	typedef  std::map<std::string,type_createor> CreateMap;
	static void RegistCreator(const std::string& name,type_createor fn);

	static SerializationAble* Decode(common::BufferReader& buf);
private:
	static CreateMap s_create_map_;
public:
	SerializationAble(const std::string& name):type_name(name){};
	virtual ~SerializationAble(){};
	uint32_t Length();
	void Encode(common::BufferWriter &buf);
	const std::string& GetTypeName(){
		return type_name;
	}
private:
	virtual uint32_t GetLength() = 0;
	virtual void EncodeBody(common::BufferWriter &buf) = 0;
	virtual void DecodeBody(common::BufferReader &buf) = 0;
private:
	std::string type_name;
};

template <class T>
SerializationAble* T_SerializationAbleCreator(){
	return new T();
}

} /* namespace raft */
} /* namespace adcloud */

#endif /* SERIALIZATION_ABLE_HPP_ */
