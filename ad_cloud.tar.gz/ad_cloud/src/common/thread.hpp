#ifndef AD_CLOUD_THREAD_HPP_
#define AD_CLOUD_THREAD_HPP_

#include <pthread.h>
#include "define.hpp"
namespace adcloud{
	namespace common{
	class Thread{
	public:
		Thread();
		~Thread();
		typedef void* (*thread_fn)(void*arg);
		void Start(thread_fn fn,void*arg);
		void Wait();
		pthread_t ID(){
			return tid_;
		}
	private:
		pthread_t tid_;
		bool bstart_;
		AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(Thread);
	};
	}
}
#endif
