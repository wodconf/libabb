#ifndef AD_CLOUND_COMMON_DEFINE_H_
#define AD_CLOUND_COMMON_DEFINE_H_


#define AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(TypeName) \
	private:\
  	TypeName(const TypeName&);               \
  	TypeName& operator=(const TypeName&)

#endif
