/*
 * string_tool.cpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#include "string_tool.hpp"

namespace adcloud {
namespace common {

StringTool::StringTool() {
	// TODO Auto-generated constructor stub

}

StringTool::~StringTool() {
	// TODO Auto-generated destructor stub
}
void StringTool::Split(const std::string&str,const std::string& sep,std::vector<std::string>& s_arr){
	int pre_pos = 0;
	while(true){
		int pos = str.find(sep,pre_pos);
		if( pos != std::string::npos ){
			pre_pos = pos+1;
			s_arr.push_back(str.substr(0,pos));
		}else{
			s_arr.push_back(str.substr(pre_pos));
			break;
		}
	}
}
} /* namespace common */
} /* namespace adcloud */
