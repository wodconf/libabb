
#include "notification.hpp"
#include <errno.h>
namespace adcloud {
namespace common {

Notification::Notification():bsingle_(false) {

}
Notification::~Notification() {
}
void Notification::Wait(){
	Mutex::Locker l(mtx_);
	if(!bsingle_){
		cond_.Wait(mtx_);
	}
	bsingle_ =false;
}
bool Notification::WaitTimeout(int timeout){
	Mutex::Locker l(mtx_);
	if(!bsingle_){
		cond_.WaitTimeout(mtx_,timeout);
	}
	bool tmp = bsingle_;
	bsingle_ = false;
	return tmp;
}
void Notification::Notify(){
	Mutex::Locker l(mtx_);
	bsingle_ = true;
	cond_.Broadcast();
}
} /* namespace translate */
} /* namespace adcloud */
