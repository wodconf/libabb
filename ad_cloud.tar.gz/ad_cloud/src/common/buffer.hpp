#ifndef _ADCLOUD_COMMON_BUFFER_H_
#define _ADCLOUD_COMMON_BUFFER_H_ 1

#include <string>
#include <stddef.h>
#include "define.hpp"
#include <abb/base/buffer.hpp>
namespace adcloud { namespace common{

typedef abb::base::Buffer Buffer;

}}

#endif
