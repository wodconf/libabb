#include "thread.hpp"


namespace adcloud{
namespace common{
Thread::Thread():tid_(-1),bstart_(false){

}
Thread::~Thread(){

}
void Thread::Start(Thread::thread_fn fn,void* arg){
	bstart_ = true;
	pthread_create(&tid_,NULL,fn,arg);
}
void Thread::Wait(){
	if(bstart_){
		pthread_join(tid_,NULL);
		bstart_ = false;
	}
}
}
}
