#ifndef AD_CLOUD_LOG_H_
#define AD_CLOUD_LOG_H_

#include <abb/base/log.hpp>

#define AD_CLOUD_INFO LOG(INFO)
#define AD_CLOUD_DEBUG  LOG(INFO)
#define AD_CLOUD_ERROR  LOG(ERROR)
#define AD_CLOUD_WARN   LOG(WARN)

#endif
