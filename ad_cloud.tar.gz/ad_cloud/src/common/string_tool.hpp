/*
 * string_tool.hpp
 *
 *  Created on: 2014-5-16
 *      Author: wd
 */

#ifndef STRING_TOOL_HPP_
#define STRING_TOOL_HPP_
#include <string>
#include <vector>
namespace adcloud {
namespace common {

class StringTool {
public:
	static void Split(const std::string&str,const std::string& sep,std::vector<std::string>& s_arr);
private:
	StringTool();
	~StringTool();
};

} /* namespace common */
} /* namespace adcloud */

#endif /* STRING_TOOL_HPP_ */
