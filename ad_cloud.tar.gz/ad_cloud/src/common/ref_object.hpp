

#ifndef AD_CLOUD_COMMON_REF_OBJECT_HPP_
#define AD_CLOUD_COMMON_REF_OBJECT_HPP_

namespace adcloud {
namespace common {

class RefObject {
public:
	RefObject():ref_(1){}
	virtual ~RefObject(){};
	void Ref() {
		__sync_add_and_fetch(&ref_,1);
		return;
	}
	bool UnRef() {
		if (__sync_sub_and_fetch(&ref_,1) == 0){
			delete this;
			return true;
		}else{
			return false;
		}
	}
	RefObject* Get(){
		this->Ref();
		return this;
	}
private:
	int ref_;
};

} /* namespace translate */
} /* namespace adcloud */

#endif
