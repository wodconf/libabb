
#ifndef CONFIG_FILE_HPP_
#define CONFIG_FILE_HPP_
#include <string>
#include <map>
namespace adcloud { namespace common{
class ConfigFile {
public:
	ConfigFile();
	~ConfigFile();
	bool Parse(const std::string& path);
	bool GetValue(const std::string& key,std::string&val);
private:
	typedef std::map<std::string,std::string> ValueMap;
	ValueMap kv_map;
};
}}
#endif /* CONFIG_FILE_HPP_ */
