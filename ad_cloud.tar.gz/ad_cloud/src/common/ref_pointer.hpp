#ifndef AD_CLOUD_COMMON_REF_POINTER_HPP_
#define AD_CLOUD_COMMON_REF_POINTER_HPP_
template<class TYPE>
class RefPointer{
public:
	RefPointer(TYPE* ptr):ptr_(ptr){
	}
	~RefPointer(){
		if(ptr_)
			ptr_->UnRef();
	}
	RefPointer(const RefPointer& other) {
		if(other.ptr_)
			other.ptr_->Ref();
		ptr_ = other.ptr_;
	}
	RefPointer& operator=(const RefPointer& other){
		if(other.ptr_)
			other.ptr_->Ref();
		if(ptr_)
			ptr_->UnRef();
		ptr_ = other.ptr_;
		return *this;
	}
	bool IsNull(){
		return ptr_ == NULL;
	}
	TYPE* operator ->(){
		return ptr_;
	}
	TYPE operator*(){
		return *ptr_;
	} 
private:
	TYPE* ptr_;
};
#endif
