/*
 * buffer_exception.hpp
 *
 *  Created on: 2014-5-19
 *      Author: wd
 */

#ifndef BUFFER_EXCEPTION_HPP_
#define BUFFER_EXCEPTION_HPP_

#include <exception>

namespace adcloud{
namespace common{
class BufferException:public std::exception{
public:
	BufferException()_GLIBCXX_USE_NOEXCEPT{}
	virtual ~BufferException() _GLIBCXX_USE_NOEXCEPT{}
	virtual const char* what() const _GLIBCXX_USE_NOEXCEPT{
		return "OUT OF RANGE";
	}
};
}
}



#endif /* BUFFER_EXCEPTION_HPP_ */
