/*
 * mutex.hpp
 *
 *  Created on: 2014��4��18��
 *      Author: goalworld
 */

#ifndef _ADCLOUD_COMMON_MUTEX_HPP_
#define _ADCLOUD_COMMON_MUTEX_HPP_
#include <pthread.h>
#include "define.hpp"
namespace adcloud{ namespace common{

class Mutex{
public:
	struct Locker{
		Locker(Mutex&mtx):refmtx_(mtx){
			refmtx_.Lock();
		}
		~Locker(){
			refmtx_.UnLock();
		}
		Mutex& refmtx_;
	};
public:
	Mutex(){
		pthread_mutexattr_t attr;
		pthread_mutexattr_init(&attr);
		pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
		pthread_mutex_init(&mtx_,&attr);
	};
	~Mutex(){
		pthread_mutex_destroy(&mtx_);
	}
	void Lock(){
		pthread_mutex_lock(&mtx_);
	}
	void UnLock(){
		pthread_mutex_unlock(&mtx_);
	}
	pthread_mutex_t mtx_;
private:
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(Mutex);
};
}}



#endif /* MUTEX_HPP_ */
