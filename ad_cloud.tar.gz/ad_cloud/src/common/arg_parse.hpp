/*
 * arg_parse.hpp
 *
 *  Created on: 2014-5-13
 *      Author: wd
 */

#ifndef ARG_PARSE_HPP_
#define ARG_PARSE_HPP_

#include <map>
#include <string>

namespace adcloud{
namespace common{
class ArgParse {
public:
	ArgParse();
	virtual ~ArgParse();
	void Parse(int argc,const char* argv[]);
	bool GetValue(const std::string& key,std::string&val);
private:
	typedef std::map<std::string,std::string> ValueMap;
	ValueMap kv_map;
};
}
}
#endif /* ARG_PARSE_HPP_ */
