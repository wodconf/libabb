/*
 * arg_parse.cpp
 *
 *  Created on: 2014-5-13
 *      Author: wd
 */

#include "arg_parse.hpp"
namespace adcloud{
namespace common{
ArgParse::ArgParse() {
	// TODO Auto-generated constructor stub

}

ArgParse::~ArgParse() {
	// TODO Auto-generated destructor stub
}
void ArgParse::Parse(int argc,const char* argv[]){
	for(int i=0;i<argc;i++){
		std::string str(argv[i]);
		if(str[0] != '-'){
			continue;
		}
		str = str.substr(1);
		int pos = 0;
		pos = str.find("=",0);
		if(pos != std::string::npos){
			kv_map[str.substr(0,pos)] = str.substr(pos+1);
		}else{
			kv_map[str] = "";
		}
	}
}
bool ArgParse::GetValue(const std::string& key,std::string&val){
	ValueMap::iterator iter = this->kv_map.find(key);
	if(iter == this->kv_map.end()){
		return false;
	}
	val = iter->second;
	return true;
}
}}
