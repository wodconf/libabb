
#include "config_file.hpp"
#include <fstream>
#include<iostream>
namespace adcloud { namespace common{


static void ClearSep(std::string&str,const std::string& sep){
	int begin = 0;
	begin = str.find(sep,begin);
	while(begin !=std::string::npos)
	{
		str.replace(begin, sep.size(), "");
		begin = str.find(sep,begin);
	}
}

ConfigFile::ConfigFile() {
}

ConfigFile::~ConfigFile() {
}

bool ConfigFile::Parse(const std::string& path){
	std::fstream file;
	file.open(path.c_str(),std::ios::in);
	if(!file.is_open()){
		return false;
	}
	std::string line;
	while( std::getline(file,line) ){
		ClearSep(line," ");
		ClearSep(line,"\t");
		int pos = 0;
		pos = line.find("=",0);
		if(pos != std::string::npos){
			kv_map[line.substr(0,pos)] = line.substr(pos+1);
		}
	}
	return true;
}
bool  ConfigFile::GetValue(const std::string& key,std::string&val){
	ValueMap::iterator iter = this->kv_map.find(key);
	if(iter == this->kv_map.end()){
		return false;
	}
	val = iter->second;
	return true;
}


}}
