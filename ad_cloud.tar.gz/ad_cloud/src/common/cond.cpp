
#include "cond.hpp"
#include <time.h>
#include <errno.h>
#include "log.hpp"
#include <cstring>
#include <sys/time.h>
namespace adcloud {
namespace common {

int Cond::WaitTimeout(Mutex& mtx,int timeout){
	struct timespec s;
	struct timespec tt;
	clock_gettime(CLOCK_MONOTONIC, &s);
	s.tv_sec +=timeout /1000;
	s.tv_nsec +=(timeout%1000)*1000000;
	s.tv_sec += s.tv_nsec/1000000000;
	s.tv_nsec %= 1000000000;
	int r = pthread_cond_timedwait(&cond_,&mtx.mtx_,&s);
	if(r!= 0 && r != ETIMEDOUT){
		LOG(WARN) << r << strerror(r);
	}
	return r;
}
}
}
