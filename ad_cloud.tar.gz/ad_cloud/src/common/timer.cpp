
#include "timer.hpp"
#include "time.hpp"
#include <limits.h>
#include <algorithm>
namespace adcloud {
namespace common {
Timer::Timer():id_(1),bstop_(false) {
}

Timer::~Timer() {
}
void Timer::Loop(){
	while(!bstop_){
		Concat();
		ItemMap::iterator iter = item_map_.begin();
		uint32_t min = INT_MAX;
		uint32_t df;
		uint64_t now = time::MSNow();
		Item* item;
		while(iter!=item_map_.end()){
			item = iter->second;
			if( !item->bremove ){
				df = now - item->pre;
				uint32_t left;
				if( df > item->timeout ){
					item->lis->L_Timer_OnTimout(iter->first);
					if(!item->brepeat) item->bremove = true;
					item->pre = now;
					now = time::MSNow();
					left = item->timeout;
				}else{
					left = item->timeout - df;

				}
				if(min > left){
					min = left;
				}
			}
			if(item->bremove){
				remove_ids_.push_back(iter->first);
			}
			iter++;
		}
		Earse();
		if(min == INT_MAX){
			this->notify_.Wait();
		}else{
			this->notify_.WaitTimeout(min);
		}
	}

}
void Timer::Concat(){
	Mutex::Locker l(mtx_);
	ItemMap::iterator iter = add_map_.begin();
	for(;iter!=add_map_.end();iter++){
		item_map_[iter->first] = iter->second;
	}
	add_map_.clear();
}
void Timer::Earse(){
	for(int i=0;i<remove_ids_.size();i++){
		item_map_.erase(remove_ids_[i]);
	}
	remove_ids_.clear();
}
void Timer::Stop(){
	bstop_ = true;
	this->notify_.Notify();
}
void Timer::ClearTimer(int id){
	{
		Mutex::Locker l(mtx_);
		ItemMap::iterator iter = add_map_.find(id);
		if(iter != add_map_.end()){
			add_map_.erase(iter);
			return;
		}
	}
	ItemMap::iterator iter = item_map_.find(id);
	if(iter != item_map_.end()){
		iter->second->bremove = true;
		return;
	}
}
int Timer::SetTimer(Listener* lis,uint32_t timeout,bool brepeat){
	Item* item = new Item();
	item->bremove = false;
	item->brepeat = brepeat;
	item->timeout = timeout;
	item->lis = lis;
	item->pre = time::MSNow();
	Mutex::Locker l(mtx_);
	int id = id_++;
	add_map_[id] = item;
	this->notify_.Notify();
	return id;
}
} /* namespace common */
} /* namespace adcloud */
