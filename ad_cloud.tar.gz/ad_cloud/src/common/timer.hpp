
#ifndef ADCLOUD_COMMON_TIMER_HPP_
#define ADCLOUD_COMMON_TIMER_HPP_
#include <map>
#include <vector>
#include "mutex.hpp"
#include "notification.hpp"
#include <stdint.h>
namespace adcloud {
namespace common {

class Timer {
public:
	struct Listener{
		virtual ~Listener(){};
		virtual void L_Timer_OnTimout(int id)=0;
	};
	Timer();
	~Timer();
	void Loop();
	void Stop();
	int SetTimer(Listener* lis,uint32_t timeout,bool brepeat);
	void ClearTimer(int id);
private:
	void Concat();
	void Earse();
	struct Item{
		bool bremove;
		uint64_t pre;
		uint32_t timeout;
		bool brepeat;
		Listener* lis;
	};
	bool bstop_;
	uint32_t id_;
	typedef std::map<uint32_t,Item*> ItemMap;
	ItemMap add_map_;
	ItemMap item_map_;
	Notification notify_;
	Mutex mtx_;
	std::vector<uint32_t> remove_ids_;
};
} /* namespace common */
} /* namespace adcloud */

#endif /* TIMER_HPP_ */
