
#include "serialization_able.hpp"
#include "log.hpp"

namespace adcloud {
namespace common {
uint32_t SerializationAble::Length(){
	return type_name.size()+ 1 + this->GetLength();
}
void SerializationAble::Encode(common::BufferWriter &buf){
	buf << type_name;
	this->EncodeBody(buf);
}
std::map<std::string,SerializationAble::type_createor> SerializationAble::s_create_map_;
void SerializationAble::RegistCreator(const std::string& name,type_createor fn)
{
	s_create_map_[name] = fn;
}
SerializationAble* SerializationAble::Decode(common::BufferReader& buf){
	std::string name;
	buf >> name;
	SerializationAble* rt = NULL;
	CreateMap::iterator iter = s_create_map_.find(name);
	if(iter != s_create_map_.end()){
		rt = iter->second();
		if(rt){
			rt->DecodeBody(buf);
		}
	}
	if(!rt){
		LOG(WARN) << "SerializationAble Decode fail creator not exist:" << name;
	}
	return rt;
}
}}
