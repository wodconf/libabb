

#ifndef AD_CLOUD_COMMON_TIME_HPP_
#define AD_CLOUD_COMMON_TIME_HPP_


namespace adcloud{ namespace common{

namespace time{
	extern void Sleep(int ms);
	extern long long MSNow();
}
}
}


#endif /* TIME_HPP_ */
