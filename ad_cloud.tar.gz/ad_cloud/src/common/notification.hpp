
#ifndef AD_CLOUD_COMMON_NOTIFY_HPP_
#define AD_CLOUD_COMMON_NOTIFY_HPP_
#include "mutex.hpp"
#include "cond.hpp"
namespace adcloud {
namespace common {

class Notification {
public:
	Notification();
	~Notification();
	void Wait();
	bool WaitTimeout(int timeout);
	void Notify();
private:
	bool bsingle_;
	Cond cond_;
	Mutex mtx_;
};

} /* namespace common */
} /* namespace adcloud */

#endif /* NOTIFY_HPP_ */
