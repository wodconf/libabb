
#include "time.hpp"
#include <sys/select.h>
#include <sys/time.h>
#include <unistd.h>
namespace adcloud{ namespace common{

namespace time{
void Sleep(int ms){
	struct timeval tv;
	tv.tv_sec = ms/1000;
	tv.tv_usec = ( ms- tv.tv_sec*1000)*1000;
	select(0,0,0,0,&tv);
}

long long MSNow()
{
	struct timeval time;
	gettimeofday(&time,NULL);
	return time.tv_sec*1000 + time.tv_usec/1000;
}
}
}
}
