

#include "gate/gate.hpp"
#include "global/global_init.hpp"
#include "gate/gate_config.hpp"
#include <stdlib.h>

using namespace adcloud;
int main(int argc,const char* argv[]){
	common::ArgParse parse;
	parse.Parse(argc,argv);
	if( global::Init(parse) != 0){
		LOG(ERROR) << "global.init.fail";
	}
	gate::Config cfg;
	if( ! cfg.Parse(parse) ){
		LOG(ERROR) << "gate.config.parse.fail";
		exit(-1);
	}
	gate::GATE* g = new gate::GATE();
	if( !g->Init(&cfg) ){
		LOG(ERROR) << "gate.init.fail";
		exit(-1);
	}
	g->Start();
	return 0;
}
