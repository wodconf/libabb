

#include "connector.hpp"
#include <cassert>
#include "connection.hpp"
#include "init.hpp"
namespace adcloud {
namespace translate {
Connector::Connector():lis_(NULL) {
	ctor = abb::net::Connector::Create(g_abb_ctx);
	this->ctor->SetEventCallback(this);
}
Connector::Connector(Listener* lis):lis_(lis) {
	ctor = abb::net::Connector::Create(g_abb_ctx);
	this->ctor->SetEventCallback(this);
}

Connector::~Connector() {

}
void Connector::Reset(){
	ctor->Reset();
}
bool Connector::Connect(const abb::net::IPAddr& addr,int* save_error){
	return this->ctor->Connect(addr,save_error);
}
void Connector::L_Connector_EventOpen(abb::net::Connection* con){
	this->lis_->L_Connector_OnOpen(Connection::Create(con));
}
void Connector::L_Connector_EventError(int err){
	this->lis_->L_Connector_OnOpenFail();
}
} /* namespace translate */
} /* namespace adcloud */
