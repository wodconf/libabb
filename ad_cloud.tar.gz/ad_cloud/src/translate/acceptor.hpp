
#ifndef AD_CLOUD_TRANSLATE_ACCEPTOR_H_
#define AD_CLOUD_TRANSLATE_ACCEPTOR_H_

#include <string>
#include "../common/buffer.hpp"

#include <abb/abb.hpp>
#include <abb/net/acceptor.hpp>
#include "connection.hpp"


namespace adcloud {
namespace translate{
class Acceptor:public abb::net::Acceptor::IEvent {
public:
	struct Listener{
		virtual ~Listener(){};
		virtual void L_Acceptor_OnConnection(Connection*) = 0;
	};
public:
	Acceptor();
	Acceptor(Listener* lis);
	virtual ~Acceptor();
	void SetListener(Listener* lis){lis_=lis;}
	bool Bind(const abb::net::IPAddr& addr,int* save_error){
		return ac->Bind(addr,save_error);
	}
	void SetEnable(bool benable){
		ac->SetEnable(benable);
	}
	virtual void L_Acceptor_Event(abb::net::Connection*);
private:
	abb::net::Acceptor* ac;
	Listener* lis_;
private:
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(Acceptor);
};
}
}

#endif /* ACCEPTOR_H_ */
