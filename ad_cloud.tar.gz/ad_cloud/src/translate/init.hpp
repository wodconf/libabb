
#ifndef __AD_CLOUD_TRANSLATE_INIT_HPP__
#define __AD_CLOUD_TRANSLATE_INIT_HPP__

#include <abb/abb.hpp>

namespace adcloud {
namespace translate{

extern abb::net::Context* g_abb_ctx;

void Init(int num_thread);
void Destroy();

}
}

#endif /* INIT_HPP_ */
