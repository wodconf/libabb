

#ifndef __AD_CLOUD_TRANSLATE_MESSAGE_H__
#define __AD_CLOUD_TRANSLATE_MESSAGE_H__
#include <map>
#include "../common/buffer_reader.hpp"
#include "../common/buffer_writer.hpp"
#include "../common/ref_object.hpp"
#include "connection.hpp"
#include "../common/log.hpp"
namespace adcloud{
namespace translate{

#define	ADCLOUD_MESSAGE_TAG_RPC_REQ 1001
#define	ADCLOUD_MESSAGE_TAG_RPC_RSP 1002

#define	ADCLOUD_MESSAGE_TAG_MASTER_DATA 3001

#define	ADCLOUD_MESSAGE_TAG_APP_CLOSE_CLIENT 4002
#define	ADCLOUD_MESSAGE_TAG_APP_SCOPE_OP 4003
#define	ADCLOUD_MESSAGE_TAG_APP_SCOPE_DATA 4004
#define	ADCLOUD_MESSAGE_TAG_APP_IN 4005
#define	ADCLOUD_MESSAGE_TAG_APP_MSG 4006
#define	ADCLOUD_MESSAGE_TAG_APP_OUT 4007
#define	ADCLOUD_MESSAGE_TAG_APP_OTHER_APP_DATA 4008



#define ADCLOUD_MESSAGE_TAG_IN 5002
#define	ADCLOUD_MESSAGE_TAG_MSG 5003
#define	ADCLOUD_MESSAGE_TAG_OUT 5004
#define	ADCLOUD_MESSAGE_TAG_CLOSE 5006
#define	ADCLOUD_MESSAGE_TAG_SCOPE 5007
#define	ADCLOUD_MESSAGE_TAG_SCOPE_DATA 5008

#define	ADCLOUD_MESSAGE_TAG_CLIENT_REGIST 5101
#define ADCLOUD_MESSAGE_TAG_CLIENT_REGIST_BACK 5103
#define	ADCLOUD_MESSAGE_TAG_CLIENT_MESSAGE 5102

class Message:public common::RefObject{
public:
	typedef Message* (*message_createor)( uint32_t len );
	static void RegistCreator(int tag,message_createor fn);
	static Message* DecodeMessage(common::BufferReader &buf);
private:
	static std::map<int,message_createor> s_create_map_;
private:
	static bool DecodeHeadIfEnough(common::BufferReader &buf,uint16_t* tag,uint32_t * len);
public:
	Message(uint16_t tag):tag_(tag),len_(0),conn_(NULL){len_ = this->GetLength();}
	Message(uint16_t tag,uint32_t len):tag_(tag),len_(len),conn_(NULL){}
	virtual ~Message(){
		if(conn_) conn_->UnRef();
	};
	void Encode(common::Buffer &buf);
	bool EncodeByData(void*data,int size){
		common::BufferWriter sbuf(data,size);
		return this->EncodeByWriter(sbuf);
	}
	bool EncodeByWriter(common::BufferWriter &buf);
	uint16_t GetTag(){
		return tag_;
	}
	uint32_t Length(){
		return sizeof(tag_)+sizeof(len_) + len_;
	}
	virtual void Print();
	const char* GetTagString();
	void SetConnection(Connection* conn){
		if(conn_) conn_->UnRef();
		conn_ = conn;
		if(conn_)conn_->Ref();
	}
	Connection* GetConnection(){
		return conn_;
	}
protected:
	uint32_t GetBodyLength(){
		return len_;
	}
private:
	void SetLength(uint32_t len){
		len_ = len;
	}
	virtual uint32_t GetLength(){return 0;};
	virtual void EncodeBody(common::BufferWriter &buf){};
	virtual void DecodeBody(common::BufferReader &buf){};
private:
	uint16_t tag_;
	uint32_t len_;
	Connection* conn_;
};


template <typename T>
Message* T_Creater(uint32_t len){
	return new T(len);
}

}
}



#endif /* MESSAGE_H_ */
