
#ifndef __AD_CLOUD_TRANSLATE_CONNECTION_HPP__
#define __AD_CLOUD_TRANSLATE_CONNECTION_HPP__
#include <vector>
#include "../common/buffer.hpp"
#include "../common/mutex.hpp"
#include "../common/ref_object.hpp"
#include "../common/ref_pointer.hpp"
#include "../common/define.hpp"
#include <abb/net/connection.hpp>
#include <stddef.h>
namespace adcloud {
namespace translate {
class Message;
class Connection :public common::RefObject,abb::net::Connection::IEvent {
public:
	struct Listener{
		virtual ~Listener(){};
		virtual void L_Connection_OnMessage(Connection* self,Message*msg)=0;
		virtual void L_Connection_OnClose(Connection* self)=0;
	};
	static Connection* Create(abb::net::Connection* con){
		return new Connection(con);
	}
private:
	explicit Connection(abb::net::Connection* con);
public:
	~Connection();
	void SetListner(Listener* lis){
		lis_ = lis;
	}
	bool Send(Message&msg);
	bool SendData(void* data,int size);
	void Close();
	bool IsConnected(){
		return this->con_->IsConnected();
	}
	int GetErrorCode(){
		return this->con_->GetError();
	}
	virtual void L_Connection_EventRead(abb::net::Connection* self,abb::base::Buffer& buf);
	virtual void L_Connection_EventClose(abb::net::Connection* self);
private:
	void OnMessag(abb::base::Buffer& buf);
	void OnDrain();
	void OnClose();
	Listener* lis_;
	abb::net::Connection* con_;
private:
	static int Writer(void*arg,void*buf,int size);
private:
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(Connection);
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* CONNECTION_HPP_ */
