

#include "connection.hpp"
#include <cassert>
#include "../common/log.hpp"
#include "message.hpp"
namespace adcloud {
namespace translate {
Connection::Connection(abb::net::Connection* con):con_(con),lis_(NULL){
	this->con_->SetEventCallback(this);
}

Connection::~Connection() {
	con_->Destroy();
}
void Connection::Close(){
	con_->ShutDown();
}
bool Connection::Send(Message&msg){
	if(!this->con_->IsConnected())return false;
	abb::base::Buffer& buf = this->con_->LockWrite();
	msg.Encode(buf);
	this->con_->UnLockWrite();
	return true;
}

bool Connection::SendData(void* data,int sz){	
	if(!this->con_->IsConnected())return false;
	this->con_->SendData(data,sz);
	return true;
}
void Connection::L_Connection_EventRead(abb::net::Connection* self,abb::base::Buffer& buf){
	this->Ref();
	while(buf.Size() > 0 && lis_ ){
		common::BufferReader sbuf(buf.Data(),buf.Size());
		Message* msg = Message::DecodeMessage(sbuf);
		if(msg){
			buf.GaveRd(msg->Length());
			msg->SetConnection(this);
			lis_->L_Connection_OnMessage(this,msg);
			msg->UnRef();
		}else{
			break;
		}
	}
	this->UnRef();
}
void Connection::L_Connection_EventClose(abb::net::Connection* self){
	con_->ShutDown();
	if( lis_ ){
		lis_->L_Connection_OnClose(this);
	}
}

} /* namespace translate */
} /* namespace adcloud */
