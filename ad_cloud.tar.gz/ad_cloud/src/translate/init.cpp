#include "./init.hpp"
namespace adcloud {
namespace translate{

abb::net::Context* g_abb_ctx;

void Init(int num_thread){
	if(!g_abb_ctx){
		abb::net::ContextOption option;
		option.SetNumDispatch(0);
		option.SetNumPoller(num_thread);
		option.SetRunCurrentThread(false);
		g_abb_ctx = abb::NewContext(option);
		abb::RunContext(g_abb_ctx);
	}

}
void Destroy(){
	if(g_abb_ctx)
		abb::DeleteContext(g_abb_ctx);
}
}
}
