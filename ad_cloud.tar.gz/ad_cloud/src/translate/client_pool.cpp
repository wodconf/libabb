
#include "client_pool.hpp"

namespace adcloud {
namespace translate {

ClientPool::ClientPool(Listener* lis):lis_(lis) {
}

ClientPool::~ClientPool() {
	mtx_.Lock();
	ClientMap::iterator iter = client_map_.begin();
	for(;iter!= client_map_.end();iter++){
		iter->second->Close();
		delete iter->second;
		client_map_.erase(iter);
	}
	mtx_.UnLock();
}
TcpClient* ClientPool::GetClient(const std::string& addr){
	common::Mutex::Locker l( mtx_ );
	ClientMap::iterator iter = client_map_.find(addr);
	if(iter != client_map_.end()){
		iter->second->Ref();
		return iter->second;
	}else{
		abb::net::IPAddr ip_addr;
		if( !ip_addr.SetByString(addr) ){
			LOG(WARN) << "addr format fail" << addr;
			return NULL;
		}
		TcpClient* cli = new TcpClient();
		cli->SetListener(this);
		cli->SetCtx(addr);
		if( !cli->Connect(ip_addr)){
			LOG(WARN) << "Connect fail" << addr;
			delete cli;
			return NULL;
		}
		client_map_[addr] = cli;
		cli->Ref();
		return cli;
	}
}
bool ClientPool::SendToAddr(Message& msg,const std::string& addr){
	TcpClient* cli = this->GetClient(addr);
	if(cli){
		cli->Send(msg);
		cli->UnRef();
		return true;
	}
	return false;
}
void ClientPool::L_Client_OnOpen(TcpClient*){

}
void ClientPool::L_Client_OnMessage(TcpClient*cli,Message* msg){
	this->lis_->L_ClientPool_ConnectionMessage(cli->GetCtx(),msg);
}
void ClientPool::L_Client_OnCLose(TcpClient*cli,int code){
	std::string ctx = cli->GetCtx();
	{
		common::Mutex::Locker l( mtx_ );
		ClientMap::iterator iter = client_map_.find(ctx);
		if(iter != client_map_.end()){
			iter->second->Close();
			iter->second->UnRef();
			client_map_.erase(iter);
		}
	}
	this->lis_->L_ClientPool_ConnectionReset(ctx);
}
} /* namespace translate */
} /* namespace adcloud */
