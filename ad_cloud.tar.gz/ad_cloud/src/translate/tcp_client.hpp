#ifndef __AD_CLOUD_TRANSLATE_CLIENT_HPP__
#define __AD_CLOUD_TRANSLATE_CLIENT_HPP__

#include "../common/mutex.hpp"
#include "../common/define.hpp"
#include "../common/ref_object.hpp"
#include "connector.hpp"
#include "connection.hpp"
#include "message.hpp"

namespace adcloud{
namespace translate{
class TcpClient:public common::RefObject, Connection::Listener,Connector::Listener{
public:
	class Listener{
	public:
		virtual ~Listener(){};
		virtual void L_Client_OnOpen(TcpClient*) = 0;
		virtual void L_Client_OnMessage(TcpClient*,Message* msg) = 0;
		virtual void L_Client_OnCLose(TcpClient*,int code) = 0;
	};
public:
	TcpClient();
	virtual ~TcpClient();
	bool Connect(const abb::net::IPAddr& addr);
	bool Send(Message& msg);
	void Close();
	void SetCtx(const std::string& str){ctx_ = str;}
	const std::string&  GetCtx(){return ctx_;}
	void SetListener(Listener* lis){	lis_ = lis;}
	bool IsConnected(){
		if(con_){
			return con_->IsConnected();
		}else{
			return false;
		}
	}
	virtual void L_Connection_OnMessage(Connection* self,Message*msg);
	virtual void L_Connection_OnClose(Connection* self);
	virtual void L_Connector_OnOpen(Connection* ptr);
	virtual void L_Connector_OnOpenFail();
private:
	std::string ctx_;
	abb::base::Buffer buf_;
	Connection* con_;
	Connector ctor_;
	common::Mutex mtx_;
	Listener* lis_;
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(TcpClient);
};
}
}
#endif
