
#include "message.hpp"
#include "../common/log.hpp"
#include <cassert>
namespace adcloud{
namespace translate{
#define HEAD_SIZE (sizeof(uint16_t)+sizeof(uint32_t))
void Message::Encode(common::Buffer &buf){
	len_= this->GetLength();
	uint32_t len = len_+sizeof(len_)+sizeof(tag_);
	buf.EnoughSize(len);
	common::BufferWriter writer(buf.WrData(),len);
	this->EncodeByWriter(writer);
	buf.GaveWr(len);
}

bool Message::EncodeByWriter(common::BufferWriter &buf){
	len_= this->GetLength();
	if( buf.FreeSize() < len_+ HEAD_SIZE){
		return false;
	}
	buf.NET_WriteUint16(tag_);
	buf.NET_WriteUint32(len_);
	common::BufferWriter bodywr(buf.WritePtr(),len_);
	buf.Grow(len_);
	this->EncodeBody(bodywr);
	return true;
}
void  Message::Print(){

}
const char* Message::GetTagString(){
	return "UNKNOW_TAG";
}
bool Message::DecodeHeadIfEnough(common::BufferReader &buf,uint16_t* ptag,uint32_t *plen){
	if(buf.DataSize() < HEAD_SIZE){
		return false;
	}
	uint16_t tag;
	uint32_t len;
	tag = buf.HOST_ReadUint16();
	len = buf.HOST_ReadUint32();
	if(len <= buf.DataSize()){
		*plen = len;
		*ptag = tag;
		return true;
	}else{
		std::map<int,Message::message_createor>::iterator iter = s_create_map_.find(tag);
		if(iter == s_create_map_.end()){
			LOG(INFO) << "decode.enough.message.fail.tag.is.not.registed." <<  "tag:"<<tag << "buf_size:"<< buf.DataSize() << "need:" << len;
		}
		return false;
	}
}
Message* Message::DecodeMessage(common::BufferReader &buf){
	try{
		uint16_t tag;
		uint32_t len;
		Message* msg = NULL;
		if( Message::DecodeHeadIfEnough(buf,&tag,&len) ){
			std::map<int,Message::message_createor>::iterator iter = s_create_map_.find(tag);
			if(iter!= s_create_map_.end()){
				msg =  iter->second(len);
				common::BufferReader bodybuf(buf.DataPtr(),len);
				buf.Grow(len);
				msg->DecodeBody(bodybuf);
			}else{
				LOG(WARN) << "CreateMessage fail tag:" << tag;
			}
		}
		return msg;
	}catch(...){
		LOG(ERROR) << "buf.decodemessage.fail.out_of_range";
		return NULL;
	}
}
std::map<int,Message::message_createor> Message::s_create_map_;
void Message::RegistCreator(int tag,message_createor fn){
	s_create_map_[tag] = fn;
}

}}
