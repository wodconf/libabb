

#ifndef __AD_CLOUD_TRANSLATE_CONNECTOR_H__
#define __AD_CLOUD_TRANSLATE_CONNECTOR_H__
#include <string>
#include "connection.hpp"
#include <abb/net/connector.hpp>
#include "../common/define.hpp"
namespace adcloud {
namespace translate {
class Connection;
class Connector :public abb::net::Connector::IEvent{
public:
	struct Listener{
		virtual ~Listener(){};
		virtual void L_Connector_OnOpen(Connection* ptr) = 0;
		virtual void L_Connector_OnOpenFail() = 0;
	};
public:
	Connector();
	Connector(Listener* lis);
	virtual ~Connector();
	void SetListener(Listener* lis){lis_=lis;}
	bool Connect(const abb::net::IPAddr& addr,int* save_error = NULL);
	void Reset();
	virtual void L_Connector_EventOpen(abb::net::Connection* con);
	virtual void L_Connector_EventError(int err);
private:
	Listener *lis_;
	abb::net::Connector* ctor;
	AD_CLOUND_DISALLOW_COPY_AND_ASSIGN(Connector);
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* CONNECTOR_H_ */
