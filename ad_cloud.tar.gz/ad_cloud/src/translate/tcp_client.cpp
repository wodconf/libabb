
#include "tcp_client.hpp"

namespace adcloud{
namespace translate{
TcpClient::TcpClient():ctor_(this),con_(NULL),lis_(NULL){

}
TcpClient::~TcpClient(){
	if(con_)
		con_->UnRef();
}
bool TcpClient::Connect(const abb::net::IPAddr& addr){
	common::Mutex::Locker l(mtx_);
	if(con_)return false;
	return ctor_.Connect(addr);
}
bool TcpClient::Send(Message& msg){
	common::Mutex::Locker l(mtx_);
	if(con_){
		return con_->Send(msg);
	}else{
		msg.Encode(buf_);
		return true;
	}
}
void TcpClient::Close(){
	common::Mutex::Locker l(mtx_);
	ctor_.Reset();
	if(con_){
		con_->SetListner(NULL);
		con_->Close();
		con_->UnRef();
		con_ = NULL;
	}else{
		buf_.Clear();
	}
}
void TcpClient::L_Connection_OnMessage(Connection* self,Message*msg){
	if(lis_){
		lis_->L_Client_OnMessage(this,msg);
	}
}
void TcpClient::L_Connection_OnClose(Connection* self){
	if(lis_){
		lis_->L_Client_OnCLose(this,self->GetErrorCode());
	}
}
void TcpClient::L_Connector_OnOpen(Connection* ptr){
	{
		common::Mutex::Locker l(mtx_);
		con_ = ptr;
		con_->SetListner(this);
		if(buf_.Size() > 0){
			con_->SendData(buf_.Data(),buf_.Size());
			buf_.Clear();
		}
	}
	if(lis_){
		lis_->L_Client_OnOpen(this);
	}
}
void TcpClient::L_Connector_OnOpenFail(){
	if(lis_){
		lis_->L_Client_OnCLose(this,0);
	}
}
}
}
