
#include "acceptor.hpp"
#include <cassert>
#include "connection.hpp"
#include "../common/log.hpp"

#include "init.hpp"
namespace adcloud {
namespace translate{
Acceptor::Acceptor():lis_(NULL){
	this->ac = abb::net::Acceptor::Create(g_abb_ctx);
	this->ac->SetEventCallback(this);
}
Acceptor::Acceptor(Listener* lis):lis_(lis) {
	this->ac = abb::net::Acceptor::Create(g_abb_ctx);
	this->ac->SetEventCallback(this);
}

Acceptor::~Acceptor() {
	ac->Destroy();
}
void Acceptor::L_Acceptor_Event(abb::net::Connection* c){
	this->lis_->L_Acceptor_OnConnection(Connection::Create(c));
}

}
} /* namespace adcloud */
