

#ifndef __AD_CLOUD_TRANSLATE_CLIENT_POOL_HPP__
#define __AD_CLOUD_TRANSLATE_CLIENT_POOL_HPP__

#include "tcp_client.hpp"
#include <map>

namespace adcloud {
namespace translate {

class ClientPool:public TcpClient::Listener {
public:
	class Listener{
	public:
		virtual ~Listener(){};
		virtual void L_ClientPool_ConnectionReset(const std::string& addr) = 0;
		virtual void L_ClientPool_ConnectionMessage(const std::string& addr,Message* msg) = 0;
	};
	ClientPool(Listener* lis);
	~ClientPool();
	bool SendToAddr(Message& msg,const std::string& addr);//127.0.0.1:1234;
	virtual void L_Client_OnOpen(TcpClient*);
	virtual void L_Client_OnMessage(TcpClient*,Message* msg);
	virtual void L_Client_OnCLose(TcpClient*,int code);
private:
	TcpClient* GetClient(const std::string& addr);
	common::Mutex mtx_;
	typedef std::map<std::string,TcpClient*> ClientMap;
	ClientMap client_map_;
	Listener* lis_;
};

} /* namespace translate */
} /* namespace adcloud */

#endif /* CLIENT_POOL_HPP_ */
