var adcloud = require("./index");

var coder = require("./lib/coder");
var app_msg = require("./lib/app_message");

var buf = new Buffer(100);
var msg = app_msg.MAppScopeData("123",123,buf);

var num = 100;
var size = msg.Length() * num;
var buf = new Buffer();
var buf_writer = new coder.BufferWriter(size);
for(var i=0;i<100;i++){
	msg.Encode(buf_writer);
}